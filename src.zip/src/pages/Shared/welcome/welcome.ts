import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DashboardPage } from '../../Supervisor/KPI/dashboard/dashboard';
import { GlobalProvider } from '../../../providers/global/global';
import { StdashboardPage } from '../../Technician/stdashboard/stdashboard';
import { SependingjcPage } from '../../Technician/sependingjc/sependingjc';
import { StytsPage } from '../../Technician/styts/styts';
import { StwipPage } from '../../Technician/stwip/stwip';
//import { ScdashboardPage } from '../../Supervisor/KPI/scdashboard/scdashboard';

@IonicPage()
@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html',
})

export class WelcomePage {

  SetTimeOutDetails: any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider) {

    let that = this;

    this.SetTimeOutDetails = setTimeout(function () {

      if (that.global.WelcomeNavigateType == 1) {
        that.navCtrl.setRoot(DashboardPage);
        //that.navCtrl.setRoot(ScdashboardPage);
      }
      else if (that.global.WelcomeNavigateType == 2) {
        that.navCtrl.setRoot(StwipPage);
      }
      else if (that.global.WelcomeNavigateType == 3) {
        that.navCtrl.setRoot(StytsPage)
      }
      else if (that.global.WelcomeNavigateType == 4) {
        that.navCtrl.setRoot(StdashboardPage);
      }
      else if (that.global.WelcomeNavigateType == 5) {
        that.navCtrl.setRoot(SependingjcPage, { data: that.global.PendingJCData });
      }

    }, that.global.WelcomeScreentime);

  }

  NextClick() {

    clearTimeout(this.SetTimeOutDetails);

    if (this.global.WelcomeNavigateType == 1) {
      this.navCtrl.setRoot(DashboardPage);
      //this.navCtrl.setRoot(ScdashboardPage);
    }
    else if (this.global.WelcomeNavigateType == 2) {
      this.navCtrl.setRoot(StwipPage);
    }
    else if (this.global.WelcomeNavigateType == 3) {
      this.navCtrl.setRoot(StytsPage)
    }
    else if (this.global.WelcomeNavigateType == 4) {
      this.navCtrl.setRoot(StdashboardPage);
    }
    else if (this.global.WelcomeNavigateType == 5) {
      this.navCtrl.setRoot(SependingjcPage, { data: this.global.PendingJCData });
    }

  }

  ngOnInit() {

    this.global.RealTimeNotificationAlertCountFunction();

  }

}
