import { Component } from '@angular/core';
import { AlertController, IonicPage, MenuController, NavController, NavParams, Platform } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { WelcomePage } from '../welcome/welcome';
declare var Pushy: any;

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})

export class LoginPage {

  Username: string = "";
  Password: string = "";
  ApplicationID: number = 1;
  showPassword: boolean = false;
  currentversion: any;
  DeviceID: string;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    public alertCtrl: AlertController,
    public global: GlobalProvider,
    public platform: Platform,
    public menuCtrl: MenuController) {

    this.menuCtrl.enable(false);




  }




  ngOnInit() {

    let localSession = JSON.parse(localStorage.getItem("Session"));

    console.log(localSession);

    if (localSession != null && localSession.length > 0) {

      let lastLoginDate = new Date(localSession[0].LastLoginDate.toString().split("T")[0]).getTime();

      let today = new Date();
      let year = today.getFullYear();
      let month = (today.getMonth() + 1) > 9 ? (today.getMonth() + 1) : "0" + (today.getMonth() + 1);
      let day = today.getDate() > 9 ? today.getDate() : "0" + today.getDate();
      let date = new Date(year + "-" + month + "-" + day).getTime();

      if (lastLoginDate == date) {

        this.Username = localSession[0].Username;
        this.Password = localSession[0].Password;

        // this.LoginClick();

      }
      else {
        localStorage.clear();
      }

      // this.Username = localSession[0].Username;
      // this.Password = localSession[0].Password;

      // this.LoginClick();

    }

  }

  LoginClick1() {

    debugger

    if (this.Username != "" && this.Username != undefined && this.Username != null &&
      this.Password != "" && this.Password != undefined && this.Password != null) {

      if (this.global.CheckInternetConnection()) {

        this.global.LoadingShow("Please wait...");

        this.httpClient.post<any>(this.global.HostedPath + "GetLoginDetails?Username=" + this.Username.trim() + "&Password=" + this.Password.trim(), {}).subscribe(loginDetails => {

          if (loginDetails.StatusCode == 200) {

            this.global.UserDetails = JSON.parse(loginDetails.Output);

            console.log(this.global.UserDetails);

            if (this.global.UserDetails.length > 0) {


              // localStorage.setItem("Session", JSON.stringify(this.global.UserDetails));

              //=====================================New Code==================================//
              // Encoding and storing data
              const encodedData = btoa(JSON.stringify(this.global.UserDetails));
              localStorage.setItem("Session", encodedData);
              console.log("Encoded Data:", encodedData);

              // Retrieving and decoding data
              const storedData = localStorage.getItem("Session");

              if (storedData) {
                const decodedData = atob(storedData);
                const userDetails = JSON.parse(decodedData);
                console.log("Decoded Data:", userDetails);
              } else {
                console.log("No data found in localStorage.");
              }
              //================================================================================//


              if (this.global.UserDetails[0].ProfilePhoto == "") {
                this.global.UserDetails[0].ProfilePhotoPath = "assets/imgs/profile.png";
              }
              else {
                this.global.UserDetails[0].ProfilePhotoPath = this.global.HostedPath.split("api")[0] + "/UploadedFiles/" + this.global.UserDetails[0].ProfilePhoto;
              }

              if (this.global.CheckInternetConnection()) {

                this.httpClient.post(this.global.HostedPath + "UpdateUserDevices?EmployeIC=" + this.global.UserDetails[0].Employee_IC + "&DeviceID=" + this.DeviceID + "&Platform=" + this.platform.is('android'), null).subscribe((success) => {

                  if (loginDetails.StatusCode == 200) {

                    this.CheckAutoUpdate(this.global.UserDetails[0].Designation);

                  }
                  else {
                    console.log(success);
                    this.global.ToastShow("Device registration failed");
                  }

                }, (error) => {
                  console.log(`Error Adding New Employee:`, error);
                });

              }
              else {
                this.global.ToastShow(this.global.NetworkMessage);
              }

            }
            else {
              this.global.ToastShow("Please enter correct ID and Password​");
              this.global.LoadingHide();
            }

          }
          else {
            console.log(loginDetails);
            this.global.ToastShow("Something went wrong, Pls try again later");
            this.global.LoadingHide();
          }


        }, (error) => {
          console.log(error);
          this.global.LoadingHide();
        });

      }
      else {
        this.global.ToastShow(this.global.NetworkMessage);
      }

    }
    else {
      this.global.ToastShow("Please enter Username and Password");
    }

  }

  LoginClick2() {

    if (this.Username != "" && this.Username != undefined && this.Username != null &&
      this.Password != "" && this.Password != undefined && this.Password != null) {

      if (this.global.CheckInternetConnection()) {

        if (this.DeviceID == "" || this.DeviceID == null) {         //Mobile
          //if (!(this.DeviceID == "" || this.DeviceID == null)) {    //Browse
          //this.global.LoadingShow("Please wait...");
          this.global.ToastShow("Please Restart the application");
        }
        else {

          this.global.LoadingShow("Please wait...");

          this.httpClient.post<any>(this.global.HostedPath + "GetLoginDetails?Username=" + this.Username.trim() + "&Password=" + this.Password.trim(), {}).subscribe(loginDetails => {

            if (loginDetails.StatusCode == 200) {

              this.global.UserDetails = JSON.parse(loginDetails.Output);

              console.log(this.global.UserDetails);

              if (this.global.UserDetails.length > 0) {

                // localStorage.setItem("Session", JSON.stringify(this.global.UserDetails));

        //=====================================New Code==================================//

                // Encoding and storing data
              const encodedData = btoa(JSON.stringify(this.global.UserDetails));
              localStorage.setItem("Session", encodedData);
              console.log("Encoded Data:", encodedData);

              // Retrieving and decoding data
              const storedData = localStorage.getItem("Session");

              if (storedData) {
                const decodedData = atob(storedData);
                const userDetails = JSON.parse(decodedData);
                console.log("Decoded Data:", userDetails);
              } else {
                console.log("No data found in localStorage.");
              }

        //==================================================================================//




                if (this.global.UserDetails[0].ProfilePhoto == "") {
                  this.global.UserDetails[0].ProfilePhotoPath = "assets/imgs/profile.png";
                }
                else {
                  this.global.UserDetails[0].ProfilePhotoPath = this.global.HostedPath.split("api")[0] + "/UploadedFiles/" + this.global.UserDetails[0].ProfilePhoto;
                }

                this.global.RealTimeNotificationAlertCountFunction();
                if (this.global.CheckInternetConnection()) {

                  this.httpClient.post(this.global.HostedPath + "UpdateUserDevices?EmployeIC=" + this.global.UserDetails[0].Employee_IC + "&DeviceID=" + this.DeviceID + "&Platform=" + this.platform.is('android'), null).subscribe((success) => {

                    if (loginDetails.StatusCode == 200) {

                      this.CheckAutoUpdate(this.global.UserDetails[0].Designation);

                      this.AddUserDeviceDetails(this.global.UserDetails[0].Employee_IC, this.DeviceID, this.platform.is('android'));

                    }
                    else {
                      console.log(success);
                      this.global.ToastShow("Device registration failed");
                    }

                  }, (error) => {
                    console.log(`Error Adding New Employee:`, error);
                  });

                }
                else {
                  this.global.ToastShow(this.global.NetworkMessage);
                }

              }
              else {
                this.global.ToastShow("Please enter correct ID and Password​");
                this.global.LoadingHide();
              }

            }
            else {
              console.log(loginDetails);
              this.global.ToastShow("Something went wrong, Pls try again later");
              this.global.LoadingHide();
            }


          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });
        }

      }
      else {
        this.global.ToastShow(this.global.NetworkMessage);
      }

    }
    else {
      this.global.ToastShow("Please enter Username and Password");
    }

  }

  LoginClick() {

    if (this.Username != "" && this.Username != undefined && this.Username != null &&
      this.Password != "" && this.Password != undefined && this.Password != null) {

      if (this.global.CheckInternetConnection()) {

        this.global.LoadingShow("Please wait...");

        this.httpClient.post<any>(this.global.HostedPath + "GetLoginDetails?Username=" + this.Username.trim() + "&Password=" + this.Password.trim(), {}).subscribe(loginDetails => {

          if (loginDetails.StatusCode == 200) {

            this.global.UserDetails = JSON.parse(loginDetails.Output);

            console.log(this.global.UserDetails);

            if (this.global.UserDetails.length > 0) {

              this.global.isDeviceLogedIn = true;

              // localStorage.setItem("Session", JSON.stringify(this.global.UserDetails));

        //=====================================New Code==================================//

              // Encoding and storing data
              const encodedData = btoa(JSON.stringify(this.global.UserDetails));
              localStorage.setItem("Session", encodedData);
              console.log("Encoded Data:", encodedData);

              // Retrieving and decoding data
              const storedData = localStorage.getItem("Session");

              if (storedData) {
                const decodedData = atob(storedData);
                const userDetails = JSON.parse(decodedData);
                console.log("Decoded Data:", userDetails);
              } else {
                console.log("No data found in localStorage.");
              }
        //==================================================================================//



              if (this.global.UserDetails[0].ProfilePhoto == "") {
                this.global.UserDetails[0].ProfilePhotoPath = "assets/imgs/profile.png";
              }
              else {
                this.global.UserDetails[0].ProfilePhotoPath = this.global.HostedPath.split("api")[0] + "/UploadedFiles/" + this.global.UserDetails[0].ProfilePhoto;
              }

              this.global.RealTimeNotificationAlertCountFunction();
              if (this.global.CheckInternetConnection()) {

                if (this.global.isDevice) {

                  var deviceIdInterval = setInterval(() => {

                    console.log("Outside the setInterval");
                    if (this.DeviceID == "" || this.DeviceID == null) {
                      this.FetchDeviceID()
                    }
                    else if (!(this.DeviceID == "" || this.DeviceID == null)) {

                      console.log("Inside the setInterval");
                      console.log("Device ID" + this.DeviceID);
                      // CALLING UPDATE USER DEVICE //
                      this.httpClient.post(this.global.HostedPath + "UpdateUserDevices?EmployeIC=" + this.global.UserDetails[0].Employee_IC + "&DeviceID=" + this.DeviceID + "&Platform=" + this.platform.is('android'), null).subscribe((success) => {

                        if (loginDetails.StatusCode == 200) {

                          clearInterval(deviceIdInterval);
                          this.CheckAutoUpdate(this.global.UserDetails[0].Designation);

                        }
                        else {
                          console.log(success);
                          this.global.ToastShow("Device registration failed");
                        }

                      }, (error) => {
                        console.log(`Error Adding New Employee:`, error);
                      });
                      // END CALLING UPDATE USER DEVICE //
                    }

                  }, 1000);

                }
                else {

                  this.httpClient.post(this.global.HostedPath + "UpdateUserDevices?EmployeIC=" + this.global.UserDetails[0].Employee_IC + "&DeviceID=" + this.DeviceID + "&Platform=" + this.platform.is('android'), null).subscribe((success) => {

                    if (loginDetails.StatusCode == 200) {

                      clearInterval(deviceIdInterval);
                      this.CheckAutoUpdate(this.global.UserDetails[0].Designation);

                    }
                    else {
                      console.log(success);
                      this.global.ToastShow("Device registration failed");
                    }

                  }, (error) => {
                    console.log(`Error Adding New Employee:`, error);
                  });

                }

              }
              else {
                this.global.ToastShow(this.global.NetworkMessage);
              }

            }
            else {
              this.global.ToastShow("Please enter correct ID and Password");
              this.global.LoadingHide();
            }

          }
          else {
            console.log(loginDetails);
            this.global.ToastShow("Something went wrong, Pls try again later");
            this.global.LoadingHide();
          }


        }, (error) => {
          console.log(error);
          this.global.LoadingHide();
        });

      }
      else {
        this.global.ToastShow(this.global.NetworkMessage);
      }

    }
    else {
      this.global.ToastShow("Please enter Username and Password");
    }

  }

  GetAllMasters(user) {

    this.httpClient.get<any>(this.global.HostedPath + "GetAllMasters").subscribe(masters => {

      if (masters.StatusCode == 200) {

        this.global.MasterData = JSON.parse(masters.Output);

        console.log(this.global.MasterData);

        if (user == "Works Manager") {

          this.global.IsManager = true;
          this.global.WelcomeNavigateType = 1;
          this.navCtrl.setRoot(WelcomePage);

        }
        else if (user == "Floor Supervisor") {

          this.global.IsManager = false;
          this.global.WelcomeNavigateType = 1;
          this.navCtrl.setRoot(WelcomePage);

        }
        else if (user == "Technician" || user == "Assistant Technician" || user == "Electrician") {

          this.CheckTechinicianPendingJC();

        }
        else {
          this.global.ToastShow("You are not valid user");
        }

      }
      else {
        console.log(masters);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }

      this.global.LoadingHide();

    }, (error) => {
      console.log(error);
      this.global.LoadingHide();
    });

  }

  CheckTechinicianPendingJC() {

    this.httpClient.get<any>(this.global.HostedPath + "GetTechnicianPendingJC?TechnicianID=" + this.global.UserDetails[0].Employee_IC).subscribe(jobCards => {

      if (jobCards.StatusCode == 200) {

        let jc = JSON.parse(jobCards.Output);

        if (jc.length > 0) {
          this.global.WelcomeNavigateType = 5;
          this.global.PendingJCData = jc;
          this.navCtrl.setRoot(WelcomePage);
        }
        else {

          this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=2" + "&FromeDate=02/14/2024&ToDate=03/14/2024"
          ).subscribe(jobCards => {

            if (jobCards.StatusCode == 200) {

              console.log(JSON.parse(jobCards.Output));

              if (JSON.parse(jobCards.Output)[0].WIP > 0) {
                this.global.WelcomeNavigateType = 2;
              }
              else if (JSON.parse(jobCards.Output)[0].YTS > 0) {
                this.global.WelcomeNavigateType = 3;
              }
              else {
                this.global.WelcomeNavigateType = 4;
              }

              this.navCtrl.setRoot(WelcomePage);

            }
            else {
              console.log(jobCards);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

          });

        }

      }
      else {
        console.log(jobCards);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
    });

  }

  CheckAutoUpdate(user) {

    this.httpClient.get<any>(this.global.HostedPath + "GetAutoUpdateAppDetails?ApplicationID=" + this.ApplicationID).subscribe(autoUpdateDetails => {

      if (autoUpdateDetails.StatusCode == 200) {

        let autoUpdate = JSON.parse(autoUpdateDetails.Output);

        console.log(autoUpdate);

        this.global.AutoUpdateDetails = autoUpdate;

        if (autoUpdate.length > 0) {

          if ((autoUpdate[0].AppVersion > this.global.ApplicationVersion) && autoUpdate[0].AndroidUpdate) {

            this.global.IsAlertOpen = true;

            let d = new Date(autoUpdate[0].FromDate).toString().split(" ");
            let fromDate = d[2] + "-" + d[1] + "-" + d[3];

            let RegisterAlert = this.alertCtrl.create({
              title: 'Update Availability',
              message: '<p style="font-weight:600;display:block">Please update the new version</p>Version : ' + autoUpdate[0].AppStoreVersion + '<br/>Size : ' + autoUpdate[0].AppSize + '<br/>Release Date : ' + fromDate,
              // buttons: [
              //   {
              //     text: 'Update',
              //     cssClass: 'BtnOnePopup',
              //     handler: data => {
              //       this.global.IsAlertOpen = false;
              //       window.location.href = autoUpdate[0].Android_Link;
              //     }
              //   }
              // ],

              //==============================New Code====================//
              buttons: [
                {
                  text: 'Update',
                  cssClass: 'BtnOnePopup',
                  handler: data => {
                    this.global.IsAlertOpen = false;
                    const trustedRedirectURL = 'https://wps_prod.vecv.net/WP_MobileApp'; // Replace with your trusted URL or whitelist logic
                    window.location.href = trustedRedirectURL;
                  }
                }
              ],
              //==================================================================//

              enableBackdropDismiss: false
            });

            RegisterAlert.present();

          }
          else {
            this.GetAllMasters(user);
          }

        }
        else {
          this.GetAllMasters(user);
        }

      }
      else {
        console.log(autoUpdateDetails);
        this.global.LoadingHide();
        this.global.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
      this.global.LoadingHide();
    });

  }

  ShowClick() {
    this.showPassword = !this.showPassword;
  }

  ForgotPasswordClick() {

    if (this.global.CheckInternetConnection()) {

      if (this.Username != "") {

        this.global.LoadingShow("Please wait");

        let NewPW = this.Username.substring(0, 1).toUpperCase() + this.GeneratePassword() + "@" + Math.floor(Math.random() * (999 - 100 + 1) + 100);

        this.httpClient.post<any>(this.global.HostedPath + "UpdatePassword?Username=" + this.Username + "&NewPassword=" + NewPW, {}).subscribe(result => {

          this.global.LoadingHide();

          if (result.StatusCode == 200) {

            this.SendPWSMS(NewPW, result.Output);

          }
          else if (result.StatusCode == 0) {

            this.global.ToastShow("Mobile number is not registered, Pls contact Admin");
          }
          else if (result.StatusCode == 4) {

            this.global.ToastShow("Invalid Username");
          }
          else {
            console.log(result);
            this.global.ToastShow("Something went wrong, Pls try again later");
          }

        }, (error) => {
          console.log(error);
          this.global.LoadingHide();
        });

      }
      else {
        this.global.ToastShow("Please enter Username");
      }

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  SendPWSMS(NewPW, mobile) {

    let lastdigits = mobile.substr(mobile.length - 4, 4);

    let msg = "Dear " + this.Username + ", Your new password for Eicher ProfiTech Application is " + NewPW + ", Please do not share this password with anyone. Regards, Eicher";

    this.httpClient.get<any>("https://easygosms.in/api/url_api.php?api_key=fSdgaXWDCFLiM3zp&pass=3cMkYVhy9m&senderid=EICHER&dlttempid=1707170988831080871&dlttagid=&message=" + msg + "&dest_mobileno=" + mobile + "&mtype=TXT").subscribe(result => {

      console.log(result);

      this.global.ToastShow("New Password has been sent to your registered mobile number ******" + lastdigits);
      localStorage.clear();

    }, (error) => {

      console.log(error);

      this.global.ToastShow("New Password has been sent to your registered mobile number ******" + lastdigits);
      localStorage.clear();

    });

  }

  GeneratePassword() {
    var length = 5,
      charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
      retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
      retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
  }

  AddUserDeviceDetails(EmployeIC, DeviceID, Platform) {

    if (this.global.CheckInternetConnection()) {

      this.httpClient.post(this.global.HostedPath + "UpdateUserDevices?EmployeIC=" + EmployeIC + "&DeviceID=" + DeviceID + "&Platform=" + Platform, null).subscribe((success) => {

        console.log(success);

      }, (error) => {
        console.log(`Error Adding New Employee:`, error);
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  FetchDeviceID() {
    // ===================================================== PUSHY NOTIFICATION ==================================================== //

    let that = this;

    document.addEventListener('deviceready', function () {
      // Start the Pushy service
      Pushy.listen();

      // Custom Notification Icon (Android)
      Pushy.setNotificationIcon('ic_notification');

      // Register the user for push notifications
      Pushy.register(function (err, deviceToken) {
        if (err) {
          return console.log(err);
        }
        console.log('Pushy device token: ' + deviceToken);
        that.DeviceID = deviceToken;
        console.log("Device ID" + that.DeviceID);
      });

      // Enable in-app notification banners (iOS 10+)
      Pushy.toggleInAppBanner(true);

      // Listen for push notifications
      // Pushy.setNotificationListener(function (data) {
      //   console.log('Received notification: ' + data.message);
      //   // Clear iOS app badge number
      //   Pushy.clearBadge();
      // });

      // Optionally call the Pushy.setNotificationClickListener((data) => {}) method from your application to listen for when the user taps your notifications:
      // Listen for notification click
      // Pushy.setNotificationClickListener(function (data) {
      //   console.log('Notification click: ' + data.message);

      //   // Navigate the user to another page or
      //   // execute other logic on notification click
      //   // that.navCtrl.setRoot(NotificationsPage);
      //   // console.log("Wellcome to NotificationsPage")
      // });

    });

    // ============================================================================================================================= //
  }

}