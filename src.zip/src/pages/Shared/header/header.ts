import { Component } from '@angular/core';
import { AlertController, App, IonicApp, IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { DashboardPage } from '../../Supervisor/KPI/dashboard/dashboard';
import { RealizationPage } from '../../Supervisor/KPI/realization/realization';
import { ScpfalistPage } from '../../Supervisor/JCStatus/scpfalist/scpfalist';
import { ScetdelistPage } from '../../Supervisor/JCStatus/scetdelist/scetdelist';
import { ScallocatedytslistPage } from '../../Supervisor/JCStatus/scallocatedytslist/scallocatedytslist';
import { ScwiplistPage } from '../../Supervisor/JCStatus/scwiplist/scwiplist';
import { SconholdlistPage } from '../../Supervisor/JCStatus/sconholdlist/sconholdlist';
import { SccmptedlistPage } from '../../Supervisor/JCStatus/sccmptedlist/sccmptedlist';
import { Sccmptedt5plistPage } from '../../Supervisor/JCStatus/sccmptedt5plist/sccmptedt5plist';
import { Sccmptedt5dlistPage } from '../../Supervisor/JCStatus/sccmptedt5dlist/sccmptedt5dlist';
import { StdashboardPage } from '../../Technician/stdashboard/stdashboard';
import { LoginPage } from '../login/login';
import { StytsPage } from '../../Technician/styts/styts';
import { StwipPage } from '../../Technician/stwip/stwip';
import { StpausedPage } from '../../Technician/stpaused/stpaused';
import { NotificationsPage } from '../notifications/notifications';
import { SctechpausePage } from '../../Supervisor/TechStatus/sctechpause/sctechpause';
import { ScwipdetailsPage } from '../../Supervisor/JCStatus/scwipdetails/scwipdetails';
import { ScallocatedytsdetailsPage } from '../../Supervisor/JCStatus/scallocatedytsdetails/scallocatedytsdetails';
import { SconholddetailsPage } from '../../Supervisor/JCStatus/sconholddetails/sconholddetails';
import { SccmpteddetailsPage } from '../../Supervisor/JCStatus/sccmpteddetails/sccmpteddetails';
import { Sccmptedt5pdetailsPage } from '../../Supervisor/JCStatus/sccmptedt5pdetails/sccmptedt5pdetails';
import { Sccmptedt5ddetailsPage } from '../../Supervisor/JCStatus/sccmptedt5ddetails/sccmptedt5ddetails';
import { ScetdedetailsPage } from '../../Supervisor/JCStatus/scetdedetails/scetdedetails';
import { ScpfadetailsPage } from '../../Supervisor/JCStatus/scpfadetails/scpfadetails';
import { SctechytsPage } from '../../Supervisor/TechStatus/sctechyts/sctechyts';

@IonicPage()
@Component({
  selector: 'page-header',
  templateUrl: 'header.html',
})

export class HeaderPage {

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public app: App,
    public alertCtrl: AlertController,
    public platform: Platform,
    public ionicApp: IonicApp) {

  }

  HomeClick() {

    // if (this.global.UserDetails[0].Designation == 'Floor Supervisor') {
    //   this.navCtrl.setRoot(DashboardPage);
    // }
    // else {
    //   this.navCtrl.setRoot(SejoblistPage);
    // }

  }

  BackButtonClick() {

    const overlayView = this.ionicApp._overlayPortal._views[0];

    if (!(overlayView && overlayView.dismiss)) {

      let nav = this.app.getActiveNavs()[0];
      let activeView = nav.getActive();

      console.log(activeView.name);

      switch (activeView.name) {

        case "LoginPage":
        case "WelcomePage":
          this.platform.exitApp();
          break;

        case "DashboardPage":
        case "StdashboardPage":
          if (!this.global.IsAlertOpen) {
            this.RegistrationBackClick("Are you sure, you want to Logout?");
          }
          break;

        case "UtilizationPage":
        case "RealizationPage":
        case "ProductivityPage":
        case "SctechavlPage":
        case "SctechwiplPage":
        case "SctechytsPage":
        case "SctechpausePage":
        case "ScpfalistPage":
        case "ScetdelistPage":
        case "ScallocatedytslistPage":
        case "ScwiplistPage":
        case "SconholdlistPage":
        case "SccmptedlistPage":
        case "Sccmptedt5plistPage":
        case "Sccmptedt5dlistPage":
          this.navCtrl.setRoot(DashboardPage);
          break;

        case "ProfilePage":
        case "NotificationsPage":
        case "CommunicationPage":
        case "GovernancePage":
          if (this.global.WelcomeNavigateType == 1) {
            this.navCtrl.setRoot(DashboardPage);
          }
          else if (this.global.WelcomeNavigateType == 2 ||
            this.global.WelcomeNavigateType == 3 ||
            this.global.WelcomeNavigateType == 4 ||
            this.global.WelcomeNavigateType == 5) {
            this.navCtrl.setRoot(StdashboardPage);
          }
          break;

        case "StatisticsPage":
          this.navCtrl.setRoot(RealizationPage);
          break;

        case "ScpfadetailsPage":
          this.navCtrl.setRoot(ScpfalistPage);
          break;

        case "ScetdedetailsPage":
          this.navCtrl.setRoot(ScetdelistPage);
          break;

        case "ScallocatedytsdetailsPage":
          this.navCtrl.setRoot(ScallocatedytslistPage);
          break;

        case "ScwipdetailsPage":
          this.navCtrl.setRoot(ScwiplistPage);
          break;

        case "SconholddetailsPage":
          this.navCtrl.setRoot(SconholdlistPage);
          break;

        case "SccmpteddetailsPage":
          this.navCtrl.setRoot(SccmptedlistPage);
          break;

        case "Sccmptedt5pdetailsPage":
          this.navCtrl.setRoot(Sccmptedt5plistPage);
          break;

        case "Sccmptedt5ddetailsPage":
          this.navCtrl.setRoot(Sccmptedt5dlistPage);
          break;

        case "StrealizationPage":
        case "StytsPage":
        case "StwipPage":
        case "StpausedPage":
        case "StcompletedPage":
          this.navCtrl.setRoot(StdashboardPage);
          break;

        case "SctechpdetailsPage":
          this.navCtrl.setRoot(SctechpausePage);
          break;

          case "SctechydetailsPage":
          this.navCtrl.setRoot(SctechytsPage);
          break;

        case "SesearchPage":
        case "SctechlogPage":

          switch (this.global.SESearchPage) {

            case "PFA":
              this.navCtrl.setRoot(ScpfadetailsPage, { data: this.global.SelectedJC });
              break;

            case "WIP":
              this.navCtrl.setRoot(ScwipdetailsPage, { data: this.global.SelectedJC });
              break;

            case "AllocatedYTS":
              this.navCtrl.setRoot(ScallocatedytsdetailsPage, { data: this.global.SelectedJC });
              break;

            case "OnHold":
              this.navCtrl.setRoot(SconholddetailsPage, { data: this.global.SelectedJC });
              break;

            case "Completed":
              this.navCtrl.setRoot(SccmpteddetailsPage, { data: this.global.SelectedJC });
              break;

            case "CompletedT5Pend":
              this.navCtrl.setRoot(Sccmptedt5pdetailsPage, { data: this.global.SelectedJC });
              break;

            case "CompletedT5Done":
              this.navCtrl.setRoot(Sccmptedt5ddetailsPage, { data: this.global.SelectedJC });
              break;

            case "ETDExceeded":
              this.navCtrl.setRoot(ScetdedetailsPage, { data: this.global.SelectedJC });
              break;

            default:
              this.navCtrl.setRoot(LoginPage);
              break;
          }

          break;

        case "StjcdetailsPage":
          if (this.global.CurrentPage == "StytsPage") {
            this.navCtrl.setRoot(StytsPage);
          }
          else if (this.global.CurrentPage == "StwipPage") {
            this.navCtrl.setRoot(StwipPage);
          }
          else if (this.global.CurrentPage == "StpausedPage") {
            this.navCtrl.setRoot(StpausedPage);
          }
          break;

        case "ModalCmp":
          break;

        default:
          this.navCtrl.setRoot(LoginPage);
          break;

      }

    }

  }

  LogoutClick() {
    if (!this.global.IsAlertOpen) {
      this.RegistrationBackClick("Are you sure, you want to Logout?");
    }
  }

  RegistrationBackClick(msg) {

    this.global.IsAlertOpen = true;

    const confirm = this.alertCtrl.create({
      title: "Confirm",
      message: msg,
      buttons: [
        {
          text: 'No',
          cssClass: "BtnTwoPopup",
          handler: () => {
            this.global.IsAlertOpen = false;
          }
        },
        {
          text: 'Yes',
          cssClass: "BtnTwoPopup",
          handler: () => {
            this.navCtrl.setRoot(LoginPage);
            this.global.IsAlertOpen = false;
            localStorage.clear();
          }
        }
      ],
      enableBackdropDismiss: false
    });

    confirm.present();

  }

  NotificationClick() {
    this.navCtrl.setRoot(NotificationsPage);
    //this.global.ToastShow("Coming soon...");
  }

}