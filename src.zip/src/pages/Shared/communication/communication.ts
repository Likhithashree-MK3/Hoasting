import { Component } from '@angular/core';
import { ActionSheetController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotificationsPage } from '../notifications/notifications';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { CalendarComponentOptions } from 'ion2-calendar';

@IonicPage()
@Component({
  selector: 'page-communication',
  templateUrl: 'communication.html',
})

export class CommunicationPage {

  SelectedFilter = "2";
  SelectedFilterName = "Last 7 Days";
  SearchFromDate: any;
  SearchToDate: any;
  CommunicationList: any = [];
  FinalCommunicationList: any = [];
  Last6Month: any;
  TodaysDate: any;
  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    color: "danger",
    from: new Date().setDate(new Date().getDate() - 30),
    to: new Date()
  };
  options: InAppBrowserOptions;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public actionSheetCtrl: ActionSheetController,
    public httpClient: HttpClient,
    private iab: InAppBrowser) {

    this.global.HeaderTitle = "Communication Section";

    let date = new Date();

    this.TodaysDate = date.getFullYear() + "-" + ((date.getMonth() + 1) > 9 ? (date.getMonth() + 1) : ("0" + (date.getMonth() + 1))) + "-" + ((date.getDate() + 1) > 9 ? (date.getDate()) : ("0" + (date.getDate())));

  }

  ngOnInit(val) {

    let fromDate;
    let toDate;

    if (this.SelectedFilter == "6") {
      let d1 = new Date(this.SearchFromDate);
      fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
      let d2 = new Date(this.SearchToDate);
      toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
    }
    else {
      fromDate = this.TodaysDate;
      toDate = this.TodaysDate;
    }

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetCommunicationDetailsList?Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(commList => {

        if (commList.StatusCode == 200) {

          this.CommunicationList = JSON.parse(commList.Output);

          console.log(this.CommunicationList);

          this.FinalCommunicationList = Object.assign([], this.CommunicationList);

          if (val != undefined) {
            val.complete();
          }

        }
        else {
          console.log(commList);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  OnClickOpenPDF(item) {

    console.log(item);

    this.options = {
      location: 'no',//Or 'no' 
      hidden: 'no', //Or  'yes'
      zoom: 'yes',//Android only ,shows browser zoom controls 
      hideurlbar: 'yes',//Or 'no'
    }

    let path = this.global.HostedPath.split("api")[0];

    let url = encodeURIComponent(path + "UploadedFiles/Communication/" + item.FilePath);

    this.iab.create('https://docs.google.com/viewer?url=' + url, "_blank", this.options);

    //window.location.href = path + "UploadedFiles/Communication/" + item.FilePath;

  }

  backToNotification() {
    this.navCtrl.setRoot(NotificationsPage)
  }

  FilterClick1() {

    let actionSheet = this.actionSheetCtrl.create({

      title: 'Select filter option',
      buttons: [
        {
          text: 'Last Day',
          handler: () => {
            this.SelectedFilter = "1";
            this.SelectedFilterName = "Last Day";
            // this.ngOnInit();
          }
        },
        {
          text: 'Last 7 Days',
          handler: () => {
            this.SelectedFilter = "2";
            this.SelectedFilterName = "Last 7 Days";
            // this.ngOnInit();
          }
        },
        {
          text: 'MTD',
          handler: () => {
            this.SelectedFilter = "3";
            this.SelectedFilterName = "MTD";
            // this.ngOnInit();
          }
        },
        {
          text: 'LM',
          handler: () => {
            this.SelectedFilter = "4";
            this.SelectedFilterName = "Last Month";
            // this.ngOnInit();
          }
        },
        {
          text: 'YTD',
          handler: () => {
            this.SelectedFilter = "5";
            this.SelectedFilterName = "YTD";
            // this.ngOnInit();
          }
        },
        {
          text: 'Date Range',
          handler: () => {
            this.SelectedFilter = "6";
            this.SelectedFilterName = "Date Range";
          }
        }
      ],
      enableBackdropDismiss: true
    });

    actionSheet.present();

  }

  FilterClick() {

    this.global.iscardOpen = !this.global.iscardOpen;

    this.global.FilterList.filter((a) => a.isSelected = false);

    this.global.FilterList.filter((a) => a.id == this.SelectedFilter)[0].isSelected = true;

}

  FilterListClick(val) {

    this.global.FilterList.filter((a) => a.isSelected = false);
    val.isSelected = true;
    this.SelectedFilter = val.id;

    if (val.id == 6) {
      this.optionsRange.from = new Date().setDate(new Date().getDate() - 30);
      this.optionsRange.to = new Date()
    }

  }

  FilterApplyClick() {

    if (this.SelectedFilter == "6") {

      if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
        && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

        this.global.iscardOpen = !this.global.iscardOpen;
        this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
        this.ngOnInit(undefined);

      }
      else {
        this.global.ToastShow("Please enter From date and To date");
      }

    }
    else {
      this.global.iscardOpen = !this.global.iscardOpen;
      this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
      this.ngOnInit(undefined);
    }

  }

  FilterResetClick() {

    this.SelectedFilter = "2";
    this.SelectedFilterName = "Last 7 Days";
    this.global.FilterList[1].isSelected = true;
    this.ngOnInit(undefined);

  }

  DateRangeChange(val) {
    console.log(val);
    this.SearchFromDate = val.from._i;
    this.SearchToDate = val.to._i;
  }

  CalenderStartClick(val) {

    console.log(val);

    //this.optionsRange.from = new Date(val.time).setDate(new Date().getDate() - 30);

    this.optionsRange.from = new Date(new Date().setDate(new Date().getDate() - 60));

    console.log(this.optionsRange);

  }

}
