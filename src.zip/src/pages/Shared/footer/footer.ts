import { Component } from '@angular/core';
import { App, IonicApp, IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { DashboardPage } from '../../Supervisor/KPI/dashboard/dashboard';
import { StdashboardPage } from '../../Technician/stdashboard/stdashboard';
import { CommunicationPage } from '../communication/communication';
import { GovernancePage } from '../governance/governance';

@IonicPage()
@Component({
  selector: 'page-footer',
  templateUrl: 'footer.html',
})

export class FooterPage {

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public app: App,
    public ionicApp: IonicApp,
    public global: GlobalProvider) {
  }

  DashboardClick() {

    let that = this;

    const overlayView = this.ionicApp._overlayPortal._views[0];

    if (!(overlayView && overlayView.dismiss)) {

      let nav = this.app.getActiveNavs()[0];
      let activeView = nav.getActive();

      console.log(activeView.name);

      if (activeView.name == "ModalCmp") {

        this.viewCtrl.dismiss();

        setTimeout(() => {

          if (that.global.WelcomeNavigateType == 1) {
            that.navCtrl.setRoot(DashboardPage);
          }
          else if (that.global.WelcomeNavigateType == 2 || that.global.WelcomeNavigateType == 3) {
            that.navCtrl.setRoot(StdashboardPage);
          }

        }, 500);

      }
      else {

        if (this.global.WelcomeNavigateType == 1) {
          this.navCtrl.setRoot(DashboardPage);
        }
        else if (this.global.WelcomeNavigateType == 2 ||
          this.global.WelcomeNavigateType == 3 ||
          this.global.WelcomeNavigateType == 4 ||
          this.global.WelcomeNavigateType == 5) {
          this.navCtrl.setRoot(StdashboardPage);
        }

      }

    }

  }

  CommunicationClick() {

    let that = this;

    const overlayView = this.ionicApp._overlayPortal._views[0];

    if (!(overlayView && overlayView.dismiss)) {

      let nav = this.app.getActiveNavs()[0];
      let activeView = nav.getActive();

      console.log(activeView.name);

      if (activeView.name == "ModalCmp") {

        this.viewCtrl.dismiss();

        setTimeout(() => {

          that.navCtrl.setRoot(CommunicationPage);

        }, 500);

      }
      else {
        this.navCtrl.setRoot(CommunicationPage);
      }

    }

  }

  GovernanceClick() {

    let that = this;

    const overlayView = this.ionicApp._overlayPortal._views[0];

    if (!(overlayView && overlayView.dismiss)) {

      let nav = this.app.getActiveNavs()[0];
      let activeView = nav.getActive();

      console.log(activeView.name);

      if (activeView.name == "ModalCmp") {

        this.viewCtrl.dismiss();

        setTimeout(() => {

          that.navCtrl.setRoot(GovernancePage);

        }, 500);

      }
      else {
        this.navCtrl.setRoot(GovernancePage);
      }

    }

  }

}