import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, ToastController } from 'ionic-angular';
import { CommunicationPage } from '../communication/communication';
import { DashboardPage } from '../../Supervisor/KPI/dashboard/dashboard';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { SconholddetailsPage } from '../../Supervisor/JCStatus/sconholddetails/sconholddetails';
import { ScpfalistPage } from '../../Supervisor/JCStatus/scpfalist/scpfalist';
import { ScallocatedytsdetailsPage } from '../../Supervisor/JCStatus/scallocatedytsdetails/scallocatedytsdetails';
import { StytsPage } from '../../Technician/styts/styts';

@IonicPage()
@Component({
  selector: 'page-notifications',
  templateUrl: 'notifications.html',
})

export class NotificationsPage {

  isAlertOpen: boolean;
  isNotificationOpen: boolean;
  isOverflow: boolean = false;
  AlertSelectedMessageIDs: number[] = [];
  NotificationSelectedMessageIDs: number[] = [];
  isSelectAllAlertChecked: boolean = false;
  isSelectAllNotificationChecked: boolean = false;
  maxLengthOfMessage: number = 40;
  searchText: string = '';
  filteredAlertMessages: any[] = [];
  filteredNotificationMessages: any[] = [];
  matchingItems: string[] = ['High', 'Medium', 'Low'];
  checkedItems: { [key: string]: boolean } = {};
  previousCheckedItems: { [key: string]: boolean } = {};
  finalCheckedItems: { [key: string]: boolean } = {};
  checkedItemsCount: number = 0;
  AlertMessagesReadingCount: number = 0;
  NotificationMessagesReadingCount: number = 0;
  alertMessages: any = [];
  notificationMessage: any = [];

  SeverityFilterList: any = [{
    name: "High",
    isSelected: false,
    color: "red"
  },
  {
    name: "Medium",
    isSelected: false,
    color: "orange "
  },
  {
    name: "Low",
    isSelected: false,
    color: "Yellow"
  }]
  iscardOpen: boolean = false;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public alertCtrl: AlertController,
    public httpClient: HttpClient,
    public toastCtrl: ToastController) {

    this.global.HeaderTitle = "Notification";

    this.isAlertOpen = true;
    this.isNotificationOpen = false;

  }

  ngOnInit() {

    if (this.global.CheckInternetConnection()) {

      // this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetAlertDetailsList?EmployeeID=" + this.global.UserDetails[0].Employee_IC).subscribe(commList => {

        if (commList.StatusCode == 200) {

          this.alertMessages = JSON.parse(commList.Output);

          console.log("alertMessages List");
          console.log(this.alertMessages);
          this.filteredAlertMessages = Object.assign([], this.alertMessages);
          this.ReadingCountAlertMessages();

        }
        else {
          console.log(commList);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

      }, (error) => {
        console.log(error);
      });

      // ========================================================= NOTIFICATION LIST ===================================================== // 
      this.httpClient.get<any>(this.global.HostedPath + "GetNotificationDetailsList?EmployeeID=" + this.global.UserDetails[0].Employee_IC).subscribe(commList => {

        if (commList.StatusCode == 200) {

          this.notificationMessage = JSON.parse(commList.Output);

          console.log("notificationMessage List");
          console.log(this.notificationMessage);
          this.filteredNotificationMessages = Object.assign([], this.notificationMessage);
          this.ReadingCountNotificationMessages();
        }
        else {
          console.log(commList);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

      }, (error) => {
        console.log(error);
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  //ALERT PAGE
  openAlertMessages() {

    this.isAlertOpen = true;
    this.isNotificationOpen = false;
    this.isSelectAllAlertChecked = false;
    this.isSelectAllNotificationChecked = false;

  }

  //NOTIFICATION PAGE 
  openNotificationMessages() {
    // alert("Notification");
    this.isAlertOpen = false;
    this.isNotificationOpen = true;
    this.isSelectAllAlertChecked = false;
    this.isSelectAllNotificationChecked = false;
    // this.AlertSelectedMessageIDs = [];
    // this.NotificationSelectedMessageIDs = [];
  }

  //SELECTED MESSAGES IDs STORING IN ARRAY
  AlertSelectedMessage(id: number) {

    let index = this.AlertSelectedMessageIDs.indexOf(id);
    if (index > -1) {
      this.AlertSelectedMessageIDs.splice(index, 1);      // Remove The ID if already selected
    } else {
      this.AlertSelectedMessageIDs.push(id);            // Add ID The if not selected
    }
    console.log(this.AlertSelectedMessageIDs);
  }

  // SELECT ALL AND STORE ALL MESSAGES IDs IN ARRAY
  SelectAllAlertMessages() {

    if (!this.isSelectAllAlertChecked) {

      this.AlertSelectedMessageIDs = [];
      for (let item of this.alertMessages) {

        let index = this.AlertSelectedMessageIDs.indexOf(item.Alert_IC);
        if (index > -1) {
          this.AlertSelectedMessageIDs.splice(index, 1);      // Remove The ID if already selected
        } else {
          this.AlertSelectedMessageIDs.push(item.Alert_IC);            // Add ID The if not selected
        }
      }
      console.log(this.AlertSelectedMessageIDs);
      this.isSelectAllAlertChecked = true;
    }
    else {
      this.AlertSelectedMessageIDs = [];
      console.log(this.AlertSelectedMessageIDs);
      this.isSelectAllAlertChecked = false;
    }


  }

  deleteAlerts() {

    // alert("Delete Alert");
    if (this.AlertSelectedMessageIDs.length != 0) {

      const confirm = this.alertCtrl.create({
        // title: 'Use this lightsaber?',
        message: 'Are you sure you want to delete selected Messages?',
        cssClass: 'buttonCss',
        buttons: [
          {
            text: 'Cancel',
            handler: () => {
              console.log('Cancel clicked');
            }
          },
          {
            text: 'Yes',
            handler: () => {

              this.httpClient.post(this.global.HostedPath + "DeleteAlertMessage?AlertSelectedAlert_ICs=" + this.AlertSelectedMessageIDs, null).subscribe((success) => {

                console.log(this.AlertSelectedMessageIDs + " These IDs Alerts Messages are Deleted Sucessfully:");
                this.ngOnInit();
                this.ReadingCountAlertMessages();
                this.AlertSelectedMessageIDs = [];
                console.log(this.alertMessages);
              }, (error) => {
                console.log(`Failed To Delete Alert Message:`, error);
              });

            }
          }
        ]
      });
      confirm.present();
    }
    else {
      this.ShowToastMessage("Please select message to delete!", "bottom");
    }
  }

  ShowToastMessage(message: string, position: string) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 2000,
      position: position
    });

    toast.present(toast);
  }

  // SELECTED NOTIFICATIONS IDs STORING IN ARRAY
  NotificationSelectedMessage(id: number) {

    let index = this.NotificationSelectedMessageIDs.indexOf(id);
    if (index > -1) {
      this.NotificationSelectedMessageIDs.splice(index, 1);      // Remove The ID if already selected
    } else {
      this.NotificationSelectedMessageIDs.push(id);            // Add ID The if not selected
    }
    console.log(this.NotificationSelectedMessageIDs);
  }

  // SELECT ALL AND STORE ALL NOTIFICATIONS IDs IN ARRAY
  SelectAllNotificationMessages() {

    if (!this.isSelectAllNotificationChecked) {

      this.NotificationSelectedMessageIDs = [];
      for (let item of this.notificationMessage) {

        let index = this.NotificationSelectedMessageIDs.indexOf(item.Notification_IC);
        if (index > -1) {
          this.NotificationSelectedMessageIDs.splice(index, 1);      // Remove The ID if already selected
        } else {
          this.NotificationSelectedMessageIDs.push(item.Notification_IC);            // Add ID The if not selected
        }
      }
      console.log(this.NotificationSelectedMessageIDs);
      this.isSelectAllNotificationChecked = true;
    }
    else {
      this.NotificationSelectedMessageIDs = [];
      console.log(this.NotificationSelectedMessageIDs);
      this.isSelectAllNotificationChecked = false;
    }
  }

  deleteNotifications() {
    // alert("Delete Notifications");
    if (this.NotificationSelectedMessageIDs.length != 0) {

      const confirm = this.alertCtrl.create({
        // title: 'Use this lightsaber?',
        message: 'Are you sure you want to delete selected Notification?',
        cssClass: 'buttonCss',
        buttons: [
          {
            text: 'Cancel',
            handler: () => {
              console.log('Cancel clicked');
            }
          },
          {
            text: 'Yes',
            handler: () => {
              // for (let id of this.NotificationSelectedMessageIDs) {

              //   const index = this.notificationMessage.findIndex(Description => Description.Notification_IC === id);
              //   // If the id exists, remove it from the array
              //   if (index !== -1) {
              //     this.notificationMessage.splice(index, 1);
              //   }
              // }

              this.httpClient.post(this.global.HostedPath + "DeleteNotificationMessage?NotificationSelectedNotification_ICs=" + this.NotificationSelectedMessageIDs, null).subscribe((success) => {

                console.log(this.NotificationSelectedMessageIDs + " These IDs Notification Messages are Deleted Sucessfully:");
                this.ngOnInit();
                this.ReadingCountNotificationMessages
                this.NotificationSelectedMessageIDs = [];
                console.log(this.notificationMessage);

              }, (error) => {
                console.log(`Failed To Delete Alert Message:`, error);
              });

            }
          }
        ]
      });
      confirm.present();
    }
    else {
      this.ShowToastMessage("Please select Notification to delete!", "bottom");
    }
  }

  //ALERT AUTO CHECK 
  isAlertMessageSelected(id: number): boolean {
    return this.AlertSelectedMessageIDs.indexOf(id) !== -1;
  }

  //NOTIFICATION AUTO CHECK
  isNotificationMessageSelected(id: number): boolean {
    return this.NotificationSelectedMessageIDs.indexOf(id) !== -1;
  }

  //SEARCH MESSAGE 
  filterAlertMessages() {
    if (this.searchText.trim() === '') {
      this.filteredAlertMessages = this.alertMessages; // If search text is empty, show all messages
    } else {
      this.filteredAlertMessages = this.alertMessages.filter(message =>
        message.JobcardNumber.toLowerCase().includes(this.searchText.toLowerCase()) ||
        message.Description.toLowerCase().includes(this.searchText.toLowerCase())
      ); // Filter messages based on JobcardNumber or Description
    }
  }

  //SEARCH NOTIFICATION
  filterNotificationMessages() {
    if (this.searchText.trim() === '') {
      this.filteredNotificationMessages = this.notificationMessage; // If search text is empty, show all messages
    } else {
      this.filteredNotificationMessages = this.notificationMessage.filter(message =>
        message.JC_Number.toLowerCase().includes(this.searchText.toLowerCase()) ||
        message.Description.toLowerCase().includes(this.searchText.toLowerCase())
      ); // Filter messages based on JC_Number or Description 
    }
  }

  //COUNT - READ AND UNREAD
  ReadingCountAlertMessages() {

    this.AlertMessagesReadingCount = 0;
    for (let i of this.alertMessages) {
      if (i.IsRead == false) {
        this.AlertMessagesReadingCount++;
      }
    }
    console.log("AlertMessagesReadingCount : " + this.AlertMessagesReadingCount);
  }

  ReadingCountNotificationMessages() {

    this.NotificationMessagesReadingCount = 0;
    for (let i of this.notificationMessage) {
      if (i.IsRead == false) {
        this.NotificationMessagesReadingCount++;
      }
    }
    console.log("NotificationMessagesReadingCount : " + this.NotificationMessagesReadingCount);

  }

  //ALERT - READ AND UNREAD
  alertReadMessage(item) {
    item.IsRead = true;
    // UPDATE ALERT ISREAD COLUMN // 
    this.httpClient.post(this.global.HostedPath + "UpdateAlertReadMessage?Alert_IC=" + item.Alert_IC, null).subscribe((success) => {

      // ONCLICK NOTIFICATION NAVIGATION
      let JC = { JobCardHedIC: item.JobcardHeader_IC }

      if (item.Description.includes('Diagnosis Issue')) {                         // Diagnosis Issue

        console.log('Notification click Description Contain - Diagnosis Issue');
        // this.navCtrl.setRoot(SconholdlistPage); 
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('Pending for Allocation')) {            // Pending for Allocation

        console.log('Notification click Description Contain - Pending for Allocation');
        // this.navCtrl.setRoot(ScpfalistPage);
        if (this.global.IsManager) {
          this.navCtrl.setRoot(ScpfalistPage);
        }
      }
      else if (item.Description.includes('YTS')) {                              // YTS

        console.log('Notification click Description Contain - YTS');
        // this.navCtrl.setRoot(ScallocatedytslistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(ScallocatedytsdetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('has been allocated')) {             // JC# has been allocated

        console.log('Notification click Description Contain - has been allocated');
        this.navCtrl.setRoot(StytsPage);

      }
      // END ONCLICK NOTIFICATION NAVIGATION

    }, (error) => {
      console.log(`Failed To Read Alert Message:`, error);
    });
  }

  //NOTIFICATION - READ AND UNREAD
  notificationReadMessage(item) {
    item.IsRead = true;
    // UPDATE ALERT ISREAD COLUMN // 
    this.httpClient.post<any>(this.global.HostedPath + "UpdateNotificationReadMessage?Notification_IC=" + item.Notification_IC, null).subscribe((success) => {

      // ONCLICK NOTIFICATION NAVIGATION
      let JC = { JobCardHedIC: item.JC_Header_ID }

      if (item.Description.includes('No Job is assigned')) {             // No Job is assigned

        console.log('Notification click Description Contain - No Job is assigned');
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(ScpfalistPage);
        }
      }
      else if (item.Description.includes('Ancillary')) {                      // Ancillary

        console.log('Notification click Description Contain - Ancillary');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('working on another vehicle')) {     // working on another vehicle

        console.log('Notification click Description Contain - working on another vehicle');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('Shift Change alert')) {             // Shift Change alert

        console.log('Notification click Description Contain - Shift Change alert');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('Tea break')) {                    // Tea break

        console.log('Notification click Description Contain - Tea break');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('Bio break')) {                    // Bio break

        console.log('Notification click Description Contain - Bio break');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      else if (item.Description.includes('Lunch break')) {                // Lunch break

        console.log('Notification click Description Contain - Lunch break');
        // this.navCtrl.setRoot(SconholdlistPage);
        if (!this.global.IsManager) {
          this.navCtrl.setRoot(SconholddetailsPage, { data: JC });
        }
      }
      // END ONCLICK NOTIFICATION NATIGATION

    }, (error) => {
      console.log(`Failed To Read Notifications Message:`, error);
    });
  }

  //BACKTO DASHBOARD
  backToDashBoard() {
    this.navCtrl.setRoot(DashboardPage);
  }

  //GO TO COMMUNICATION 
  CommunicationClick() {
    this.navCtrl.setRoot(CommunicationPage);
  }

  //SHOW MORE
  AlertshowFullMessage(item: any) {
    // item.isClickOnViewMore = !item.isClickOnViewMore;
    this.httpClient.post<any>(this.global.HostedPath + "UpdateAlertisClickOnViewMore?Alert_IC=" + item.Alert_IC + "&isClickOnViewMore=" + !item.isClickOnViewMore, null).subscribe((success) => {

      this.ngOnInit();
    }, (error) => {
      console.log(`Failed To Alert View More Messages:`, error);
    });
  }

  NotificationshowFullMessage(item: any) {
    // item.isClickOnViewMore = !item.isClickOnViewMore;
    this.httpClient.post<any>(this.global.HostedPath + "UpdateNotificationisClickOnViewMore?Notification_IC=" + item.Notification_IC + "&isClickOnViewMore=" + !item.isClickOnViewMore, null).subscribe((success) => {

      this.ngOnInit();
    }, (error) => {
      console.log(`Failed To Notification View More Messages:`, error);
    });
  }

  FilterClick() {

    this.iscardOpen = !this.iscardOpen;

  }

  FilterApplyClick() {

    this.previousCheckedItems = { ...this.checkedItems };
    this.finalCheckedItems = { ...this.checkedItems };

    let that = this;

    this.filteredNotificationMessages = [];
    this.notificationMessage.filter(a => {

      let v = that.checkedItems.hasOwnProperty(a.Priority);

      if (v && this.finalCheckedItems[a.Priority]) {
        that.filteredNotificationMessages.push({
          Notification_IC: a.Notification_IC,
          JC_Header_ID: a.JC_Header_ID,
          Employee_ID: a.Employee_ID,
          JC_Number: a.JC_Number,
          Vehicle_No: a.Vehicle_No,
          JC_CreationDate: a.JC_CreationDate,
          NotificationsentTime: a.NotificationsentTime,
          Description: a.Description,
          IsRead: a.IsRead,
          IsSend: a.IsSend,
          isClickOnViewMore: a.isClickOnViewMore,
          Priority: a.Priority
        });
      }

    });

    console.log(this.filteredNotificationMessages);

    this.filteredAlertMessages = [];
    this.alertMessages.filter(a => {

      let v = that.checkedItems.hasOwnProperty(a.Priority);

      if (v && this.finalCheckedItems[a.Priority]) {
        that.filteredAlertMessages.push({
          Alert_IC: a.Alert_IC,
          JobcardHeader_IC: a.JobcardHeader_IC,
          JobcardNumber: a.JobcardNumber,
          LicensePlateNumber: a.LicensePlateNumber,
          Employee_ID: a.Employee_ID,
          JC_CreationDate: a.JC_CreationDate,
          NotificationsentTime: a.NotificationsentTime,
          Description: a.Description,
          IsRead: a.IsRead,
          IsSend: a.IsSend,
          isClickOnViewMore: a.isClickOnViewMore,
          Priority: a.Priority
        });
      }

    });

    console.log(this.filteredAlertMessages);


    // CLOSING MODEL
    this.iscardOpen = !this.iscardOpen;

  }

  FilterResetClick() {

    this.filteredNotificationMessages = Object.assign([], this.notificationMessage);
    this.filteredAlertMessages = Object.assign([], this.alertMessages);

    this.finalCheckedItems = {};
    this.checkedItems = {};

    // CLOSING MODEL 
    this.iscardOpen = !this.iscardOpen;

  }

  FilterCloseClick() {

    this.checkedItems = { ...this.previousCheckedItems };

    this.finalCheckedItems = Object.assign({}, this.checkedItems);

    // CLOSING MODEL
    this.iscardOpen = !this.iscardOpen;

  }

  //REMOVE FILTER
  removeItem(item: string) {

    delete this.checkedItems[item];

    console.log(this.checkedItems);

    if (Object.keys(this.checkedItems).length == 0) {

      this.filteredNotificationMessages = Object.assign([], this.notificationMessage);
      this.filteredAlertMessages = Object.assign([], this.alertMessages);

      this.previousCheckedItems = Object.assign({}, this.checkedItems)

      this.finalCheckedItems = {};

    }
    else {

      this.previousCheckedItems = { ...this.checkedItems };
      this.finalCheckedItems = { ...this.checkedItems };
      let that = this;

      this.filteredNotificationMessages = [];
      this.notificationMessage.filter(a => {

        let v = that.checkedItems.hasOwnProperty(a.Priority);

        if (v && this.finalCheckedItems[a.Priority]) {
          that.filteredNotificationMessages.push({
            Notification_IC: a.Notification_IC,
            JC_Header_ID: a.JC_Header_ID,
            Employee_ID: a.Employee_ID,
            JC_Number: a.JC_Number,
            Vehicle_No: a.Vehicle_No,
            JC_CreationDate: a.JC_CreationDate,
            NotificationsentTime: a.NotificationsentTime,
            Description: a.Description,
            IsRead: a.IsRead,
            IsSend: a.IsSend,
            isClickOnViewMore: a.isClickOnViewMore,
            Priority: a.Priority
          });
        }

      });

      this.filteredAlertMessages = [];
      this.alertMessages.filter(a => {

        let v = that.checkedItems.hasOwnProperty(a.Priority);

        if (v && this.finalCheckedItems[a.Priority]) {
          that.filteredAlertMessages.push({
            Alert_IC: a.Alert_IC,
            JobcardHeader_IC: a.JobcardHeader_IC,
            JobcardNumber: a.JobcardNumber,
            LicensePlateNumber: a.LicensePlateNumber,
            Employee_ID: a.Employee_ID,
            JC_CreationDate: a.JC_CreationDate,
            NotificationsentTime: a.NotificationsentTime,
            Description: a.Description,
            IsRead: a.IsRead,
            IsSend: a.IsSend,
            isClickOnViewMore: a.isClickOnViewMore,
            Priority: a.Priority
          });
        }

      });

    }

  }

}