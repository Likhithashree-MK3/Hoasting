import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StpausedPage } from './stpaused';

@NgModule({
  declarations: [
    StpausedPage,
  ],
  imports: [
    IonicPageModule.forChild(StpausedPage),
  ],
})
export class StpausedPageModule {}
