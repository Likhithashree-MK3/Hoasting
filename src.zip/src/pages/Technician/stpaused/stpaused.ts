import { Component } from '@angular/core';
import { AlertController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { StdashboardPage } from '../stdashboard/stdashboard';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { StjcdetailsPage } from '../stjcdetails/stjcdetails';

@IonicPage()
@Component({
  selector: 'page-stpaused',
  templateUrl: 'stpaused.html',
})

export class StpausedPage {

  PausedList: any = [];
  PausedListCopy: any = [];
  SrchText: string;
  IsSorted: boolean = false;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public global: GlobalProvider,
    public httpClient: HttpClient) {

    this.global.HeaderTitle = "Paused";

  }

  ngOnInit(refresher) {
    if (this.global.CheckInternetConnection()) {
      console.log(this.global.UserDetails)
      this.global.LoadingShow("Please wait...");
      this.CallListData();
      this.global.LoadingHide();
      if (refresher != undefined) {
        refresher.complete();
      }
    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }
  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(StdashboardPage);
  }

  StartClick(e) {
    console.log(e);
    const confirm = this.alertCtrl.create({
      title: 'Do you want to Start the job ?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          cssClass: 'BtnCancelPopup',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          cssClass: 'BtnYesPopup',
          handler: () => {
            console.log('Agree clicked');
            if (this.global.CheckInternetConnection()) {

              this.httpClient.post<any>(this.global.HostedPath + "UpdateOnStart?TechnicianID=" + this.global.UserDetails[0].Employee_IC + "&JobCardHeaderIC=" + e.JobCardHedIC, {}).subscribe(result => {
                console.log(result);
                if (result.StatusCode == 200) {
                  this.CallListData();
                  this.global.ToastShow("Job Started");
                  // this.ngOnInit(undefined);
                }
                else if (result.StatusCode == 0) {

                  this.global.ToastShow("Please close Previous job to start new JC");
                  // this.ngOnInit(undefined);

                }
                else {
                  console.log(result);
                  this.global.ToastShow("Something went wrong, Pls try again later");
                }

              }, (error) => {
                console.log(error);
              });

            }
            else {
              this.global.ToastShow(this.global.NetworkMessage);
            }
          }
        }
      ]
    });
    confirm.present();
  }

  CallListData() {

    this.httpClient.get<any>(this.global.HostedPath + "GetTechPaused?Technician_ID=" + this.global.UserDetails[0].Employee_IC
    ).subscribe(list => {

      if (list.StatusCode == 200) {

        this.PausedList = JSON.parse(list.Output);
        console.log(this.PausedList);

        this.PausedListCopy = Object.assign([], this.PausedList);

      }
      else {
        console.log(list);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }
    }, (error) => {
      console.log(error);
      this.global.LoadingHide();
    });

  }

  Search() {
    console.log(this.SrchText)
    this.PausedList = this.PausedListCopy.filter(
      p => p.Jobtype.toLowerCase().trim().includes(this.SrchText.toLowerCase().trim()) ||
        p.OrderNo.toString().includes(this.SrchText.trim()) ||
        p.VehicleNo.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.IsAppointmentDone.toString().includes(this.SrchText.trim()) ||
        p.CustomerName.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.ServiceAdvisor.toString().includes(this.SrchText.trim()) ||
        p.Ageing.toString().includes(this.SrchText.trim()) ||
        p.T1.toString().includes(this.SrchText.trim()) ||
        p.EDD.toString().includes(this.SrchText.trim()) ||
        p.ETD.toString().includes(this.SrchText.trim()) ||
        p.PauseReason.toLowerCase().includes(this.SrchText.toLowerCase().trim())
    );
    console.log(this.PausedList);
  }

  JCClick(jc) {

    this.global.CurrentPage = "StpausedPage";

    this.navCtrl.setRoot(StjcdetailsPage, { data: jc })

  }

  SortClick() {

    if (!this.IsSorted) {
      this.PausedList.sort((a, b) => new Date(a.T1).valueOf() - new Date(b.T1).valueOf());
      this.IsSorted = true;
    }
    else {
      this.PausedList = Object.assign([], this.PausedListCopy);
      this.IsSorted = false;
    }

    console.log(this.PausedList);

  }

}
