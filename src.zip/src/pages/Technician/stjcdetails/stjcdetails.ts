import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';

@IonicPage()
@Component({
  selector: 'page-stjcdetails',
  templateUrl: 'stjcdetails.html',
})

export class StjcdetailsPage {

  SelectedJC: any = {};
  SelectedSEList: any = [];

  JobDetails: any = {};
  JobsList: any = [];

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public httpClient: HttpClient) {

    this.SelectedJC = this.navParams.get("data");

    this.global.HeaderTitle = "JC " + this.SelectedJC.OrderNo;

    console.log(this.SelectedJC);

  }

  ngOnInit() {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetJobCardDetails?JobCardID=" + this.SelectedJC.JobCardHedIC).subscribe(jobs => {

        if (jobs.StatusCode == 200) {

          this.JobDetails = JSON.parse(jobs.Output).JobCardOrderDetails;
          this.JobsList = JSON.parse(jobs.Output).GetJCJobDetails; this.SelectedSEList = JSON.parse(jobs.Output).GetJobCardTechnicianList;

          console.log(JSON.parse(jobs.Output));

        }
        else {
          console.log(jobs);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

}
