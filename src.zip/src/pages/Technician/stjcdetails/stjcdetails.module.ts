import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StjcdetailsPage } from './stjcdetails';

@NgModule({
  declarations: [
    StjcdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(StjcdetailsPage),
  ],
})
export class StjcdetailsPageModule {}
