import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StcompletedPage } from './stcompleted';

@NgModule({
  declarations: [
    StcompletedPage,
  ],
  imports: [
    IonicPageModule.forChild(StcompletedPage),
  ],
})
export class StcompletedPageModule {}
