import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { StdashboardPage } from '../stdashboard/stdashboard';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';

@IonicPage()
@Component({
  selector: 'page-stcompleted',
  templateUrl: 'stcompleted.html',
})

export class StcompletedPage {

  clickedindex: any;
  DisplayRow: boolean = false;

  CompletedList: any = [];
  CompletedListCopy: any = [];
  SrchText: string;
  IsSorted: boolean = false;
  //Initialize an array to keep track of the display state of each item
  itemDisplayStates: boolean[] = [];

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public httpClient: HttpClient) {

    this.global.HeaderTitle = "Completed";

  }

  ngOnInit(refresher) {

    if (this.global.CheckInternetConnection()) {
      console.log(this.global.UserDetails)
      this.global.LoadingShow("Please wait...");
      this.CallListData();
      this.global.LoadingHide();
      if (refresher != undefined) {
        refresher.complete();
      }
    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(StdashboardPage);
  }

  ViewClick1(ind) {
    this.DisplayRow = !this.DisplayRow;
    this.clickedindex = ind;
  }

  ViewClick(ind: number) {
    // Toggle the display state of the clicked item
    this.itemDisplayStates[ind] = !this.itemDisplayStates[ind];

  }

  CallListData() {

    this.httpClient.get<any>(this.global.HostedPath + "GetTechCompleted?Technician_ID=" + this.global.UserDetails[0].Employee_IC).subscribe(list => {

      if (list.StatusCode == 200) {

        this.CompletedList = JSON.parse(list.Output);

        console.log(this.CompletedList);
        this.CompletedListCopy = Object.assign([], this.CompletedList);

      }
      else {
        console.log(list);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
      this.global.LoadingHide();
    });
  }

  Search() {

    console.log(this.SrchText)
    this.CompletedList = this.CompletedListCopy.filter(
      p => p.Jobtype.toLowerCase().trim().includes(this.SrchText.toLowerCase().trim()) ||
        p.OrderNo.toString().includes(this.SrchText.trim()) ||
        p.VehicleNo.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.CustomerName.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.ServiceAdvisor.toString().includes(this.SrchText.trim()) ||
        p.Ageing.toString().includes(this.SrchText.trim()) ||
        p.T1.toString().includes(this.SrchText.trim()) ||
        p.EDD.toString().includes(this.SrchText.trim()) ||
        p.ETD.toString().includes(this.SrchText.trim()) ||
        p.StartDateTime.toString().includes(this.SrchText.trim()) ||
        p.EndDateTime.toString().includes(this.SrchText.trim())
    );
    console.log(this.CompletedList);

  }

  SortClick() {

    if (!this.IsSorted) {
      this.CompletedList.sort((a, b) => new Date(a.T1).valueOf() - new Date(b.T1).valueOf());
      this.IsSorted = true;
    }
    else {
      this.CompletedList = Object.assign([], this.CompletedListCopy);
      this.IsSorted = false;
    }

    console.log(this.CompletedList);

  }

}
