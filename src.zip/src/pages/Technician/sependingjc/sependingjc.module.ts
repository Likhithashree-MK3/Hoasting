import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SependingjcPage } from './sependingjc';

@NgModule({
  declarations: [
    SependingjcPage,
  ],
  imports: [
    IonicPageModule.forChild(SependingjcPage),
  ],
})
export class SependingjcPageModule {}
