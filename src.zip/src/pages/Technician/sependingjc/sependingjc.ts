import { Component } from '@angular/core';
import { AlertController, IonicPage, MenuController, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { StdashboardPage } from '../stdashboard/stdashboard';
import { StytsPage } from '../styts/styts';

@IonicPage()
@Component({
  selector: 'page-sependingjc',
  templateUrl: 'sependingjc.html',
})

export class SependingjcPage {

  JCList: any = [];
  PauseTime: any;
  PauseReason: string = "";
  showInput: boolean = true;
  selectedPauseActivity: string = '';
  JobCardHedIC: number;
  PauseActivityList: any = [];
  isResionForPauseOpen: boolean = false
  PauseActivityResion: string = "";
  PauseIconPath: string = this.global.HostedPath.split("api")[0] + "UploadedFiles/PauseActivity/";

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public global: GlobalProvider,
    public httpClient: HttpClient,
    public menuCtrl: MenuController) {

    this.global.HeaderTitle = "Pending Job Card";

    this.JCList = this.navParams.get("data");

    console.log(this.JCList);

    this.JCList[0].StatusName = this.global.MasterData.JobCardStatus.find(s => s.JobCardStatus_IC == this.JCList[0].Status).Status;

  }

  SubmitClick() {

    let jcDetails = {
      TechnicianID: this.global.UserDetails[0].Employee_IC,
      JobCardHeader_IC: this.JCList[0].JobCardHeader_IC,
      PauseDatetime: this.PauseTime.toString(),
      Reason: this.PauseReason,
      JobCardProgressDetailer_IC: this.JCList[0].JobCardProgressDetailer_IC
    }

    console.log(jcDetails);

    let d1, d2;

    if (this.PauseTime == undefined) {
      this.global.ToastShow("Please enter Pause time");
    } else {
      d1 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2.setHours(this.PauseTime.split(":")[0])
      d2.setMinutes(this.PauseTime.split(":")[1])

      if (d2 > d1) {

        if (this.PauseReason != "") {

          if (this.global.CheckInternetConnection()) {

            this.httpClient.post<any>(this.global.HostedPath + "UpdateTechnicianPendingJC", jcDetails).subscribe(jobCards => {

              if (jobCards.StatusCode == 200) {

                this.global.ToastShow("Updated Successfully, you can continue working now");

                this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=1" + "&FromeDate=02/14/2024&ToDate=03/14/2024"
                ).subscribe(jobCards => {

                  console.log(jobCards);

                  if (jobCards.StatusCode == 200) {

                    if (JSON.parse(jobCards.Output)[0].YTS > 0) {
                      this.navCtrl.setRoot(StytsPage)
                    }
                    else {
                      this.navCtrl.setRoot(StdashboardPage);
                    }

                  }
                  else {
                    console.log(jobCards);
                    this.global.ToastShow("Something went wrong, Pls try again later");
                  }

                });

                //this.navCtrl.setRoot(SejoblistPage);

              }
              else {
                console.log(jobCards);
                this.global.ToastShow("Something went wrong, Pls try again later");
              }

            }, (error) => {
              console.log(error);
            });

          }
          else {
            this.global.ToastShow(this.global.NetworkMessage);
          }

        }
        else {
          this.global.ToastShow("Please enter Resume Reason");
        }

      }
      else {
        this.global.ToastShow("Please enter greater than Previous Resume date");
      }

    }

  }

  SaveClick(e) {

    console.log(e);

    let d1, d2;

    if (this.PauseTime == undefined) {
      this.global.ToastShow("Please enter Pause time");
    } else {
      d1 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2.setHours(this.PauseTime.split(":")[0])
      d2.setMinutes(this.PauseTime.split(":")[1])

      if (d2 > d1) {

        this.PauseActivityList = this.global.MasterData.PauseActivity;

        this.JobCardHedIC = e.JobCardHeader_IC;

        this.isResionForPauseOpen = true;

      }
      else {
        this.global.ToastShow("Please enter greater than Previous Resume date");
      }

    }

  }

  ClosePauseContainer() {
    this.isResionForPauseOpen = false;
  }

  ConfirmResionForPause() {

    console.log(this.selectedPauseActivity);

    if (this.selectedPauseActivity == "OT") {

      if (this.PauseActivityResion == "") {
        this.global.ToastShow("Please Enter Other reason");
        return false;
      }
      else {
        this.UpdatePuase(this.selectedPauseActivity, this.PauseActivityResion);
        this.isResionForPauseOpen = false;
      }
    }
    else {
      let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == this.selectedPauseActivity).PauseReason;
      this.UpdatePuase(this.selectedPauseActivity, res);
      this.isResionForPauseOpen = false;
    }

  }

  PauseActivityListClick(val) {

    setTimeout(() => {
      if (val.ShortName == "OT") {
        document.getElementById("ResionForPauseListContainer").scrollTop = 200;
      }
    }, 10);

  }

  UpdatePuase(ShortName, reason) {

    let jcDetails = {
      TechnicianID: this.global.UserDetails[0].Employee_IC,
      JobCardHeader_IC: this.JCList[0].JobCardHeader_IC,
      PauseDatetime: this.PauseTime.toString(),
      Reason: reason,
      JobCardProgressDetailer_IC: this.JCList[0].JobCardProgressDetailer_IC,
      ShortName: ShortName
    }

    this.httpClient.post<any>(this.global.HostedPath + "UpdateTechnicianPendingJC", jcDetails).subscribe(jobCards => {

      if (jobCards.StatusCode == 200) {

        this.global.ToastShow("Updated Successfully, you can continue working now");

        this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=1" + "&FromeDate=02/14/2024&ToDate=03/14/2024"
        ).subscribe(jobCards => {

          console.log(jobCards);

          if (jobCards.StatusCode == 200) {

            if (JSON.parse(jobCards.Output)[0].YTS > 0) {
              this.navCtrl.setRoot(StytsPage)
            }
            else {
              this.navCtrl.setRoot(StdashboardPage);
            }

          }
          else {
            console.log(jobCards);
            this.global.ToastShow("Something went wrong, Pls try again later");
          }

        });

        //this.navCtrl.setRoot(SejoblistPage);

      }
      else {
        console.log(jobCards);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
    });

  }

  onDateTimeChange() {
    // Check if a value has been selected in datetime picker
    if (this.PauseTime) {
      // Hide the input and show the datetime picker
      this.showInput = false;
    }
  }

  CompleteClick(e) {

    console.log(e);

    let d1, d2;

    if (this.PauseTime == undefined) {
      this.global.ToastShow("Please enter Completed time");
    } else {
      d1 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2 = new Date(this.JCList[0].JobCardProgressResumeDatetime);
      d2.setHours(this.PauseTime.split(":")[0])
      d2.setMinutes(this.PauseTime.split(":")[1])

      if (d2 > d1) {

        this.JobCardHedIC = e[0].JobCardHeader_IC;

        this.UpdateComplete(e)

      }
      else {
        this.global.ToastShow("Please enter greater than Previous Resume date");
      }

    }

  }

  UpdateComplete(e) {

    const confirm = this.alertCtrl.create({
      title: 'Do you want to Complete the job ?',
      buttons: [
        {
          text: 'Cancel',
          cssClass: 'BtnCancelPopup',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          cssClass: 'BtnYesPopup',
          handler: () => {

            console.log(e);

            if (this.global.CheckInternetConnection()) {

              this.httpClient.post<any>(this.global.HostedPath + "UpdateOnComplete?TechnicianID=" + this.global.UserDetails[0].Employee_IC + "&JobCardHeaderIC=" + e[0].JobCardHeader_IC, {}).subscribe(result => {
                console.log(result);
                if (result.StatusCode == 200) {

                  // this.global.ToastShow("Job Submitted Successfully");
                  // this.ngOnInit(undefined);                  

                  this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=2" + "&FromeDate=02/14/2024&ToDate=03/14/2024").subscribe(tecjCount => {

                    console.log(JSON.parse(tecjCount.Output));

                    if (tecjCount.StatusCode == 200) {

                      if (JSON.parse(tecjCount.Output)[0].WIP > 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp1.png">',
                          subTitle: '<center>Great Job!!!<br/> Keep up the good work!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {

                              if (JSON.parse(tecjCount.Output)[0].YTS > 0) {
                                this.navCtrl.setRoot(StytsPage)
                              }
                              else {
                                this.navCtrl.setRoot(StdashboardPage);
                              }

                            }
                          }]
                        });
                        alert.present();

                      }
                      else if (JSON.parse(tecjCount.Output)[0].WIP == 0 && JSON.parse(tecjCount.Output)[0].YTS > 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp1.png">',
                          subTitle: '<center>Great Job!!!<br/> Keep up the good work!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {

                              if (JSON.parse(tecjCount.Output)[0].YTS >= 1 && JSON.parse(tecjCount.Output)[0].WIP == 0) {

                                this.httpClient.get<any>(this.global.HostedPath + "GetTechYetToStart?Technician_ID=" + this.global.UserDetails[0].Employee_IC).subscribe(list => {

                                  if (list.StatusCode == 200) {

                                    let tempYTS = JSON.parse(list.Output);

                                    let Description = encodeURIComponent("JC " + tempYTS[0].OrderNo + " has been allocated");
                                    this.global.RealTimeInsertIntoTrAlert2(this.JobCardHedIC, this.global.UserDetails[0].Employee_IC, Description, 'High');

                                    this.navCtrl.setRoot(StytsPage);

                                  }
                                  else {
                                    console.log(list);
                                    this.global.ToastShow("Something went wrong, Pls try again later");
                                  }

                                }, (error) => {
                                  console.log(error);
                                  this.global.LoadingHide();
                                });

                              }

                            }
                          }]
                        });
                        alert.present();

                      }
                      else if (JSON.parse(tecjCount.Output)[0].WIP == 0 && JSON.parse(tecjCount.Output)[0].YTS == 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp.png">',
                          subTitle: '<center>Great Job!!<br />Keep Going!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {
                              this.navCtrl.setRoot(StdashboardPage);
                            }
                          }]
                        });
                        alert.present();

                      }

                    }
                    else {
                      console.log(tecjCount);
                      this.global.ToastShow("Something went wrong, Pls try again later");
                    }

                  }, (error) => {
                    console.log(error);
                  });

                }
                else {
                  console.log(result);
                  this.global.ToastShow("Something went wrong, Pls try again later");
                }


              }, (error) => {
                console.log(error);
              });

            }
            else {
              this.global.ToastShow(this.global.NetworkMessage);
            }

          }
        }
      ]
    });
    confirm.present();

  }

}