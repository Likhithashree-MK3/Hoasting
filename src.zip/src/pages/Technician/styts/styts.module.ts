import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StytsPage } from './styts';

@NgModule({
  declarations: [
    StytsPage,
  ],
  imports: [
    IonicPageModule.forChild(StytsPage),
  ],
})
export class StytsPageModule {}
