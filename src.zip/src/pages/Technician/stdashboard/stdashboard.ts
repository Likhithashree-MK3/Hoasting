import { Component, ViewChild } from '@angular/core';
import { ActionSheetController, AlertController, IonicPage, MenuController, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { StytsPage } from '../../Technician/styts/styts';
import { StwipPage } from '../../Technician/stwip/stwip';
import { StpausedPage } from '../../Technician/stpaused/stpaused';
import { StcompletedPage } from '../../Technician/stcompleted/stcompleted';
import { StrealizationPage } from '../strealization/strealization';
import { DatePipe } from '@angular/common';
import { Chart } from 'chart.js';
import { NotificationsPage } from '../../Shared/notifications/notifications';
import { CalendarComponentOptions } from 'ion2-calendar';

declare var google;

@IonicPage()
@Component({
  selector: 'page-stdashboard',
  templateUrl: 'stdashboard.html',
  providers: [DatePipe]
})

export class StdashboardPage {

  @ViewChild('halfPieChart') halfPieChart: any;
  @ViewChild('LineChart') LineChart: any;

  DashboardCount: any = {};
  TechnicianDashboard: any = [];
  WorkStatus: any = [];
  OverallJobcard: any = {};
  Filterdata = "Last 7 days";
  filtervalue: boolean = true;
  jchrs;
  nonjchrs;
  Graphdata: any = [];
  selectedtype: number = 2;
  daterange: boolean = false
  maxDate: string;
  minDate: string;
  SearchFromDate: any;
  SearchToDate: any;
  TodaysDate: any;
  SelectedFilter = "2";
  SelectedFilterName = "Last 7 Days";
  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    color: "danger",
    from: new Date().setDate(new Date().getDate() - 30),
    to: new Date()
  };
  isHalfGraphDisplay: boolean = true;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public menuCtrl: MenuController,
    public httpClient: HttpClient,
    public global: GlobalProvider,
    public actionSheetCtrl: ActionSheetController,
    public alertCtrl: AlertController,
    private datePipe: DatePipe,
    public actionsheetCtrl: ActionSheetController) {

    this.menuCtrl.enable(true);

    const currentDate = new Date();
    this.maxDate = currentDate.toISOString().substring(0, 10); //YYYY-MM-DD
    const sixMonthsAgo = new Date(currentDate.getFullYear(), currentDate.getMonth() - 6, currentDate.getDate());
    this.minDate = sixMonthsAgo.toISOString().substring(0, 10); //YYYY-MM-DD

    let date1 = new Date();

    this.TodaysDate = date1.getFullYear() + "-" + ((date1.getMonth() + 1) > 9 ? (date1.getMonth() + 1) : ("0" + (date1.getMonth() + 1))) + "-" + ((date1.getDate() + 1) > 9 ? (date1.getDate()) : ("0" + (date1.getDate())));

  }

  ngOnInit(refresher) {

    console.log(this.selectedtype);

    let fromDate;
    let toDate;

    if (this.SelectedFilter == "6") {
      let d1 = new Date(this.SearchFromDate);
      fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
      let d2 = new Date(this.SearchToDate);
      toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
    }
    else {
      fromDate = this.TodaysDate;
      toDate = this.TodaysDate;
    }

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate
      ).subscribe(jobCards => {

        //console.log(jobCards);

        if (jobCards.StatusCode == 200) {

          this.DashboardCount = JSON.parse(jobCards.Output)[0];
          this.DashboardCount.RealizationPercValue = this.DashboardCount.RealizationPerc / 100

          console.log(this.DashboardCount);

          this.jchrs = this.DashboardCount.JCHours;
          this.nonjchrs = this.DashboardCount.NonJCHours;

          //Graph
          this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardGraphCount?Employee_ID=" + this.global.UserDetails[0].Employee_IC
          ).subscribe(jobCards => {

            if (jobCards.StatusCode == 200) {

              let val = JSON.parse(jobCards.Output);

              this.Graphdata = [];

              this.Graphdata.push({
                FromDate: val[0].FromDate1,
                ToDate: val[0].ToDate1,
                RealizationPerc: val[0].RealizationPref1,
                BilledHours: val[0].BilledHours1,
                WorkedHours: val[0].WorkedHours1
              });
              this.Graphdata.push({
                FromDate: val[0].FromDate2,
                ToDate: val[0].ToDate2,
                RealizationPerc: val[0].RealizationPref2,
                BilledHours: val[0].BilledHours2,
                WorkedHours: val[0].WorkedHours2
              });
              this.Graphdata.push({
                FromDate: val[0].FromDate3,
                ToDate: val[0].ToDate3,
                RealizationPerc: val[0].RealizationPref3,
                BilledHours: val[0].BilledHours3,
                WorkedHours: val[0].WorkedHours3
              });
              this.Graphdata.push({
                FromDate: val[0].FromDate4,
                ToDate: val[0].ToDate4,
                RealizationPerc: val[0].RealizationPref4,
                BilledHours: val[0].BilledHours4,
                WorkedHours: val[0].WorkedHours4
              });

              console.log(this.Graphdata);

              //charts
              google.charts.setOnLoadCallback(this.drawLineChart());
              google.charts.setOnLoadCallback(this.drawColumnChart());

              this.createHalfPieChart();

              if (refresher != undefined) {
                refresher.complete();
              }

            }
            else {
              console.log(jobCards);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

            this.global.LoadingHide();

          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });

        }
        else {
          console.log(jobCards);
          this.global.ToastShow("Something went wrong, Pls try again later");
          this.global.LoadingHide();
        }

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  drawLineChart1() {

    const chartWidth = window.innerWidth * 1.1; // 110% of window width
    const chartHeight = window.innerHeight * 0.4; // 50% of window height

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Date');
    data.addColumn('number', 'Realization');
    data.addColumn({ type: 'string', role: 'annotation' });

    console.log(this.Graphdata);

    var LineChartData = [];

    this.Graphdata.forEach(ele => {
      // Combine dates into a single string
      let combinedDate = this.datePipe.transform(ele.FromDate, 'dd.MM.yy') + ' - ' + this.datePipe.transform(ele.ToDate, 'dd.MM.yy');
      let per;

      if (ele.RealizationPerc > 100) {
        per = "*" + ele.RealizationPerc + "%";
      }
      else {
        ele.RealizationPerc + "%";
      }

      LineChartData.push([combinedDate, ele.RealizationPerc, per])
    });

    data.addRows(LineChartData);

    var options = {
      title: 'My Activity',
      titleTextStyle: {
        fontSize: 18
      },
      curveType: 'function',
      width: chartWidth,
      height: chartHeight,
      legend: 'none',
      pointSize: 5,
      pointColor: 'black',
      series: {
        0: {
          color: '#3E3E3E',
          lineWidth: 2
        },
        1: {
          color: 'black',
          lineWidth: 0,
        }
      },
      annotations: {
        textStyle: {
          fontSize: 12,
          color: '#3E3E3E',
          bold: true
        },
        stem: {
          length: 10,
          color: '#ffffff'
        },
        annotationTextPosition: 'auto'
      },
      vAxis: {
        title: "% Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent',
          minSpacing: 10
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
          //max: 30000
        }
      },
      hAxis: {
        textStyle: {
          bold: true,
          color: '#3E3E3E',
        }
      }
    };

    var chart = new google.visualization.LineChart(document.getElementById('linechart_div'));
    chart.draw(data, options);

  }

  drawLineChart2() {

    const chartWidth = window.innerWidth * 0.9;
    const chartHeight = window.innerHeight * 0.5;

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Week');
    data.addColumn('number', 'Realization');
    data.addColumn({ type: 'string', role: 'annotation' });

    console.log(this.Graphdata);

    var LineChartData = [];

    this.Graphdata.forEach((ele, index) => {

      let weekLabel = 'W' + (index + 1); // W1, W2, W3, W4,

      //let combinedDate = this.datePipe.transform(ele.FromDate, 'dd.MM.yy') + ' - ' + this.datePipe.transform(ele.ToDate, 'dd.MM.yy');

      // Round the realization percentage to the nearest whole number
      let realizationPerc = Math.round(ele.RealizationPerc);

      let annotationText;

      if (realizationPerc > 0) {
        annotationText = '⭐️' + realizationPerc + '%'; // Add colored icon for realization percentage greater than 0
      } else {
        annotationText = realizationPerc + '%';
      }

      LineChartData.push([weekLabel, realizationPerc, annotationText]);

      //console.log(`Week ${weekLabel}: ${combinedDate}`);

    });

    data.addRows(LineChartData);

    var options = {
      title: 'My Activity',
      titleTextStyle: {
        fontSize: 18
      },
      curveType: 'function',
      width: chartWidth,
      height: chartHeight,
      legend: 'none',
      pointSize: 5,
      series: {
        0: {
          color: '#3E3E3E',
          lineWidth: 2,
          pointSize: 1
        }
      },
      annotations: {
        textStyle: {
          fontSize: 10,
          color: 'black',
          bold: true,
          auraColor: 'white',
          opacity: 1.0,
        },
        boxStyle: {
          stroke: 'lightgrey',
          strokeWidth: 1,
          rx: 3,
          ry: 3,
          gradient: {
            color1: 'white',
            color2: 'white',
            x1: '0%',
            y1: '0%',
            x2: '100%',
            y2: '100%',
            useObjectBoundingBoxUnits: true
          }
        },
        stem: {
          length: 0,
          color: 'none'
        },
        alwaysOutside: true,
        annotationTextPosition: 'right',
      },
      vAxis: {
        title: "% Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent',
          minSpacing: 10
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
        }
      },
      hAxis: {
        textStyle: {
          bold: true,
          color: '#3E3E3E',
        },
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        }
      }
    };

    var chart = new google.visualization.LineChart(document.getElementById('linechart_div'));
    chart.draw(data, options);

    var dateReferencesDiv = document.getElementById('date_references');
    dateReferencesDiv.innerText = '';

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate().toString().padStart(2, '0');
      let month = monthNames[date.getMonth()];
      return `${month} ${day}`;
    }

    this.Graphdata.forEach((ele, index) => {
      let weekLabel = 'W' + (index + 1); // W1, W2, W3, W4,
      let fromDate = new Date(ele.FromDate);
      let toDate = new Date(ele.ToDate);
      let formattedFromDate = formatDate(fromDate);
      let formattedToDate = formatDate(toDate);
      dateReferencesDiv.innerText += `<p><span class="week-label"><strong>${weekLabel}:</strong></span> <span class="date-range">${formattedFromDate}</span><span class="hyphen"> - </span><span class="date-range">${formattedToDate}</span></p>`;
    });

    var style = document.createElement('style');
    style.innerText = `
    #date_references p {
      display: flex;
      align-items: baseline;
    }
    .week-label {
      display: inline-block;
      width: 40px; /* Adjust width as needed */
      text-align: left;
    }
    .date-range {
      font-family: monospace; /* Use a monospaced font */
      white-space: nowrap; /* Prevent wrapping */
      display: inline-block;
      text-align: left;
    }`;

    document.head.appendChild(style);

  }

  drawLineChart3() {

    const chartWidth = window.innerWidth * 0.9;
    const chartHeight = window.innerHeight * 0.5;

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Week');
    data.addColumn('number', 'Realization');
    data.addColumn({ type: 'string', role: 'annotation' });

    var LineChartData = [];
    let maxValue = 0;

    this.Graphdata.forEach((ele, index) => {

      let weekLabel = 'W' + (index + 1); // W1, W2, W3, W4
      let realizationPerc = Math.round(ele.RealizationPerc);

      if (realizationPerc > maxValue) {
        maxValue = realizationPerc;
      }

      let annotationText;

      if (realizationPerc > 0) {
        annotationText = '⭐️' + realizationPerc + '%'; // Add colored icon for realization percentage greater than 0
      } else {
        annotationText = realizationPerc + '%';
      }

      LineChartData.push([weekLabel, realizationPerc, annotationText]);

    });

    data.addRows(LineChartData);

    var options = {
      title: 'My Activity',
      titleTextStyle: {
        fontSize: 18
      },
      curveType: 'function',
      width: chartWidth,
      height: chartHeight,
      legend: 'none',
      pointSize: 5,
      series: {
        0: {
          color: '#3E3E3E',
          lineWidth: 2,
          pointSize: 1
        }
      },
      annotations: {
        textStyle: {
          fontSize: 10,
          color: 'black',
          bold: true,
          auraColor: 'white',
          opacity: 1.0,
        },
        boxStyle: {
          stroke: 'lightgrey',
          strokeWidth: 1,
          rx: 3,
          ry: 3,
          gradient: {
            color1: 'white',
            color2: 'white',
            x1: '0%',
            y1: '0%',
            x2: '100%',
            y2: '100%',
            useObjectBoundingBoxUnits: true
          }
        },
        stem: {
          length: 0,
          color: 'none'
        },
        alwaysOutside: true,
        annotationTextPosition: 'right',
      },
      vAxis: {
        title: "% Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent',
          minSpacing: 10
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
          max: maxValue > 0 ? maxValue * 1.2 : 10
        }
      },
      hAxis: {
        textStyle: {
          bold: true,
          color: '#3E3E3E',
        },
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        }
      }
    };

    var chart = new google.visualization.LineChart(document.getElementById('linechart_div'));
    chart.draw(data, options);

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate().toString().padStart(2, '0');
      let month = monthNames[date.getMonth()];
      return `${month} ${day}`;
    }

    // Generating HTML content for the grid
    let gridContent = '';
    for (let i = 0; i < this.Graphdata.length; i += 2) {
      let firstDateRange = '';
      let secondDateRange = '';

      if (i < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 1);
        let fromDate = new Date(this.Graphdata[i].FromDate);
        let toDate = new Date(this.Graphdata[i].ToDate);
        firstDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      if (i + 1 < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 2);
        let fromDate = new Date(this.Graphdata[i + 1].FromDate);
        let toDate = new Date(this.Graphdata[i + 1].ToDate);
        secondDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      gridContent += `
      <ion-row>
        <ion-col size="6">${firstDateRange}</ion-col>
        <ion-col size="6">${secondDateRange}</ion-col>
      </ion-row>
    `;
    }

    // Set the innerText of the grid container
    document.getElementById('grid_container').innerText = gridContent;

    var style = document.createElement('style');
    style.innerText = `
      .week-label {
          font-weight: bold;
          min-width: 40px; /* Ensure consistent width for all week labels */
          display: inline-block;
          text-align: right; /* Align week labels to the right */
          padding-right: 10px; /* Add spacing between the week label and the date range */}
  `;

  }

  drawLineChart() {

    const chartWidth = window.innerWidth * 0.9;
    const chartHeight = window.innerHeight * 0.5;

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Week');
    data.addColumn('number', 'Realization');
    data.addColumn({ type: 'string', role: 'annotation' });

    var LineChartData = [];
    let maxValue = 0;

    this.Graphdata.forEach((ele, index) => {

      let weekLabel = 'W' + (index + 1); // W1, W2, W3, W4
      let realizationPerc = Math.round(ele.RealizationPerc);

      if (realizationPerc > maxValue) {
        maxValue = realizationPerc;
      }

      let annotationText;

      if (realizationPerc > 0) {
        annotationText = '⭐️' + realizationPerc + '%'; // Add colored icon for realization percentage greater than 0
      } else {
        annotationText = realizationPerc + '%';
      }

      LineChartData.push([weekLabel, realizationPerc, annotationText]);

    });

    data.addRows(LineChartData);

    var options = {
      // title: 'My Activity',
      // titleTextStyle: {
      //   fontSize: 18
      // },
      curveType: 'function',
      width: chartWidth,
      height: chartHeight,
      legend: 'none',
      pointSize: 5,
      series: {
        0: {
          color: '#3E3E3E',
          lineWidth: 2,
          pointSize: 1
        }
      },
      annotations: {
        textStyle: {
          fontSize: 10,
          color: 'black',
          bold: true,
          auraColor: 'white',
          opacity: 1.0,
        },
        boxStyle: {
          stroke: 'lightgrey',
          strokeWidth: 1,
          rx: 3,
          ry: 3,
          gradient: {
            color1: 'white',
            color2: 'white',
            x1: '0%',
            y1: '0%',
            x2: '100%',
            y2: '100%',
            useObjectBoundingBoxUnits: true
          }
        },
        stem: {
          length: 0,
          color: 'none'
        },
        alwaysOutside: true,
        annotationTextPosition: 'right',
      },
      vAxis: {
        title: "% Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent',
          minSpacing: 10
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
          max: maxValue > 0 ? maxValue * 1.2 : 10
        }
      },
      hAxis: {
        textStyle: {
          bold: true,
          color: '#3E3E3E',
        },
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        }
      }
    };

    var chart = new google.visualization.LineChart(document.getElementById('linechart_div'));
    chart.draw(data, options);

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate().toString().padStart(2, '0');
      let month = monthNames[date.getMonth()];
      return `${month} ${day}`;
    }

    // Generating HTML content for the grid
    let gridContent = '';
    for (let i = 0; i < this.Graphdata.length; i += 2) {
      let firstDateRange = '';
      let secondDateRange = '';

      if (i < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 1);
        let fromDate = new Date(this.Graphdata[i].FromDate);
        let toDate = new Date(this.Graphdata[i].ToDate);
        firstDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      if (i + 1 < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 2);
        let fromDate = new Date(this.Graphdata[i + 1].FromDate);
        let toDate = new Date(this.Graphdata[i + 1].ToDate);
        secondDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      gridContent += `
      <ion-row class="LineRow">
        <ion-col size="6" class="LineCol">${firstDateRange}</ion-col>
        <ion-col size="6" class="LineCol">${secondDateRange}</ion-col>
      </ion-row>
    `;
    }

    // Set the innerText of the grid container
    //document.getElementById('grid_container').innerText = gridContent;

    var style = document.createElement('style');
    style.innerText = `
    .LineCol {
      white-space: nowrap; /* Prevent wrapping */
      display: inline-block;
      text-align: left;
      padding: 8px; /* Add some padding for better readability */
  }
  .LineRow {
      display: flex;
      align-items: center;
  }
      .week-label {
          font-weight: bold;
          min-width: 40px; /* Ensure consistent width for all week labels */
          display: inline-block;
          text-align: right; /* Align week labels to the right */
          padding-right: 10px; /* Add spacing between the week label and the date range */}
          `;

    //document.head.appendChild(style);

  }

  drawColumnChart1() {

    // Calculate chart width and height dynamically
    const chartWidth = window.innerWidth * 1.1; // 110% of window width
    const chartHeight = window.innerHeight * 0.4; // 50% of window height

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Date');
    data.addColumn('number', 'Worked');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });
    data.addColumn('number', 'Billed');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });

    var ColumnChartData = [];

    this.Graphdata.forEach(ele => {
      // Combine dates into a single string (assuming FromDate and ToDate are valid dates)
      let combinedDate = this.datePipe.transform(ele.FromDate, 'dd.MM.yy') +
        ' - ' + this.datePipe.transform(ele.ToDate, 'dd.MM.yy');
      ColumnChartData.push([combinedDate, ele.WorkedHours, 'color: #294785;', ele.WorkedHours, ele.BilledHours, 'color: #e33239;', ele.BilledHours])
    });

    console.log(ColumnChartData)

    data.addRows(ColumnChartData);

    var options = {
      'title': "My Activity",
      titleTextStyle: {
        fontSize: 18
      },
      'width': chartWidth,
      'height': chartHeight,
      legend: {
        position: 'top', alignment: 'end', textStyle: {
          bold: true,
          fontSize: 12,
          color: '#3E3E3E'
        }
      },
      annotations: {
        textStyle: {
          color: 'white',
          fontSize: 10,
          bold: true
        },
        stem: {
          length: 0
        },
      },
      series: {
        0: {
          color: '#294785',
          annotations: {
            textStyle: { color: '#294785' }
          }
        }, // Customize color for the first series
        1: {
          color: '#e33239',
          annotations: {
            textStyle: { color: '#e33239' }
          }
        } // Customize color for the second series
      },
      vAxis: {
        title: "Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent'
        },
        textPosition: 'none'
      },
      hAxis: {
        gridlines: {
          color: 'transparent'
        },
        textStyle: {
          bold: true,
        }
      },

    }
    var modelchart = new google.visualization.ColumnChart(document.getElementById('columnchart_div'));
    modelchart.draw(data, options);

  }

  drawColumnChart2() {

    const chartWidth = window.innerWidth * 1.1;
    const chartHeight = window.innerHeight * 0.4;

    var data = new google.visualization.DataTable();

    data.addColumn('string', 'Week');
    data.addColumn('number', 'Worked');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });
    data.addColumn('number', 'Billed');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });

    var ColumnChartData = [];

    this.Graphdata.forEach((ele, index) => {
      let weekLabel = 'W' + (index + 1);
      let workedHours = Math.round(ele.WorkedHours);
      let billedHours = Math.round(ele.BilledHours);
      ColumnChartData.push([weekLabel, workedHours, 'color: #294785;', workedHours, billedHours, 'color: #e33239;', billedHours]);
    });

    data.addRows(ColumnChartData);

    var options = {
      'title': "My Activity",
      titleTextStyle: {
        fontSize: 18
      },
      'width': chartWidth,
      'height': chartHeight,
      legend: {
        position: 'top', alignment: 'end', textStyle: {
          bold: true,
          fontSize: 12,
          color: '#3E3E3E'
        }
      },
      annotations: {
        textStyle: {
          color: 'white',
          fontSize: 10,
          bold: true
        },
        stem: {
          length: 0
        },
      },
      series: {
        0: {
          color: '#294785',
          annotations: {
            textStyle: { color: '#294785' }
          }
        },
        1: {
          color: '#e33239',
          annotations: {
            textStyle: { color: '#e33239' }
          }
        }
      },
      vAxis: {
        title: "Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent'
        },
        textPosition: 'none'
      },
      hAxis: {
        gridlines: {
          color: 'transparent'
        },
        textStyle: {
          bold: true,
        }
      },
    };

    var modelchart = new google.visualization.ColumnChart(document.getElementById('columnchart_div'));
    modelchart.draw(data, options);

    var dateReferencesDiv = document.getElementById('date_references1');
    dateReferencesDiv.innerText = '';

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate();
      let month = monthNames[date.getMonth()];
      if (day < 10) {
        day = '0' + day;
      }
      return month + ' ' + day;
    }

    this.Graphdata.forEach((ele, index) => {
      let weekLabel = 'W' + (index + 1); // W1, W2, W3, W4, ...
      let fromDate = new Date(ele.FromDate);
      let toDate = new Date(ele.ToDate);
      let formattedFromDate = formatDate(fromDate);
      let formattedToDate = formatDate(toDate);
      dateReferencesDiv.innerText += `<p><span class="week-label"><strong>${weekLabel}:</strong></span> <span class="date-range">${formattedFromDate}</span><span class="hyphen"> - </span><span class="date-range">${formattedToDate}</span></p>`;
    });

    var style = document.createElement('style');
    style.innerText = `
    #date_references1 p {
      display: flex;
      align-items: baseline;
    }
    .week-label {
      display: inline-block;
      width: 40px; /* Adjust width as needed */
      text-align: left;
    }
    .date-range {
      display: inline-block;
      text-align: left;
    }
    .hyphen {
      width: 10px; /* Fixed width for the hyphen */
    }`;

    document.head.appendChild(style);

  }

  drawColumnChart3() {

    const chartWidth = window.innerWidth * 1.1; // 110% of window width
    const chartHeight = window.innerHeight * 0.4; // 40% of window height

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Week');
    data.addColumn('number', 'Worked');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });
    data.addColumn('number', 'Billed');
    data.addColumn({ type: 'string', role: 'style' });
    data.addColumn({ type: 'number', role: 'annotation' });

    var ColumnChartData = [];

    this.Graphdata.forEach((ele, index) => {
      let weekLabel = 'W' + (index + 1);
      let workedHours = Math.round(ele.WorkedHours);
      let billedHours = Math.round(ele.BilledHours);
      ColumnChartData.push([weekLabel, workedHours, 'color: #294785;', workedHours, billedHours, 'color: #e33239;', billedHours]);
    });

    data.addRows(ColumnChartData);

    var options = {
      'title': "My Activity",
      titleTextStyle: {
        fontSize: 18
      },
      'width': chartWidth,
      'height': chartHeight,
      legend: {
        position: 'top', alignment: 'end', textStyle: {
          bold: true,
          fontSize: 12,
          color: '#3E3E3E'
        }
      },
      annotations: {
        textStyle: {
          color: 'white',
          fontSize: 10,
          bold: true
        },
        stem: {
          length: 0
        },
      },
      series: {
        0: {
          color: '#294785',
          annotations: {
            textStyle: { color: '#294785' }
          }
        },
        1: {
          color: '#e33239',
          annotations: {
            textStyle: { color: '#e33239' }
          }
        }
      },
      vAxis: {
        title: "Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent'
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
          max: 10
        }
      },
      hAxis: {
        gridlines: {
          color: 'transparent'
        },
        textStyle: {
          bold: true,
        }
      },
    };

    var modelchart = new google.visualization.ColumnChart(document.getElementById('columnchart_div'));
    modelchart.draw(data, options);

    // Update date references in a grid format
    var dateReferencesDiv = document.getElementById('grid_container1');
    dateReferencesDiv.innerText = '';

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate().toString().padStart(2, '0');
      let month = monthNames[date.getMonth()];
      return `${month} ${day}`;
    }

    let gridContent = '';
    for (let i = 0; i < this.Graphdata.length; i += 2) {
      let firstDateRange = '';
      let secondDateRange = '';

      if (i < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 1);
        let fromDate = new Date(this.Graphdata[i].FromDate);
        let toDate = new Date(this.Graphdata[i].ToDate);
        firstDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      if (i + 1 < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 2);
        let fromDate = new Date(this.Graphdata[i + 1].FromDate);
        let toDate = new Date(this.Graphdata[i + 1].ToDate);
        secondDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      gridContent += `
            <ion-row>
                <ion-col size="6">${firstDateRange}</ion-col>
                <ion-col size="6">${secondDateRange}</ion-col>
            </ion-row>
        `;
    }

    // Set the innerText of the grid container
    dateReferencesDiv.innerText = gridContent;

    var style = document.createElement('style');
    style.innerText = `
        .week-label {
            font-weight: bold;
            min-width: 40px; /* Ensure consistent width for all week labels */
            display: inline-block;
            text-align: right; /* Align week labels to the right */
            padding-right: 10px; /* Add spacing between the week label and the date range */
        }
    `;

    document.head.appendChild(style);

  }

  drawColumnChart() {
    const chartWidth = window.innerWidth * 1.1; // 110% of window width
    const chartHeight = window.innerHeight * 0.4; // 40% of window height

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Week');
    data.addColumn('number', 'Worked');
    data.addColumn({ type: 'string', role: 'style' });
    // data.addColumn({ type: 'number', role: 'annotation' });
    data.addColumn({ type: 'string', role: 'annotation' }); // Changed to string to prevent comma formatting
    data.addColumn('number', 'Billed');
    data.addColumn({ type: 'string', role: 'style' });
    // data.addColumn({ type: 'number', role: 'annotation' });
    data.addColumn({ type: 'string', role: 'annotation' }); // Changed to string to prevent comma formatting


    var ColumnChartData = [];

    this.Graphdata.forEach((ele, index) => {
      let weekLabel = 'W' + (index + 1);
      let workedHours = Math.round(ele.WorkedHours);
      let billedHours = Math.round(ele.BilledHours);

      //  let workedHours = 1234;
      //  let billedHours = 5678;
      ColumnChartData.push([weekLabel, workedHours, 'color: #294785;', workedHours.toString(), billedHours, 'color: #e33239;', billedHours.toString()]);
    });

    data.addRows(ColumnChartData);

    var options = {
      'width': chartWidth,
      'height': chartHeight,
      legend: {
          position: 'top', alignment: 'end', textStyle: {
              bold: true,
              fontSize: 12,
              color: '#3E3E3E'
          }
      },
      //legend: { position: 'none' }, // Remove legends
      annotations: {
        textStyle: {
          color: 'white',
          fontSize: 10,
          bold: true
        },
        stem: {
          length: 0
        },
      },
      series: {
        0: {
          color: '#294785',
          annotations: {
            textStyle: { color: '#294785' }
          }
        },
        1: {
          color: '#e33239',
          annotations: {
            textStyle: { color: '#e33239' }
          }
        }
      },
      vAxis: {
        title: "Realization",
        titleTextStyle: {
          bold: true,
          fontSize: 11,
          italic: false
        },
        gridlines: {
          color: 'transparent'
        },
        textPosition: 'none',
        viewWindow: {
          min: 0,
          max: this.getMaxValue(), // Use a function to calculate the max value
        }
      },
      hAxis: {
        gridlines: {
          color: 'transparent'
        },
        textStyle: {
          bold: true,
        }
      },
    };

    var modelchart = new google.visualization.ColumnChart(document.getElementById('columnchart_div'));
    modelchart.draw(data, options);

    // Update date references in a grid format
    //var dateReferencesDiv = document.getElementById('grid_container1');
    //dateReferencesDiv.innerText = '';

    function formatDate(date) {
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let day = date.getDate().toString().padStart(2, '0');
      let month = monthNames[date.getMonth()];
      return `${month} ${day}`;
    }

    let gridContent = '';
    for (let i = 0; i < this.Graphdata.length; i += 2) {
      let firstDateRange = '';
      let secondDateRange = '';

      if (i < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 1);
        let fromDate = new Date(this.Graphdata[i].FromDate);
        let toDate = new Date(this.Graphdata[i].ToDate);
        firstDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      if (i + 1 < this.Graphdata.length) {
        let weekLabel = 'W' + (i + 2);
        let fromDate = new Date(this.Graphdata[i + 1].FromDate);
        let toDate = new Date(this.Graphdata[i + 1].ToDate);
        secondDateRange = `<span class="week-label">${weekLabel}:</span> ${formatDate(fromDate)} - ${formatDate(toDate)}`;
      }

      gridContent += `
            <ion-row class="CustomRow">
                <ion-col size="6" class="CustomCol">${firstDateRange}</ion-col>
                <ion-col size="6" class="CustomCol">${secondDateRange}</ion-col>
            </ion-row>
        `;
    }

    // Set the innerText of the grid container
    //dateReferencesDiv.innerText = gridContent;

    var style = document.createElement('style');
    style.innerText = `
      .CustomCol {
            white-space: nowrap; /* Prevent wrapping */
            display: inline-block;
            text-align: left;
            padding: 8px; /* Add some padding for better readability */
        }
        .CustomRow {
            display: flex;
            align-items: center;
        }
   
        .week-label {
            font-weight: bold;
            min-width: 40px; /* Ensure consistent width for all week labels */
            display: inline-block;
            text-align: right; /* Align week labels to the right */
            padding-right: 10px; /* Add spacing between the week label and the date range */
        }
    `;

    //document.head.appendChild(style);
  }

  getMaxValue() {
    const maxValue = Math.max(...this.Graphdata.map(ele => Math.round(ele.WorkedHours)), ...this.Graphdata.map(ele => Math.round(ele.BilledHours)));
    return maxValue > 0 ? maxValue + (maxValue * 0.2) : 10;
  }

  createHalfPieChart() {

    let GraphData;
    let GraphLabels;
    let GraphColor;

    if (this.DashboardCount.JCHours == 0 && this.DashboardCount.NonJCHours == 0) {
      GraphData = [this.DashboardCount.JCHours, this.DashboardCount.NonJCHours];
      GraphLabels = ['JC Hours', 'Non-JC Hours'];
      GraphColor = ['#a8da72', '#ff7e81'];
      this.isHalfGraphDisplay = false;
    }
    else if (this.DashboardCount.JCHours > 0 && this.DashboardCount.NonJCHours > 0) {
      GraphData = [this.DashboardCount.JCHours, this.DashboardCount.NonJCHours];
      GraphLabels = ['JC Hours', 'Non-JC Hours'];
      GraphColor = ['#a8da72', '#ff7e81'];
      this.isHalfGraphDisplay = true;
      this.JcNonJCGraph(GraphLabels, GraphData, GraphColor);
    }
    else if (this.DashboardCount.JCHours > 0 && this.DashboardCount.NonJCHours == 0) {
      GraphData = [this.DashboardCount.JCHours];
      GraphLabels = ['JC Hours'];
      GraphColor = ['#a8da72'];
      this.isHalfGraphDisplay = true;
      this.JcNonJCGraph(GraphLabels, GraphData, GraphColor);
    }
    else if (this.DashboardCount.JCHours == 0 && this.DashboardCount.NonJCHours > 0) {
      GraphData = [this.DashboardCount.NonJCHours];
      GraphLabels = ['Non-JC Hours'];
      GraphColor = ['#ff7e81'];
      this.isHalfGraphDisplay = true;
      this.JcNonJCGraph(GraphLabels, GraphData, GraphColor);
    }
    else if (this.DashboardCount.JCHours < 0 || this.DashboardCount.NonJCHours < 0) {
      GraphData = [this.DashboardCount.JCHours, this.DashboardCount.NonJCHours];
      GraphLabels = ['JC Hours', 'Non-JC Hours'];
      GraphColor = ['#a8da72', '#ff7e81'];
      this.isHalfGraphDisplay = false;
    }

  }

  JcNonJCGraph(GraphLabels, GraphData, GraphColor) {

    const canvas = this.halfPieChart.nativeElement;
    const ctx = canvas.getContext('2d');

    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: GraphLabels,
        datasets: [{
          data: GraphData,
          backgroundColor: GraphColor,
          borderWidth: 0 // Set border width to 0
        }]
      },
      options: {
        cutoutPercentage: 50,
        rotation: Math.PI,
        circumference: Math.PI,
        legend: {
          display: false,
          position: 'bottom',
          labels: {
            usePointStyle: false // Use point style (circle)
          },
          onClick: function () {

          }
        },
        animation: {
          animateScale: true,
          animateRotate: true
        },
        plugins: {
          datalabels: {
            display: false // Ensure that datalabels plugin doesn't interfere
          }
        }
      },
      // Register a custom plugin for drawing data labels
      plugins: [{
        afterDatasetsDraw: function (chartInstance, easing) {
          // To only draw at the end of animation, check for easing === 1
          const ctx = chartInstance.ctx;
          chartInstance.data.datasets.forEach((dataset, i) => {
            const meta = chartInstance.getDatasetMeta(i);
            if (!meta.hidden) {
              meta.data.forEach((element, index) => {
                ctx.fillStyle = '#083a81'; // EicherBlue color
                const fontSize = 15;
                const fontStyle = '600'; // Semibold font weight
                const fontFamily = 'Hermis FB'; // Hermis FB font family
                ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                const model = element._model;
                const midAngle = model.startAngle + (model.endAngle - model.startAngle) / 2;

                // Calculate position based on segment angle
                const radius = model.outerRadius;
                const textRadius = radius * 0.8; // Adjust this value to position text closer or further from the center
                const x = model.x + textRadius * Math.cos(midAngle);
                const y = model.y + textRadius * Math.sin(midAngle);

                // Additional styles
                ctx.textAlign = 'center'; // Center text horizontally
                ctx.textBaseline = 'middle'; // Center text vertically

                // Get the data value
                const dataValue = dataset.data[index];
                // Ensure dataValue is a number
                if (typeof dataValue === 'number') {
                  // Example numbers
                  const formattedValue = (dataValue < 0 ? '0' : '') + dataValue; // Add leading zero if value is less than 10
                  ctx.fillText(formattedValue + '%', x, y);
                }
              });
            }


          });
        }
      }]
    });

  }

  createLineChart() {

    const canvas = this.LineChart.nativeElement;
    const ctx = canvas.getContext('2d');
    //const divElement = canvas.parentElement; // Get the parent <div> element

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ["A", "B", "C", "D", "E", "F"],
        datasets: [{
          label: 'My Activity',
          data: [65, 59, 80, 81, 56, 55, 40],
          fill: false,
          borderColor: 'rgb(75, 192, 192)',
          lineTension: 0.1
        }]
      },

    });

  }

  WorkStatusClick(val) {

    if (val == 'YTS') {
      this.navCtrl.setRoot(StytsPage);
    } else if (val == 'WIP') {
      this.navCtrl.setRoot(StwipPage);
    } else if (val == 'Paused') {
      this.navCtrl.setRoot(StpausedPage);
    } else if (val == 'Completed') {
      this.navCtrl.setRoot(StcompletedPage);
    }

  }

  FilterClick1() {

    let actionSheet = this.actionsheetCtrl.create({
      title: 'Duration',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Last Day',
          handler: () => {
            console.log('Last Day');
            this.Filterdata = 'Last Day';
            this.selectedtype = 1;
            this.filtervalue = true;
            this.daterange = false;
            this.ngOnInit(undefined);

          }
        },
        {
          text: 'Last 7 days',
          handler: () => {
            console.log('Last 7 days');
            this.Filterdata = 'Last 7 days';
            this.selectedtype = 2;
            this.filtervalue = true;
            this.daterange = false;
            this.ngOnInit(undefined);

          }
        },
        {
          text: 'MTD',
          handler: () => {
            console.log('MTD');
            this.Filterdata = 'MTD';
            this.selectedtype = 3;
            this.filtervalue = true;
            this.daterange = false;
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'LM',
          handler: () => {
            console.log('LM');
            this.Filterdata = 'LM';
            this.selectedtype = 4;
            this.filtervalue = true;
            this.daterange = false;
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'YTD',
          handler: () => {
            console.log('YTD');
            this.Filterdata = 'YTD';
            this.selectedtype = 5;
            this.filtervalue = true;
            this.daterange = false;
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'Date range',
          handler: () => {
            console.log('Date range');
            this.Filterdata = 'Date range';
            this.selectedtype = 6;
            this.filtervalue = false;
            this.daterange = true;
            // this.ngOnInit(undefined);
          }
        },
        {
          text: 'Cancel',
          role: 'cancel', // will always sort to be on the bottom
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();
  }

  FilterClick() {

    this.global.iscardOpen = !this.global.iscardOpen;

    this.global.FilterList.filter((a) => a.isSelected = false);

    this.global.FilterList.filter((a) => a.id == this.SelectedFilter)[0].isSelected = true;

  }

  FilterListClick(val) {

    this.global.FilterList.filter((a) => a.isSelected = false);
    val.isSelected = true;
    this.SelectedFilter = val.id;

    console.log(this.SelectedFilter);

    if (val.id == 6) {
      this.optionsRange.from = new Date().setDate(new Date().getDate() - 30);
      this.optionsRange.to = new Date()
    }

  }

  FilterApplyClick() {

    if (this.SelectedFilter == "6") {

      if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
        && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

        this.global.iscardOpen = !this.global.iscardOpen;
        this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
        this.ngOnInit(undefined);

      }
      else {
        this.global.ToastShow("Please enter From date and To date");
      }

    }
    else {
      this.global.iscardOpen = !this.global.iscardOpen;
      this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
      this.ngOnInit(undefined);
    }

  }

  FilterResetClick() {

    this.SelectedFilter = "2";
    this.SelectedFilterName = "Last 7 Days";
    this.global.FilterList[1].isSelected = true;
    this.ngOnInit(undefined);

  }

  DateRangeChange(val) {
    console.log(val);
    this.SearchFromDate = val.from._i;
    this.SearchToDate = val.to._i;
  }

  CalenderStartClick(val) {

    console.log(val);

    //this.optionsRange.from = new Date(val.time).setDate(new Date().getDate() - 30);

    this.optionsRange.from = new Date(new Date().setDate(new Date().getDate() - 60));

    console.log(this.optionsRange);

  }

  RemoveFilteredata() {
    // this.FilterList.splice(data, 1);
    // this.Filterdata = "";
    this.filtervalue = false;
  }

  RealizationClick() {
    this.navCtrl.setRoot(StrealizationPage)
  }

  NotificationClick() {
    this.navCtrl.setRoot(NotificationsPage);
    //this.global.ToastShow("Coming soon...");
  }

}