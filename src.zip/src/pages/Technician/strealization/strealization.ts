import { Component } from '@angular/core';
import { ActionSheetController, AlertController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { CalendarComponentOptions } from 'ion2-calendar';

@IonicPage()
@Component({
  selector: 'page-strealization',
  templateUrl: 'strealization.html',
  providers: [DatePipe] // Provide DatePipe
})

export class StrealizationPage {

  RealizationData: any = {};
  RealizationList: any = [];
  RealizationListCopy: any = [];

  filtervalue: boolean = true;
  today: any;
  SrchText: string;
  sortdesc: boolean = true;
  daterange: boolean = false;
  maxDate: string;
  minDate: string;
  SelectedFilter = "2";
  SelectedFilterName = "Last 7 Days";
  SearchFromDate: any;
  SearchToDate: any;
  TodaysDate: any;
  IsSorted: boolean = false;
  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    color: "danger",
    from: new Date().setDate(new Date().getDate() - 30),
    to: new Date()
  };
  filteredJobCards: any[] = []; // Initialize with an empty array
  activeFilter: string[] = ['ALL']; // Default to 'ALL' filter
  totalCount: number = 0;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public global: GlobalProvider,
    public httpClient: HttpClient,
    private datePipe: DatePipe,
    public actionsheetCtrl: ActionSheetController) {

    this.global.HeaderTitle = "Realization";

    var date = new Date();
    this.today = this.datePipe.transform(date, 'dd.MM.yyy');
    console.log(this.RealizationList)

    let date1 = new Date();

    this.TodaysDate = date1.getFullYear() + "-" + ((date1.getMonth() + 1) > 9 ? (date1.getMonth() + 1) : ("0" + (date1.getMonth() + 1))) + "-" + ((date1.getDate() + 1) > 9 ? (date1.getDate()) : ("0" + (date1.getDate())));

  }

  ngOnInit(refresher?) {
    this.activeFilter = ['ALL'];
    this.fetchDataAndFilter(refresher);
  }

  fetchDataAndFilter(refresher?) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      let fromDate;
      let toDate;

      if (this.SelectedFilter == "6") {
        let d1 = new Date(this.SearchFromDate);
        fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
        let d2 = new Date(this.SearchToDate);
        toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
      } else {
        fromDate = this.TodaysDate;
        toDate = this.TodaysDate;
      }

      this.httpClient.get<any>(this.global.HostedPath + "GetTechRealizationDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate
      ).subscribe(jobCards => {

        if (jobCards.StatusCode == 200) {

          this.RealizationData = JSON.parse(jobCards.Output)[0];
          console.log(this.RealizationData)

          this.calculateTotalCount();

          //List 
          this.httpClient.get<any>(this.global.HostedPath + "GetTechRealizationDashboardList?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate
          ).subscribe(list => {

            if (list.StatusCode == 200) {

              let tempList = JSON.parse(list.Output);

              tempList.forEach(ele => {

                this.RealizationList.push({
                  JobCardHeader_IC: ele.JobCardHeader_IC,
                  OrderNo: ele.OrderNo,
                  RealizationPerc: ele.RealizationPerc,
                  RealizationPercVal: ele.RealizationPerc + "%",
                  RealizationDiff: ele.RealizationDiff,
                  JobtypeCode: ele.JobtypeCode,
                  Jobtype: ele.Jobtype,
                  JobtypeVal: this.global.JobTypeFormat(ele.Jobtype),
                  BilledHours: ele.BilledHours,
                  BilledHoursVal: this.global.DisplayTimeFormate(ele.BilledHours) + "hrs",
                  WorkedHours: ele.WorkedHours,
                  WorkedHoursVal: this.global.DisplayTimeFormate(ele.WorkedHours) + "hrs",
                  Ageing: ele.Ageing,
                  JobColor: ele.JobColor
                });

              });

              this.RealizationListCopy = Object.assign([], this.RealizationList);

              this.filterJobCards();

              console.log(this.RealizationListCopy);

              if (refresher != undefined) {
                refresher.complete();
              }

            }
            else {
              console.log(list);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

            this.global.LoadingHide();

          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });

        }
        else {
          console.log(jobCards);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });


    } else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  filterByPercentage1(filter: string) {

    const activeFilterString = this.activeFilter.join(',');

    if (filter === 'ALL') {
      if (activeFilterString === this.RealizationListCopy.join(',')) {
        this.activeFilter = ['ALL'];
      } else {
        this.activeFilter = ['ALL'];
      }
    } else {
      if (activeFilterString.includes(filter)) {
        this.activeFilter = this.activeFilter.filter(f => f !== filter);
      } else {
        const index = this.activeFilter.indexOf('ALL');
        if (index !== -1) {
          this.activeFilter.splice(index, 1);
        }
        this.activeFilter.push(filter);
      }
    }

    this.filterJobCards();

  }

  filterByPercentage(filter: string) {
    if (filter === 'ALL') {

      this.activeFilter = ['ALL'];
    } else {

      const filterIndex = this.activeFilter.indexOf(filter);
      if (filterIndex > -1) {

        this.activeFilter.splice(filterIndex, 1);
      } else {

        const allIndex = this.activeFilter.indexOf('ALL');
        if (allIndex > -1) {

          this.activeFilter.splice(allIndex, 1);
        }
        this.activeFilter.push(filter);
      }
    }


    if (this.activeFilter.length === 0) {
      this.activeFilter = ['ALL'];
    }

    this.filterJobCards();
  }

  filterJobCards() {
    let filteredData = this.RealizationListCopy;

    if (this.activeFilter.indexOf('ALL') === -1 && this.activeFilter.length > 0) {
      filteredData = this.RealizationListCopy.filter(item => {
        return this.activeFilter.some(filter => {
          if (filter === '0-25') {
            return item.RealizationPerc >= 0 && item.RealizationPerc <= 25;
          } else if (filter === '26-50') {
            return item.RealizationPerc > 25 && item.RealizationPerc <= 50;
          } else if (filter === '51-75') {
            return item.RealizationPerc > 50 && item.RealizationPerc <= 75;
          } else if (filter === '>75') {
            return item.RealizationPerc > 75;
          }
          return false;
        });
      });
    }

    this.filteredJobCards = filteredData;
  }

  calculateTotalCount() {
    this.totalCount = (this.RealizationData.Lessthan25 || 0) +
      (this.RealizationData.Between26to50 || 0) +
      (this.RealizationData.Between51to75 || 0) +
      (this.RealizationData.Morethan75 || 0);
    console.log('Total Count:', this.totalCount);
  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  FilterClick() {

    this.global.iscardOpen = !this.global.iscardOpen;

    this.global.FilterList.filter((a) => a.isSelected = false);

    this.global.FilterList.filter((a) => a.id == this.SelectedFilter)[0].isSelected = true;

  }

  FilterListClick(val) {

    this.global.FilterList.filter((a) => a.isSelected = false);
    val.isSelected = true;
    this.SelectedFilter = val.id;

    if (val.id == 6) {
      this.optionsRange.from = new Date().setDate(new Date().getDate() - 30);
      this.optionsRange.to = new Date()
    }

  }

  FilterApplyClick() {

    this.RealizationList = [];
    this.filteredJobCards = [];

    if (this.SelectedFilter == "6") {

      if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
        && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

        this.global.iscardOpen = !this.global.iscardOpen;
        this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
        this.ngOnInit(undefined);

      }
      else {
        this.global.ToastShow("Please enter From date and To date");
      }

    }
    else {
      this.global.iscardOpen = !this.global.iscardOpen;
      this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
      this.ngOnInit(undefined);
    }

  }

  FilterResetClick() {

    this.SelectedFilter = "2";
    this.SelectedFilterName = "Last 7 Days";
    this.global.FilterList[1].isSelected = true;
    this.ngOnInit(undefined);

  }

  DateRangeChange(val) {
    console.log(val);
    this.SearchFromDate = val.from._i;
    this.SearchToDate = val.to._i;
  }

  CalenderStartClick(val) {

    console.log(val);

    //this.optionsRange.from = new Date(val.time).setDate(new Date().getDate() - 30);

    this.optionsRange.from = new Date(new Date().setDate(new Date().getDate() - 60));

    console.log(this.optionsRange);

  }

  RemoveFilteredata() {
    // console.log(data);
    // this.FilterList.splice(data, 1);
    this.filtervalue = false;

  }

  Search() {

    this.filteredJobCards = this.RealizationListCopy.filter(
      p => p.JobtypeVal.toLowerCase().trim().includes(this.SrchText.toLowerCase().trim()) ||
        p.OrderNo.toString().includes(this.SrchText.trim()) ||
        p.RealizationPercVal.toString().includes(this.SrchText.trim()) ||
        p.RealizationDiff.toString().includes(this.SrchText.trim()) ||
        p.BilledHoursVal.toString().includes(this.SrchText.trim()) ||
        p.WorkedHoursVal.toString().includes(this.SrchText.trim())
    );
    console.log(this.filteredJobCards);

  }

  tempRelList = [];
  SortClick() {

    this.tempRelList = this.filteredJobCards;

    if (!this.IsSorted) {
      this.filteredJobCards.sort((a, b) => a.RealizationPerc - b.RealizationPerc);      
      this.IsSorted = true;
    }
    else {
      this.filteredJobCards = Object.assign([], this.tempRelList);
      this.filteredJobCards.sort((a, b) => b.RealizationPerc - a.RealizationPerc);
      this.IsSorted = false;
    }

    console.log(this.filteredJobCards);

  }

}