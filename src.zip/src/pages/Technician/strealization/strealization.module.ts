import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StrealizationPage } from './strealization';

@NgModule({
  declarations: [
    StrealizationPage,
  ],
  imports: [
    IonicPageModule.forChild(StrealizationPage),
  ],
})
export class StrealizationPageModule {}
