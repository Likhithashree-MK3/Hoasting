import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StwipPage } from './stwip';

@NgModule({
  declarations: [
    StwipPage,
  ],
  imports: [
    IonicPageModule.forChild(StwipPage),
  ],
})
export class StwipPageModule {}
