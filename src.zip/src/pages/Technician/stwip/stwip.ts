import { Component } from '@angular/core';
import { AlertController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { StdashboardPage } from '../stdashboard/stdashboard';
import { GlobalProvider } from '../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { StjcdetailsPage } from '../stjcdetails/stjcdetails';
import { StytsPage } from '../styts/styts';


@IonicPage()
@Component({
  selector: 'page-stwip',
  templateUrl: 'stwip.html',
})

export class StwipPage {

  WipList: any = [];
  WipListCopy: any = [];
  SrchText: string;
  IsSorted: boolean = true;
  YtsList: any = [];
  JobCardHedIC2: number;
  selectedPauseActivity: string = '';
  JobCardHedIC: number;
  PauseActivityList: any = [];
  isResionForPauseOpen: boolean = false
  PauseActivityResion: string = "";
  PauseIconPath: string = this.global.HostedPath.split("api")[0] + "UploadedFiles/PauseActivity/";

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public global: GlobalProvider,
    public httpClient: HttpClient) {

    this.global.HeaderTitle = "In Progress";

  }

  ngOnInit(refresher) {

    if (this.global.CheckInternetConnection()) {
      console.log(this.global.UserDetails)
      this.global.LoadingShow("Please wait...");
      this.CallListData();
      this.global.LoadingHide();
      if (refresher != undefined) {
        refresher.complete();
      }
    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(StdashboardPage);
  }

  PauseClick1(e) {

    const confirm = this.alertCtrl.create({
      title: 'Do you want to Pause the job ?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          cssClass: 'BtnCancelPopup',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          cssClass: 'BtnYesPopup',
          handler: () => {

            let PauseAlert = this.alertCtrl.create();
            PauseAlert.setTitle('Reason');

            this.global.MasterData.PauseActivity.forEach(ele => {

              PauseAlert.addInput({
                type: 'radio',
                value: ele.ShortName,
                label: ele.PauseReason,
                checked: false
              });

            });

            PauseAlert.addButton({
              text: 'Reset',
              cssClass: "BtnResetPopup"
            });

            PauseAlert.addButton({
              text: 'Yes',
              cssClass: "BtnYesPopup",
              handler: val => {

                console.log(val);

                if (val == "OT") {

                  const prompt = this.alertCtrl.create({
                    title: 'Reason',
                    message: "Please Enter Other reason",
                    inputs: [
                      {
                        name: 'reason',
                        placeholder: 'Reason'
                      },
                    ],
                    buttons: [
                      {
                        text: 'Cancel',
                        cssClass: "BtnCancelPopup",
                        handler: data => {
                          //PauseAlert.present();
                        }
                      },
                      {
                        text: 'Yes',
                        cssClass: "BtnYesPopup",
                        handler: data => {

                          console.log(data);

                          if (data.reason == "") {
                            this.global.ToastShow("Please Enter Other reason");
                            return false;
                          }
                          else {
                            this.UpdatePuase(e.JobCardHedIC, val, data.reason);
                          }
                        }

                      }]
                  });
                  prompt.present();

                }
                else {
                  let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == val).PauseReason;
                  this.UpdatePuase(e.JobCardHedIC, val, res);
                }

              }

            });

            PauseAlert.present();

          }
        }
      ]
    });
    confirm.present();
  }

  PauseClick(e) {

    this.PauseActivityList = this.global.MasterData.PauseActivity;

    const confirm = this.alertCtrl.create({
      title: 'Do you want to Pause the job ?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          cssClass: 'BtnCancelPopup',
          handler: () => {
            console.log('Disagree clicked');
            this.isResionForPauseOpen = false;
          }
        },
        {
          text: 'Yes',
          cssClass: 'BtnYesPopup',
          handler: () => {

            console.log("PauseActivityList");
            console.log(this.PauseActivityList);

            this.JobCardHedIC = e.JobCardHedIC;
            console.log("JobCardHedIC");
            console.log(this.JobCardHedIC);

            this.isResionForPauseOpen = true;

          }
        }
      ]
    });
    confirm.present();
  }

  ClosePauseContainer() {
    this.isResionForPauseOpen = false;
  }

  ConfirmResionForPause1() {

    console.log(this.selectedPauseActivity);

    if (this.selectedPauseActivity == "OT") {

      if (this.PauseActivityResion == "") {
        this.global.ToastShow("Please Enter Other reason");
        return false;
      }
      else {
        this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, this.PauseActivityResion);
        this.isResionForPauseOpen = false;
      }
    }
    else {
      let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == this.selectedPauseActivity).PauseReason;
      this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, res);
      this.isResionForPauseOpen = false;
    }

  }

  ConfirmResionForPause() {

    console.log(this.selectedPauseActivity);

    if (this.selectedPauseActivity != "") {

      if (this.selectedPauseActivity == "OT") {

        if (this.PauseActivityResion == "") {
          this.global.ToastShow("Please Enter Other reason");
          return false;
        }
        else {
          this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, this.PauseActivityResion);
          this.isResionForPauseOpen = false;
        }
      }
      else if (this.selectedPauseActivity == 'WOV') {

        let Description = "Tech " + this.global.UserDetails[0].Name + " working on another vehicle";
        this.global.RealTimeInsertIntoTrNotification2(this.WipListCopy[0].JobCardHedIC, this.WipListCopy[0].AssignedBy, this.WipListCopy[0].OrderNo, Description, 'Medium');
        let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == this.selectedPauseActivity).PauseReason;
        this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, res);
        this.isResionForPauseOpen = false;
      }
      else if (this.selectedPauseActivity == 'SC') {

        let Description = "Shift Change alert for Tech " + this.global.UserDetails[0].Name;
        this.global.RealTimeInsertIntoTrNotification2(this.WipListCopy[0].JobCardHedIC, this.WipListCopy[0].AssignedBy, this.WipListCopy[0].OrderNo, Description, 'Medium');
        let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == this.selectedPauseActivity).PauseReason;
        this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, res);
        this.isResionForPauseOpen = false;
      }
      else {
        let res = this.global.MasterData.PauseActivity.find(a => a.ShortName == this.selectedPauseActivity).PauseReason;
        this.UpdatePuase(this.JobCardHedIC, this.selectedPauseActivity, res);
        this.isResionForPauseOpen = false;
      }

    }
    else {
      this.global.ToastShow("Please select the Pause Reason");
    }

  }

  PauseActivityListClick(val) {

    setTimeout(() => {
      if (val.ShortName == "OT") {
        document.getElementById("ResionForPauseListContainer").scrollTop = 200;
      }
    }, 10);

  }

  CompleteClick(e) {

    const confirm = this.alertCtrl.create({
      title: 'Do you want to Complete the job ?',
      buttons: [
        {
          text: 'Cancel',
          cssClass: 'BtnCancelPopup',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          cssClass: 'BtnYesPopup',
          handler: () => {

            if (this.global.CheckInternetConnection()) {

              this.httpClient.post<any>(this.global.HostedPath + "UpdateOnComplete?TechnicianID=" + this.global.UserDetails[0].Employee_IC + "&JobCardHeaderIC=" + e.JobCardHedIC, {}).subscribe(result => {
                console.log(result);
                if (result.StatusCode == 200) {

                  // this.global.ToastShow("Job Submitted Successfully");
                  // this.ngOnInit(undefined);                  

                  this.httpClient.get<any>(this.global.HostedPath + "GetTechDashboardCounts?Technician_ID=" + this.global.UserDetails[0].Employee_IC + "&Type=2" + "&FromeDate=02/14/2024&ToDate=03/14/2024").subscribe(tecjCount => {

                    console.log(JSON.parse(tecjCount.Output));

                    if (tecjCount.StatusCode == 200) {

                      if (JSON.parse(tecjCount.Output)[0].WIP > 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp1.png">',
                          subTitle: '<center>Great Job!!!<br/> Keep up the good work!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {
                              this.CallListData();
                            }
                          }]
                        });
                        alert.present();

                      }
                      else if (JSON.parse(tecjCount.Output)[0].WIP == 0 && JSON.parse(tecjCount.Output)[0].YTS > 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp1.png">',
                          subTitle: '<center>Great Job!!!<br/> Keep up the good work!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {

                              if (JSON.parse(tecjCount.Output)[0].YTS >= 1 && JSON.parse(tecjCount.Output)[0].WIP == 0) {

                                let Description = encodeURIComponent("JC " + this.YtsList[0].OrderNo + " has been allocated");
                                this.global.RealTimeInsertIntoTrAlert2(this.JobCardHedIC2, this.global.UserDetails[0].Employee_IC, Description, 'High');

                              }

                              this.navCtrl.setRoot(StytsPage);

                            }
                          }]
                        });
                        alert.present();

                      }
                      else if (JSON.parse(tecjCount.Output)[0].WIP == 0 && JSON.parse(tecjCount.Output)[0].YTS == 0) {

                        const alert = this.alertCtrl.create({

                          title: '<img src="assets/imgs/ThumbsUp.png">',
                          subTitle: '<center>Great Job!!<br />Keep Going!!!<center>',
                          buttons: [{
                            text: 'OK',
                            cssClass: 'BtnOkPopup',
                            handler: () => {
                              this.navCtrl.setRoot(StdashboardPage);
                            }
                          }]
                        });
                        alert.present();

                      }

                    }
                    else {
                      console.log(tecjCount);
                      this.global.ToastShow("Something went wrong, Pls try again later");
                    }

                  }, (error) => {
                    console.log(error);
                  });

                }
                else {
                  console.log(result);
                  this.global.ToastShow("Something went wrong, Pls try again later");
                }


              }, (error) => {
                console.log(error);
              });

            }
            else {
              this.global.ToastShow(this.global.NetworkMessage);
            }

          }
        }
      ]
    });
    confirm.present();
  }

  CallListData() {

    this.httpClient.get<any>(this.global.HostedPath + "GetTechInProgress?Technician_ID=" + this.global.UserDetails[0].Employee_IC
    ).subscribe(list => {

      if (list.StatusCode == 200) {

        this.WipList = JSON.parse(list.Output);

        this.WipList.sort((a, b) => b.T1 - a.T1);
        console.log(this.WipList);
        this.WipListCopy = this.WipList;

        this.httpClient.get<any>(this.global.HostedPath + "GetTechYetToStart?Technician_ID=" + this.global.UserDetails[0].Employee_IC
        ).subscribe(list => {

          if (list.StatusCode == 200) {

            this.YtsList = JSON.parse(list.Output);

            this.YtsList.sort((a, b) => b.T1 - a.T1);
            console.log(this.YtsList);

            for (let i = 0; i < this.YtsList.length; i++) {
              this.JobCardHedIC2 = this.YtsList[0].JobCardHedIC;
              break;
            }
          }
          else {
            console.log(list);
            this.global.ToastShow("Something went wrong, Pls try again later");
          }

        }, (error) => {
          console.log(error);
          this.global.LoadingHide();
        });

      }
      else {
        console.log(list);
        this.global.ToastShow("Something went wrong, Pls try again later");
      }
    }, (error) => {
      console.log(error);
      this.global.LoadingHide();
    });

  }

  Search() {
    console.log(this.SrchText)
    this.WipList = this.WipListCopy.filter(
      p => p.Jobtype.toLowerCase().trim().includes(this.SrchText.toLowerCase().trim()) ||
        p.OrderNo.toString().includes(this.SrchText.trim()) ||
        p.VehicleNo.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.IsAppointmentDone.toString().includes(this.SrchText.trim()) ||
        p.CustomerName.toLowerCase().includes(this.SrchText.toLowerCase().trim()) ||
        p.ServiceAdvisor.toString().includes(this.SrchText.trim()) ||
        p.Ageing.toString().includes(this.SrchText.trim()) ||
        p.T1.toString().includes(this.SrchText.trim()) ||
        p.EDD.toString().includes(this.SrchText.trim()) ||
        p.ETD.toString().includes(this.SrchText.trim())
    );
    console.log(this.WipList);
  }

  SortClick() {

    if (!this.IsSorted) {
      this.WipList.sort((a, b) => new Date(a.T1).valueOf() - new Date(b.T1).valueOf());
      this.IsSorted = true;
    }
    else {
      this.WipList = Object.assign([], this.WipListCopy);
      this.IsSorted = false;
    }

    console.log(this.WipList);

  }

  UpdatePuase(JC, ShortName, reason) {

    if (this.global.CheckInternetConnection()) {

      this.httpClient.post<any>(this.global.HostedPath + "UpdateOnPause?TechnicianID=" + this.global.UserDetails[0].Employee_IC + "&JobCardHeaderIC=" + JC + "&ShortName=" + ShortName + "&Reason=" + reason, {}).subscribe(result => {

        if (result.StatusCode == 200) {

          this.global.ToastShow("Job Paused");
          this.CallListData();

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }


      }, (error) => {
        console.log(error);
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  JCClick(jc) {

    this.global.CurrentPage = "StwipPage";

    this.navCtrl.setRoot(StjcdetailsPage, { data: jc })

  }

}