import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScdashboardPage } from './scdashboard';

@NgModule({
  declarations: [
    ScdashboardPage,
  ],
  imports: [
    IonicPageModule.forChild(ScdashboardPage),
  ],
})
export class ScdashboardPageModule {}
