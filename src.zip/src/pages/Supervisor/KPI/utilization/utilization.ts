import { Component } from '@angular/core';
import { ActionSheetController, AlertController, IonicPage, ModalController, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../../providers/global/global';
import { DashboardPage } from '../dashboard/dashboard';
import { HttpClient } from '@angular/common/http';
import { CalendarComponentOptions } from 'ion2-calendar';

@IonicPage()
@Component({
  selector: 'page-utilization',
  templateUrl: 'utilization.html',
})

export class UtilizationPage {

  UtilizationDetails: any = {};
  EmployeeListUtilization: any = [];
  FinalEmployeeListUtilization: any = [];
  EmployeeDetailsUtilization: any = {};
  FilterList = ["Last 7 days"];
  clickedindex;
  SelectedFilter = "2";
  SelectedFilterName = "Last 7 Days";
  LastDay: any;
  SearchFromDate: any;
  SearchToDate: any;
  Last6Month: any;
  TodaysDate: any;
  IsSorted: boolean = false;
  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    color: "danger",
    from: new Date().setDate(new Date().getDate() - 30),
    to: new Date()
  };
  // Initialize an array to keep track of the display state of each item
  itemDisplayStates: boolean[] = [];
  cards: any[] = [];
  // Initialize isExpanded array with false for each card
  isExpanded: boolean[] = new Array(this.cards.length).fill(false);
  // Assuming you have some data array named elements
  elements: any[] = [/* your data */];
  DownClicked: boolean;
  filteredJobCards: any[] = []; // Initialize with an empty array
  activeFilter: string[] = ['ALL']; // Default to 'ALL' filter
  totalCount: number = 0;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    public global: GlobalProvider,
    public actionSheetCtrl: ActionSheetController,
    public alertCtrl: AlertController,
    public modalCtrl: ModalController) {

    this.global.HeaderTitle = "Utilization";

    this.LastDay = new Date(new Date().setDate(new Date().getDate() - 1));

    let date = new Date();
    let date1 = new Date();

    let d1 = new Date(date.setMonth(date.getMonth() - 6));
    this.Last6Month = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));

    this.TodaysDate = date1.getFullYear() + "-" + ((date1.getMonth() + 1) > 9 ? (date1.getMonth() + 1) : ("0" + (date1.getMonth() + 1))) + "-" + ((date1.getDate() + 1) > 9 ? (date1.getDate()) : ("0" + (date1.getDate())));

  }

  ngOnInit(refresher?) {
    this.activeFilter = ['ALL'];
    this.fetchDataAndFilter(refresher);
  }

  fetchDataAndFilter(refresher?) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      let fromDate;
      let toDate;

      if (this.SelectedFilter == "6") {
        let d1 = new Date(this.SearchFromDate);
        fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
        let d2 = new Date(this.SearchToDate);
        toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
      } else {
        fromDate = this.TodaysDate;
        toDate = this.TodaysDate;
      }

      this.httpClient.get<any>(this.global.HostedPath + "GetDashboardUtilization?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {

        if (result.StatusCode == 200) {

          this.UtilizationDetails = JSON.parse(result.Output)[0];

          this.calculateTotalCount();

          console.log(this.UtilizationDetails);

          this.httpClient.get<any>(this.global.HostedPath + "GetEmployeeListUtilization?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {
            if (result.StatusCode == 200) {

              let tempList = JSON.parse(result.Output);

              tempList.forEach(ele => {

                this.EmployeeListUtilization.push({
                  EmployeeID: ele.EmployeeID,
                  EmployeeCode: ele.EmployeeCode,
                  EmployeeName: ele.EmployeeName,
                  CompetencyLevel: ele.CompetencyLevel,
                  UtilizationPerc: ele.UtilizationPerc,
                  UtilizationDiff: ele.UtilizationDiff,
                  JobRole: ele.JobRole,
                  Ageing: ele.Ageing,
                  UtilizationPercVal: ele.UtilizationPerc + "%"
                });

              });

              this.FinalEmployeeListUtilization = Object.assign([], this.EmployeeListUtilization);

              this.filterJobCards();

              console.log(this.FinalEmployeeListUtilization);

              if (refresher != undefined) {
                refresher.complete();
              }

            } else {
              console.log(result);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

            this.global.LoadingHide();

          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });


        } else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }


      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });


    } else {
      this.global.ToastShow(this.global.NetworkMessage);
    }


  }

  filterByPercentage1(filter: string) {
    const activeFilterString = this.activeFilter.join(',');

    if (filter === 'ALL') {
      if (activeFilterString === this.FilterList.join(',')) {
        this.activeFilter = ['ALL'];
      } else {
        this.activeFilter = ['ALL'];
      }
    } else {
      if (activeFilterString.includes(filter)) {
        this.activeFilter = this.activeFilter.filter(f => f !== filter);
      } else {
        const index = this.activeFilter.indexOf('ALL');
        if (index !== -1) {
          this.activeFilter.splice(index, 1);
        }
        this.activeFilter.push(filter);
      }
    }
    this.filterJobCards();
  }

  filterByPercentage(filter: string) {
    if (filter === 'ALL') {

      this.activeFilter = ['ALL'];
    } else {

      const filterIndex = this.activeFilter.indexOf(filter);
      if (filterIndex > -1) {

        this.activeFilter.splice(filterIndex, 1);
      } else {

        const allIndex = this.activeFilter.indexOf('ALL');
        if (allIndex > -1) {

          this.activeFilter.splice(allIndex, 1);
        }
        this.activeFilter.push(filter);
      }
    }


    if (this.activeFilter.length === 0) {
      this.activeFilter = ['ALL'];
    }

    this.filterJobCards();
  }

  filterJobCards() {

    if (this.activeFilter.indexOf('ALL') !== -1 || this.activeFilter.length === 0) {

      this.filteredJobCards = this.FinalEmployeeListUtilization;

    } else {

      this.filteredJobCards = this.FinalEmployeeListUtilization.filter(e => {

        return this.activeFilter.some(filter => {
          if (filter === '0-25') {
            return e.UtilizationPerc >= 0 && e.UtilizationPerc <= 25;
          } else if (filter === '26-50') {
            return e.UtilizationPerc > 25 && e.UtilizationPerc <= 50;
          } else if (filter === '51-75') {
            return e.UtilizationPerc > 50 && e.UtilizationPerc <= 75;
          } else if (filter === '>75') {
            return e.UtilizationPerc > 75;
          }
          return false;
        });

      });

    }

    this.EmployeeListUtilization = Object.assign([], this.filteredJobCards);

  }

  calculateTotalCount() {
    this.totalCount = (this.UtilizationDetails.Lessthan25 || 0) +
      (this.UtilizationDetails.Between26to50 || 0) +
      (this.UtilizationDetails.Between51to75 || 0) +
      (this.UtilizationDetails.Morethan75 || 0);
    console.log('Total Count:', this.totalCount);
  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(DashboardPage);
  }

  FilterClick1() {

    let alert = this.alertCtrl.create({
      title: 'Duration',
      inputs: [
        {
          type: 'radio',
          label: 'YTD',
          value: "5",
          checked: (this.SelectedFilter == "5") ? true : false
        },
        {
          type: 'radio',
          label: 'LM',
          value: "4",
          checked: (this.SelectedFilter == "4") ? true : false
        },
        {
          type: 'radio',
          label: 'MTD',
          value: "3",
          checked: (this.SelectedFilter == "3") ? true : false
        },
        {
          type: 'radio',
          label: 'Last 7 Days',
          value: "2",
          checked: (this.SelectedFilter == "2") ? true : false
        },
        {
          type: 'radio',
          label: 'Last Day',
          value: "1",
          checked: (this.SelectedFilter == "1") ? true : false
        },
        {
          type: 'radio',
          label: 'Date Range',
          value: "6",
          checked: (this.SelectedFilter == "6") ? true : false
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Confirm',
          handler: (data) => {

            this.SelectedFilter = data;

            switch (data) {
              case "1":
                this.SelectedFilterName = "Last Day";
                break;
              case "2":
                this.SelectedFilterName = "Last 7 Days";
                break;
              case "3":
                this.SelectedFilterName = "MTD";
                break;
              case "4":
                this.SelectedFilterName = "LM";
                break;
              case "5":
                this.SelectedFilterName = "YTD";
                break;
              case "6":
                this.SelectedFilterName = "Date Range";
                break;
              default:
                this.SelectedFilterName = "Last 7 Days";
                break;
            }

            if (this.SelectedFilter != "6") {
              this.ngOnInit(undefined);
            }

          }
        }
      ]
    });
    alert.present();

  }

  FilterClick2() {

    let actionSheet = this.actionSheetCtrl.create({

      title: 'Select filter option',
      buttons: [
        {
          text: 'Last Day',
          handler: () => {
            this.SelectedFilter = "1";
            this.SelectedFilterName = "Last Day";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'Last 7 Days',
          handler: () => {
            this.SelectedFilter = "2";
            this.SelectedFilterName = "Last 7 Days";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'MTD',
          handler: () => {
            this.SelectedFilter = "3";
            this.SelectedFilterName = "MTD";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'LM',
          handler: () => {
            this.SelectedFilter = "4";
            this.SelectedFilterName = "LM";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'YTD',
          handler: () => {
            this.SelectedFilter = "5";
            this.SelectedFilterName = "YTD";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'Date Range',
          handler: () => {
            this.SelectedFilter = "6";
            this.SelectedFilterName = "Date Range";
          }
        }
      ],
      enableBackdropDismiss: true
    });

    actionSheet.present();

  }

  FilterClick() {

    this.global.iscardOpen = !this.global.iscardOpen;

    this.global.FilterList.filter((a) => a.isSelected = false);

    this.global.FilterList.filter((a) => a.id == this.SelectedFilter)[0].isSelected = true;

  }

  FilterListClick(val) {

    this.global.FilterList.filter((a) => a.isSelected = false);
    val.isSelected = true;
    this.SelectedFilter = val.id;

    if (val.id == 6) {
      this.optionsRange.from = new Date().setDate(new Date().getDate() - 30);
      this.optionsRange.to = new Date()
    }

  }

  FilterApplyClick() {

    this.EmployeeListUtilization = [];
    this.filteredJobCards = []; 

    if (this.SelectedFilter == "6") {

      if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
        && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

        this.global.iscardOpen = !this.global.iscardOpen;
        this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
        this.ngOnInit(undefined);

      }
      else {
        this.global.ToastShow("Please enter From date and To date");
      }

    }
    else {
      this.global.iscardOpen = !this.global.iscardOpen;
      this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
      this.ngOnInit(undefined);
    }

  }

  FilterResetClick() {

    this.SelectedFilter = "2";
    this.SelectedFilterName = "Last 7 Days";
    this.global.FilterList[1].isSelected = true;
    this.ngOnInit(undefined);

  }

  DateRangeChange(val) {
    console.log(val);
    this.SearchFromDate = val.from._i;
    this.SearchToDate = val.to._i;
  }

  CalenderStartClick(val) {

    console.log(val);

    //this.optionsRange.from = new Date(val.time).setDate(new Date().getDate() - 30);

    this.optionsRange.from = new Date(new Date().setDate(new Date().getDate() - 60));

    console.log(this.optionsRange);

  }

  RemoveFilteredata(data) {
    console.log(data);
    this.FilterList.splice(data, 1);
  }

  initializeIsExpandedArray() {
    const n = this.elements.length;
    this.isExpanded = new Array(n).fill(false);
  }

  toggleDetails(index: number) {

    if (this.isExpanded[index]) {
      this.isExpanded[index] = false;
      this.DownClicked = false
    } else {
      this.isExpanded[index] = true;
      this.DownClicked = true
    }

  }

  DownArrowClick(i, emp) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      let fromDate = "12-12-2024";

      this.httpClient.get<any>(this.global.HostedPath + "GetEmployeeDetailsUtilization?EmployeeID=" + emp.EmployeeID + "&CurrentDate=" + fromDate).subscribe(result => {

        if (result.StatusCode == 200) {

          this.EmployeeDetailsUtilization = JSON.parse(result.Output)[0];

          console.log(this.EmployeeDetailsUtilization);

          //this.clickedindex = i;
          //this.isExpanded = !this.isExpanded;

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  EmployeeSearch(val) {

    this.filteredJobCards = this.EmployeeListUtilization.filter(e => e.EmployeeName.toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.CompetencyLevel.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.UtilizationPercVal.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.UtilizationDiff.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.JobRole.toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.EmployeeCode.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
    );

    console.log(this.filteredJobCards);

  }

  tempRelList = [];
  EmployeeSortClick() {

    this.tempRelList = this.filteredJobCards;

    if (!this.IsSorted) {
      this.filteredJobCards.sort((a, b) => a.UtilizationPerc - b.UtilizationPerc);
      this.IsSorted = true;
    }
    else {
      this.filteredJobCards = Object.assign([], this.EmployeeListUtilization);
      this.filteredJobCards.sort((a, b) => b.UtilizationPerc - a.UtilizationPerc);
      this.IsSorted = false;
    }

    console.log(this.filteredJobCards);

  }

  SearchClick() {

    if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
      && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

      this.ngOnInit(undefined);

    }
    else {
      this.global.ToastShow("Please enter From date and To date");
    }

  }

}
