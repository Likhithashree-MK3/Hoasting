import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RealizationPage } from './realization';

@NgModule({
  declarations: [
    RealizationPage,
  ],
  imports: [
    IonicPageModule.forChild(RealizationPage),
  ],
})
export class RealizationPageModule {}
