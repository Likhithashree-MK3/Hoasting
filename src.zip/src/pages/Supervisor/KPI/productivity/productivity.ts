import { Component } from '@angular/core';
import { ActionSheetController, AlertController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { DashboardPage } from '../dashboard/dashboard';
import { HttpClient } from '@angular/common/http';
import { GlobalProvider } from '../../../../providers/global/global';
import { CalendarComponentOptions } from 'ion2-calendar';

@IonicPage()
@Component({
  selector: 'page-productivity',
  templateUrl: 'productivity.html',
})

export class ProductivityPage {

  ProductivityData: any = [];
  ProductivityList: any = [];
  FilterList = ["MTD"];

  ProductivityDetails: any = {};
  DateListProductivity: any = [];
  FinalDateListProductivity: any = [];
  SelectedFilter = "2";
  SelectedFilterName = "Last 7 Days";
  LastDay: any;
  Last6Month: any;
  TodaysDate: any;
  SearchFromDate: any;
  SearchToDate: any;
  IsSorted: boolean = false;
  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    color: "danger",
    from: new Date().setDate(new Date().getDate() - 30),
    to: new Date()
  };
  filteredJobCards: any[] = []; // Initialize with an empty array
  activeFilter: string[] = ['ALL']; // Default to 'ALL' filter
  totalCount: number = 0;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public httpClient: HttpClient,
    public global: GlobalProvider,
    public actionSheetCtrl: ActionSheetController,
    public alertCtrl: AlertController) {

    this.global.HeaderTitle = "Productivity";

    this.LastDay = new Date(new Date().setDate(new Date().getDate() - 1));

    let date = new Date();
    let date1 = new Date();

    let d1 = new Date(date.setMonth(date.getMonth() - 6));
    this.Last6Month = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));

    this.TodaysDate = date1.getFullYear() + "-" + ((date1.getMonth() + 1) > 9 ? (date1.getMonth() + 1) : ("0" + (date1.getMonth() + 1))) + "-" + ((date1.getDate() + 1) > 9 ? (date1.getDate()) : ("0" + (date1.getDate())));

  }

  ngOnInit(refresher?) {
    this.activeFilter = ['ALL'];
    this.fetchDataAndFilter(refresher);
  }

  fetchDataAndFilter(refresher?) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      let fromDate;
      let toDate;

      if (this.SelectedFilter == "6") {
        let d1 = new Date(this.SearchFromDate);
        fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
        let d2 = new Date(this.SearchToDate);
        toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
      } else {
        fromDate = this.TodaysDate;
        toDate = this.TodaysDate;
      }

      this.httpClient.get<any>(this.global.HostedPath + "GetDashboardProductivity?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {

        if (result.StatusCode == 200) {

          this.ProductivityDetails = JSON.parse(result.Output)[0];

          this.calculateTotalCount();

          console.log(this.ProductivityDetails);

          this.httpClient.get<any>(this.global.HostedPath + "GetProductivityDateList?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {

            if (result.StatusCode == 200) {

              let tempLIst = JSON.parse(result.Output);

              tempLIst.forEach(ele => {

                this.DateListProductivity.push({
                  ProductivityDate: ele.ProductivityDate,
                  ProductivityPerc: ele.ProductivityPerc,
                  ProductivityDiff: ele.ProductivityDiff,
                  BilledHours: ele.BilledHours,
                  AvailableHours: ele.AvailableHours,
                  Ageing: ele.Ageing,
                  BilledHoursVal: this.global.DisplayTimeFormate(ele.BilledHours) + "hrs",
                  AvailableHoursVal: this.global.DisplayTimeFormate(ele.AvailableHours) + "hrs"
                })

              });

              this.FinalDateListProductivity = Object.assign([], this.DateListProductivity);

              this.filterJobCards();

              console.log(this.FinalDateListProductivity);

              if (refresher != undefined) {
                refresher.complete();
              }

            }
            else {
              console.log(result);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

            this.global.LoadingHide();

          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });


    } else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  filterByPercentage1(filter: string) {

    const activeFilterString = this.activeFilter.join(',');

    if (filter === 'ALL') {
      if (activeFilterString === this.FilterList.join(',')) {
        this.activeFilter = ['ALL'];
      } else {
        this.activeFilter = ['ALL'];
      }
    } else {
      if (activeFilterString.includes(filter)) {
        this.activeFilter = this.activeFilter.filter(f => f !== filter);
      } else {
        const index = this.activeFilter.indexOf('ALL');
        if (index !== -1) {
          this.activeFilter.splice(index, 1);
        }
        this.activeFilter.push(filter);
      }
    }

    this.filterJobCards();

  }

  filterByPercentage(filter: string) {
    if (filter === 'ALL') {

      this.activeFilter = ['ALL'];
    } else {

      const filterIndex = this.activeFilter.indexOf(filter);
      if (filterIndex > -1) {

        this.activeFilter.splice(filterIndex, 1);
      } else {

        const allIndex = this.activeFilter.indexOf('ALL');
        if (allIndex > -1) {

          this.activeFilter.splice(allIndex, 1);
        }
        this.activeFilter.push(filter);
      }
    }


    if (this.activeFilter.length === 0) {
      this.activeFilter = ['ALL'];
    }

    this.filterJobCards();
  }

  filterJobCards() {

    if (this.activeFilter.indexOf('ALL') !== -1 || this.activeFilter.length === 0) {
      this.filteredJobCards = this.FinalDateListProductivity;
    } else {
      this.filteredJobCards = this.FinalDateListProductivity.filter(e => {
        return this.activeFilter.some(filter => {
          if (filter === '0-25') {
            return e.ProductivityPerc >= 0 && e.ProductivityPerc <= 25;
          } else if (filter === '26-50') {
            return e.ProductivityPerc > 25 && e.ProductivityPerc <= 50;
          } else if (filter === '51-75') {
            return e.ProductivityPerc > 50 && e.ProductivityPerc <= 75;
          } else if (filter === '>75') {
            return e.ProductivityPerc > 75;
          }
          return false;
        });
      });
    }

    this.DateListProductivity = Object.assign([], this.filteredJobCards);

  }

  calculateTotalCount() {
    this.totalCount = (this.ProductivityDetails.Lessthan25 || 0) +
      (this.ProductivityDetails.Between26to50 || 0) +
      (this.ProductivityDetails.Between51to75 || 0) +
      (this.ProductivityDetails.Morethan75 || 0);
    console.log('Total Count:', this.totalCount);
  }

  ngOnInit1(refresher) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      let fromDate;
      let toDate;

      if (this.SelectedFilter == "6") {
        let d1 = new Date(this.SearchFromDate);
        fromDate = d1.getFullYear() + "-" + ((d1.getMonth() + 1) > 9 ? (d1.getMonth() + 1) : ("0" + (d1.getMonth() + 1))) + "-" + ((d1.getDate() + 1) > 9 ? (d1.getDate()) : ("0" + (d1.getDate())));
        let d2 = new Date(this.SearchToDate);
        toDate = d2.getFullYear() + "-" + ((d2.getMonth() + 1) > 9 ? (d2.getMonth() + 1) : ("0" + (d2.getMonth() + 1))) + "-" + ((d2.getDate() + 1) > 9 ? (d2.getDate()) : ("0" + (d2.getDate())));
      }
      else {
        fromDate = this.TodaysDate;
        toDate = this.TodaysDate;
      }

      this.httpClient.get<any>(this.global.HostedPath + "GetDashboardProductivity?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {

        if (result.StatusCode == 200) {

          this.ProductivityDetails = JSON.parse(result.Output)[0];

          console.log(this.ProductivityDetails);

          this.httpClient.get<any>(this.global.HostedPath + "GetProductivityDateList?BranchID=" + this.global.UserDetails[0].BranchID + "&Type=" + this.SelectedFilter + "&FromeDate=" + fromDate + "&ToDate=" + toDate).subscribe(result => {

            if (result.StatusCode == 200) {

              this.DateListProductivity = JSON.parse(result.Output);

              this.FinalDateListProductivity = Object.assign([], this.DateListProductivity);

              console.log(this.FinalDateListProductivity);

              if (refresher != undefined) {
                refresher.complete();
              }

            }
            else {
              console.log(result);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

            this.global.LoadingHide();

          }, (error) => {
            console.log(error);
            this.global.LoadingHide();
          });

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  FilterClick1() {

    let alert = this.alertCtrl.create({
      title: 'Duration',
      inputs: [
        {
          type: 'radio',
          label: 'YTD',
          value: "5",
          checked: (this.SelectedFilter == "5") ? true : false
        },
        {
          type: 'radio',
          label: 'LM',
          value: "4",
          checked: (this.SelectedFilter == "4") ? true : false
        },
        {
          type: 'radio',
          label: 'MTD',
          value: "3",
          checked: (this.SelectedFilter == "3") ? true : false
        },
        {
          type: 'radio',
          label: 'Last 7 Days',
          value: "2",
          checked: (this.SelectedFilter == "2") ? true : false
        },
        {
          type: 'radio',
          label: 'Last Day',
          value: "1",
          checked: (this.SelectedFilter == "1") ? true : false
        },
        {
          type: 'radio',
          label: 'Date Range',
          value: "6",
          checked: (this.SelectedFilter == "6") ? true : false
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Confirm',
          handler: (data) => {

            this.SelectedFilter = data;

            switch (data) {
              case "1":
                this.SelectedFilterName = "Last Day";
                break;
              case "2":
                this.SelectedFilterName = "Last 7 Days";
                break;
              case "3":
                this.SelectedFilterName = "MTD";
                break;
              case "4":
                this.SelectedFilterName = "Last Month";
                break;
              case "5":
                this.SelectedFilterName = "YTD";
                break;
              case "6":
                this.SelectedFilterName = "Date Range";
                break;
              default:
                this.SelectedFilterName = "Last 7 Days";
                break;
            }

            if (this.SelectedFilter != "6") {
              this.ngOnInit(undefined);
            }

          }
        }
      ]
    });
    alert.present();

  }

  FilterClick2() {

    let actionSheet = this.actionSheetCtrl.create({

      title: 'Select filter option',
      buttons: [
        {
          text: 'Last Day',
          handler: () => {
            this.SelectedFilter = "1";
            this.SelectedFilterName = "Last Day";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'Last 7 Days',
          handler: () => {
            this.SelectedFilter = "2";
            this.SelectedFilterName = "Last 7 Days";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'MTD',
          handler: () => {
            this.SelectedFilter = "3";
            this.SelectedFilterName = "MTD";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'LM',
          handler: () => {
            this.SelectedFilter = "4";
            this.SelectedFilterName = "Last Month";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'YTD',
          handler: () => {
            this.SelectedFilter = "5";
            this.SelectedFilterName = "YTD";
            this.ngOnInit(undefined);
          }
        },
        {
          text: 'Date Range',
          handler: () => {
            this.SelectedFilter = "6";
            this.SelectedFilterName = "Date Range";
          }
        }
      ],
      enableBackdropDismiss: true
    });

    actionSheet.present();

  }

  FilterClick() {

    this.global.iscardOpen = !this.global.iscardOpen;

    this.global.FilterList.filter((a) => a.isSelected = false);

    this.global.FilterList.filter((a) => a.id == this.SelectedFilter)[0].isSelected = true;

  }

  FilterListClick(val) {

    this.global.FilterList.filter((a) => a.isSelected = false);
    val.isSelected = true;
    this.SelectedFilter = val.id;

    if (val.id == 6) {
      this.optionsRange.from = new Date().setDate(new Date().getDate() - 30);
      this.optionsRange.to = new Date()
    }

  }

  FilterApplyClick() {

    this.DateListProductivity = [];
    this.filteredJobCards = [];

    if (this.SelectedFilter == "6") {

      if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
        && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

        this.global.iscardOpen = !this.global.iscardOpen;
        this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
        this.ngOnInit(undefined);

      }
      else {
        this.global.ToastShow("Please enter From date and To date");
      }

    }
    else {
      this.global.iscardOpen = !this.global.iscardOpen;
      this.SelectedFilterName = this.global.FilterList.filter(a => a.id == this.SelectedFilter)[0].name;
      this.ngOnInit(undefined);
    }

  }

  FilterResetClick() {

    this.SelectedFilter = "2";
    this.SelectedFilterName = "Last 7 Days";
    this.global.FilterList[1].isSelected = true;
    this.ngOnInit(undefined);

  }

  DateRangeChange(val) {
    console.log(val);
    this.SearchFromDate = val.from._i;
    this.SearchToDate = val.to._i;
  }

  CalenderStartClick(val) {

    console.log(val);

    //this.optionsRange.from = new Date(val.time).setDate(new Date().getDate() - 30);

    this.optionsRange.from = new Date(new Date().setDate(new Date().getDate() - 60));

    console.log(this.optionsRange);

  }

  RemoveFilteredata(data) {
    this.FilterList.splice(data, 1);
  }

  BackClick() {
    this.navCtrl.setRoot(DashboardPage);
  }

  DateSearch(val) {

    this.filteredJobCards = this.DateListProductivity.filter(e => e.ProductivityDate.toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.ProductivityPerc.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.ProductivityDiff.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.BilledHoursVal.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.AvailableHoursVal.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
    );

    console.log(this.filteredJobCards);

  }

  tempRelList = [];
  DateSortClick() {

    this.tempRelList = this.filteredJobCards;

    if (!this.IsSorted) {
      this.filteredJobCards.sort((a, b) => a.ProductivityPerc - b.ProductivityPerc);
      this.IsSorted = true;
    }
    else {
      this.filteredJobCards = Object.assign([], this.DateListProductivity);
      this.filteredJobCards.sort((a, b) => b.ProductivityPerc - a.ProductivityPerc);
      this.IsSorted = false;
    }

    console.log(this.filteredJobCards);

  }

  SearchClick() {

    if (this.SearchFromDate != undefined && this.SearchFromDate != null && this.SearchFromDate != ""
      && this.SearchToDate != undefined && this.SearchToDate != null && this.SearchToDate != "") {

      this.ngOnInit(undefined);

    }
    else {
      this.global.ToastShow("Please enter From date and To date");
    }

  }

}
