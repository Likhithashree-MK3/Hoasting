import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechpdetailsPage } from './sctechpdetails';

@NgModule({
  declarations: [
    SctechpdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechpdetailsPage),
  ],
})
export class SctechpdetailsPageModule {}
