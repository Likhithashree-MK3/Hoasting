import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../../providers/global/global';
import { SctechpausePage } from '../sctechpause/sctechpause';

@IonicPage()
@Component({
  selector: 'page-sctechpdetails',
  templateUrl: 'sctechpdetails.html',
})

export class SctechpdetailsPage {

  PauseList: any = [];
  FinalPauseList: any = [];
  IsSorted: boolean = false;
  SelectedTechnician: any;

  constructor(public navCtrl: NavController,
    public httpClient: HttpClient,
    public global: GlobalProvider,
    public navParams: NavParams) {

    this.global.HeaderTitle = "Pause";

    this.SelectedTechnician = this.navParams.get("data");

    console.log(this.SelectedTechnician);

  }

  ngOnInit(refresher) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetPausedTechnicianDetailsList?TechnicianID=" + this.SelectedTechnician.EmployeeID
      ).subscribe(result => {

        if (result.StatusCode == 200) {

          this.PauseList = JSON.parse(result.Output);

          this.FinalPauseList = Object.assign([], this.PauseList);

          console.log(this.PauseList);

          if (refresher != undefined) {
            refresher.complete();
          }

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(SctechpausePage);
  }

  JCSearch(val) {

    this.FinalPauseList = this.PauseList.filter(e => e.EmployeeName.toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.JCOrderNo.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.JobRole.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.EmployeeCode.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.CompetencyLevel.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.AvailableFrom.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.PauseReason.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
    );

    console.log(this.FinalPauseList);

  }

  JCSortClick() {

    if (!this.IsSorted) {
      this.FinalPauseList.sort((a, b) => a.AgeinginMins - b.AgeinginMins);
      this.IsSorted = true;
    }
    else {
      this.FinalPauseList = Object.assign([], this.PauseList);
      this.IsSorted = false;
    }

    console.log(this.FinalPauseList);

  }

}
