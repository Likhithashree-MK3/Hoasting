import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechydetailsPage } from './sctechydetails';

@NgModule({
  declarations: [
    SctechydetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechydetailsPage),
  ],
})
export class SctechydetailsPageModule {}
