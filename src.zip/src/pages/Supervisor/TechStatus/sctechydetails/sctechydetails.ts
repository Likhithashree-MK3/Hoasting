import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SctechytsPage } from '../sctechyts/sctechyts';
import { GlobalProvider } from '../../../../providers/global/global';

@IonicPage()
@Component({
  selector: 'page-sctechydetails',
  templateUrl: 'sctechydetails.html',
})

export class SctechydetailsPage {

  YtsList: any = [];
  FinalYtslList: any = [];
  IsSorted: boolean = false;
  SelectedTechnician: any;

  constructor(public navCtrl: NavController,
    public httpClient: HttpClient,
    public global: GlobalProvider,
    public navParams: NavParams) {

    this.global.HeaderTitle = "Yet to Start";

    this.SelectedTechnician = this.navParams.get("data");

  }

  ngOnInit(refresher) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetYetToStartTechnicianDetailesList?TechnicianID=" + this.SelectedTechnician.EmployeeID).subscribe(result => {

        if (result.StatusCode == 200) {

          this.YtsList = JSON.parse(result.Output);

          this.FinalYtslList = Object.assign([], this.YtsList);

          console.log(this.YtsList);

          if (refresher != undefined) {
            refresher.complete();
          }

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  doRefresh(val) {

    this.ngOnInit(val);

  }

  BackClick() {
    this.navCtrl.setRoot(SctechytsPage);
  }

  JCSearch(val) {

    this.FinalYtslList = this.YtsList.filter(e => e.EmployeeName.toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.JCOrderNo.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.JobRole.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.EmployeeCode.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.CompetencyLevel.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
      || e.AvailableFrom.toString().toLowerCase().trim().includes(val.toLowerCase().trim())
    );

    console.log(this.FinalYtslList);

  }

  JCSortClick() {

    if (!this.IsSorted) {

      this.FinalYtslList.sort((a, b) => a.AgeinginMins - b.AgeinginMins);
      this.IsSorted = true;

    }
    else {
      this.FinalYtslList = Object.assign([], this.YtsList);
      this.IsSorted = false;
    }

    console.log(this.FinalYtslList);

  }

}
