import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechytsPage } from './sctechyts';

@NgModule({
  declarations: [
    SctechytsPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechytsPage),
  ],
})
export class SctechytsPageModule {}
