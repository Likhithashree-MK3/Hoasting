import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechpausePage } from './sctechpause';

@NgModule({
  declarations: [
    SctechpausePage,
  ],
  imports: [
    IonicPageModule.forChild(SctechpausePage),
  ],
})
export class SctechpausePageModule {}
