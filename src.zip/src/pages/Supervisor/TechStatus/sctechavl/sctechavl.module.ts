import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechavlPage } from './sctechavl';

@NgModule({
  declarations: [
    SctechavlPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechavlPage),
  ],
})
export class SctechavlPageModule {}
