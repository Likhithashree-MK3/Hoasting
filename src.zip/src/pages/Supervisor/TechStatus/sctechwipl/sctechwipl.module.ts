import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechwiplPage } from './sctechwipl';

@NgModule({
  declarations: [
    SctechwiplPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechwiplPage),
  ],
})
export class SctechwiplPageModule {}
