import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScpfalistPage } from './scpfalist';

@NgModule({
  declarations: [
    ScpfalistPage,
  ],
  imports: [
    IonicPageModule.forChild(ScpfalistPage),
  ],
})
export class ScpfalistPageModule {}
