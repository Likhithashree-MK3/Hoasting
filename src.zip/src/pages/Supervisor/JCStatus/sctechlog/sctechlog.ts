import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GlobalProvider } from '../../../../providers/global/global';
import { HttpClient } from '@angular/common/http';

@IonicPage()
@Component({
  selector: 'page-sctechlog',
  templateUrl: 'sctechlog.html',
})

export class SctechlogPage {

  SelectedJC: any;
  SelectedTech: any;
  ActivityLogs: any = [];

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public httpClient: HttpClient) {

    this.SelectedJC = this.navParams.get("sjc");
    this.SelectedTech = this.navParams.get("technician");

    //console.log(this.SelectedJC);
    //console.log(this.SelectedTech);

    this.global.HeaderTitle = this.SelectedTech.Name;

  }

  ngOnInit() {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetTechnicianActivityLog?JobCard_ID=" + this.SelectedJC.JobCardHedIC + "&Technician_ID=" + this.SelectedTech.Employee_IC).subscribe(jobs => {

        if (jobs.StatusCode == 200) {

          let TempActivityLog = JSON.parse(jobs.Output)
          console.log(JSON.parse(jobs.Output));

          TempActivityLog.forEach((a, index) => {

            if (index == 0) {

              this.ActivityLogs = [{
                ListType: 1,
                Date: TempActivityLog[0].ActDateTime,
                JobCardHeader_IC: TempActivityLog[0].JobCardHeader_IC,
                TechnicianID: TempActivityLog[0].TechnicianID,
                ActDateTime: TempActivityLog[0].ActDateTime,
                Act_Type: TempActivityLog[0].Act_Type
              }];

            }
            else {

              let d1 = this.ActivityLogs[this.ActivityLogs.length - 1].ActDateTime.split("T")[0];
              let d2 = a.ActDateTime.split("T")[0];

              if (d1 == d2) {
                this.ActivityLogs.push({
                  ListType: 2,
                  Date: a.ActDateTime,
                  JobCardHeader_IC: a.JobCardHeader_IC,
                  TechnicianID: a.TechnicianID,
                  ActDateTime: a.ActDateTime,
                  Act_Type: a.Act_Type
                });
              }
              else {
                this.ActivityLogs.push({
                  ListType: 1,
                  Date: a.ActDateTime,
                  JobCardHeader_IC: a.JobCardHeader_IC,
                  TechnicianID: a.TechnicianID,
                  ActDateTime: a.ActDateTime,
                  Act_Type: a.Act_Type
                });
              }

            }

          });

          console.log(this.ActivityLogs);

        }
        else {
          console.log(jobs);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  GetDateFormat(val) {

    let d = new Date(val);

    let date = d.toLocaleString('en-us', { weekday: 'long' }) + ", " + d.getDate() + " " + d.toString().split(" ")[1] + " " + d.toString().split(" ")[3]

    return date;

  }

}