import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SctechlogPage } from './sctechlog';

@NgModule({
  declarations: [
    SctechlogPage,
  ],
  imports: [
    IonicPageModule.forChild(SctechlogPage),
  ],
})
export class SctechlogPageModule {}
