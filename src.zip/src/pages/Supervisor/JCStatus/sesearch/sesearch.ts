import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { GlobalProvider } from '../../../../providers/global/global';
import { HttpClient } from '@angular/common/http';
import { ScwipdetailsPage } from '../scwipdetails/scwipdetails';
import { ScallocatedytsdetailsPage } from '../scallocatedytsdetails/scallocatedytsdetails';
import { SconholddetailsPage } from '../sconholddetails/sconholddetails';
import { SccmpteddetailsPage } from '../sccmpteddetails/sccmpteddetails';
import { Sccmptedt5pdetailsPage } from '../sccmptedt5pdetails/sccmptedt5pdetails';
import { Sccmptedt5ddetailsPage } from '../sccmptedt5ddetails/sccmptedt5ddetails';
import { ScetdedetailsPage } from '../scetdedetails/scetdedetails';
import { LoginPage } from '../../../Shared/login/login';
import { ScpfadetailsPage } from '../scpfadetails/scpfadetails';

@IonicPage()
@Component({
  selector: 'page-sesearch',
  templateUrl: 'sesearch.html',
})

export class SesearchPage {

  SEList: any = [];
  FinalSEList: any = [];
  SelectedSEList: any = [];
  SelectedJC: any = [];
  TempSEList: any = [];
  FreeTechnician: any = [];

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public global: GlobalProvider,
    public httpClient: HttpClient,
    public viewCtrl: ViewController) {

    this.global.HeaderTitle = "Add Technician";

    this.SelectedSEList = this.navParams.get("SEList");
    this.SelectedJC = this.navParams.get("JC");

    //console.log(this.SelectedSEList);
    //console.log(this.SelectedJC);

  }

  ngOnInit() {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "GetBranchTechnicians?BranchID=" + this.global.UserDetails[0].BranchID).subscribe(technicians => {

        if (technicians.StatusCode == 200) {

          let employees = JSON.parse(technicians.Output);

          employees.forEach(ele => {

            let emp = this.SelectedSEList.filter(a => a.Employee_IC == ele.Employee_IC);

            if (emp.length > 0) {
              ele.IsSelected = true;
              ele.LastActivity = emp[0].LastActivity;
              ele.PauseActivity_ID = emp[0].PauseActivity_ID;
              ele.DetailerPauseReason = emp[0].DetailerPauseReason;
              ele.AssignedDate = emp[0].AssignedDate;
              ele.ModifiedDate = (emp[0].ModifiedDate == "0001-01-01T00:00:00") ? "01-10-2000" : emp[0].ModifiedDate;
              ele.OnHoldTimeinMins = emp[0].OnHoldTimeinMins;
              ele.StartDateTime = (emp[0].StartDateTime == "0001-01-01T00:00:00") ? "01-10-2000" : emp[0].StartDateTime;
              ele.EndDateTime = (emp[0].EndDateTime == "0001-01-01T00:00:00") ? "01-10-2000" : emp[0].EndDateTime;
              ele.IsDisabled = true; // Mark as disabled if already selected
              ele.IsReallocation = false;
            }
            else {
              ele.IsSelected = false;
              ele.LastActivity = 0;
              ele.PauseActivity_ID = 0;
              ele.DetailerPauseReason = "";
              ele.AssignedDate = "02-10-2000";
              ele.ModifiedDate = "01-10-2000";
              ele.OnHoldTimeinMins = 0;
              ele.StartDateTime = "01-10-2000";
              ele.EndDateTime = "01-10-2000";
              ele.IsDisabled = false; // Mark as disabled if already selected
              ele.IsReallocation = false;
            }

          });

          this.SEList = employees;
          this.FinalSEList = Object.assign([], employees);
          console.log(this.FinalSEList);

          // FETCHING FREE TECHNICIANS TO SEND NOTIFICATION 
          this.httpClient.get<any>(this.global.HostedPath + "GetAvailableTechnicianList?BranchID=" + this.global.UserDetails[0].BranchID).subscribe(result => {

            if (result.StatusCode == 200) {

              let TechnicianList = JSON.parse(result.Output);
              TechnicianList.forEach(ele => {
                this.FreeTechnician.push(ele.EmployeeID)
              });

            }
            else {
              console.log(result);
              this.global.ToastShow("Something went wrong, Pls try again later");
            }

          }, (error) => {
            console.log(error);
          });

        }
        else {
          console.log(technicians);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  SEListClick(val) {

    if (val.IsDisabled) {
      return; // Do nothing if the technician is disabled
    }

    if (val.IsSelected) {
      this.SEDeleteClick(val);
    } else {
      val.IsSelected = !val.IsSelected;
      this.UpdateSelectedList(); // Update selected list
    }

  }

  SESearch1(val) {

    this.FinalSEList = this.SEList.filter(p => p.Name.toLowerCase().trim().includes(val.toLowerCase().trim())
      || p.Code.toLowerCase().trim().includes(val.toLowerCase().trim()));

    console.log(this.FinalSEList);

  };

  SESearch(val) {
    const lowerTerm = val.toLowerCase().trim();
    this.FinalSEList = this.SEList.filter(p => p.Name.toLowerCase().trim().includes(lowerTerm)
      || p.Code.toLowerCase().trim().includes(lowerTerm)
      || p.IsSelected); // Ensure selected technicians are included in the search results
    console.log(this.FinalSEList);
  }

  SaveClick() {

    console.log(this.FinalSEList);

    let JCEmployees = [];
    this.FinalSEList.forEach(ele => {
      if (ele.IsSelected) {
        JCEmployees.push({
          JobCardHeader_IC: this.SelectedJC.JobCardHedIC,
          AssignedBy: this.global.UserDetails[0].Employee_IC,
          AssignedTechnicianID: ele.Employee_IC,
          LastActivity: ele.LastActivity,
          PauseActivity_ID: ele.PauseActivity_ID,
          DetailerPauseReason: ele.DetailerPauseReason,
          AssignedDate: ele.AssignedDate,
          ModifiedDate: ele.ModifiedDate,
          OnHoldTimeinMins: ele.OnHoldTimeinMins,
          StartDateTime: ele.StartDateTime,
          EndDateTime: ele.EndDateTime,
          IsReallocation: ele.IsReallocation
        });
      }
    });

    console.log(JCEmployees);

    if (JCEmployees.length > 0) {

      if (this.global.CheckInternetConnection()) {

        this.global.LoadingShow("Please wait...");

        this.httpClient.post<any>(this.global.HostedPath + "UpdateJC", JCEmployees).subscribe(result => {

          if (result.StatusCode == 200) {

            console.log(result);

            let Description = "JC " + this.SelectedJC.OrderNo + " has been allocated";
            for (let i = 0; i < JCEmployees.length; i++) {
              this.global.RealTimeInsertIntoTrAlert2IfTechFree(JCEmployees[i].JobCardHeader_IC, JCEmployees[i].AssignedTechnicianID, Description, 'High');
            }

            this.global.ToastShow("Submitted Succesfully");

            switch (this.global.SESearchPage) {

              case "PFA":
                this.navCtrl.setRoot(ScpfadetailsPage, { data: this.global.SelectedJC });
                break;

              case "WIP":
                this.navCtrl.setRoot(ScwipdetailsPage, { data: this.global.SelectedJC });
                break;

              case "AllocatedYTS":
                this.navCtrl.setRoot(ScallocatedytsdetailsPage, { data: this.global.SelectedJC });
                break;

              case "OnHold":
                this.navCtrl.setRoot(SconholddetailsPage, { data: this.global.SelectedJC });
                break;

              case "Completed":
                this.navCtrl.setRoot(SccmpteddetailsPage, { data: this.global.SelectedJC });
                break;

              case "CompletedT5Pend":
                this.navCtrl.setRoot(Sccmptedt5pdetailsPage, { data: this.global.SelectedJC });
                break;

              case "CompletedT5Done":
                this.navCtrl.setRoot(Sccmptedt5ddetailsPage, { data: this.global.SelectedJC });
                break;

              case "ETDExceeded":
                this.navCtrl.setRoot(ScetdedetailsPage, { data: this.global.SelectedJC });
                break;

              default:
                this.navCtrl.setRoot(LoginPage);
                break;
            }

          }
          else {
            console.log(result);
            this.global.ToastShow("Something went wrong, Pls try again later");
          }

          this.global.LoadingHide();

        }, (error) => {
          console.log(error);
          this.global.LoadingHide();
        });

      }
      else {
        this.global.ToastShow(this.global.NetworkMessage);
      }

    }
    else {
      this.global.ToastShow("Please select atleast one Technician");
    }

  }

  BackClick() {
    this.viewCtrl.dismiss();
  }

  GetTechnicianCount() {
    return this.FinalSEList.filter(t => t.IsSelected).length;
  }

  SEDeleteClick1(Employee) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");

      this.httpClient.get<any>(this.global.HostedPath + "DeleteTechnicians?JobCardHeaderIC=" + this.SelectedJC.JobCardHedIC + "&TechnicianIC=" + Employee.Employee_IC).subscribe(result => {

        if (result.StatusCode == 200) {

          console.log(JSON.parse(result.Output));

          if (result.Output == 0) {

            Employee.IsSelected = !Employee.IsSelected;

            this.SelectedSEList = this.FinalSEList.filter(a => a.IsSelected);
          }
          else {
            this.global.ToastShow(Employee.Name + " has already started this Job");
          }

        }
        else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });

    }
    else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  SEDeleteClick(Employee) {

    if (this.global.CheckInternetConnection()) {

      this.global.LoadingShow("Please wait...");
      this.httpClient.get<any>(this.global.HostedPath + "DeleteTechnicians?JobCardHeaderIC=" + this.SelectedJC.JobCardHedIC + "&TechnicianIC=" + Employee.Employee_IC).subscribe(result => {

        if (result.StatusCode == 200) {

          console.log(JSON.parse(result.Output));
          if (result.Output == 0) {
            Employee.IsSelected = !Employee.IsSelected;
            this.UpdateSelectedList(); // Update selected list
          } else {
            this.global.ToastShow(Employee.Name + " has already started this Job");
          }

          Employee.IsDisabled = false;

        } else {
          console.log(result);
          this.global.ToastShow("Something went wrong, Pls try again later");
        }

        this.global.LoadingHide();

      }, (error) => {
        console.log(error);
        this.global.LoadingHide();
      });
    } else {
      this.global.ToastShow(this.global.NetworkMessage);
    }

  }

  IsEmployeeSelected(emp): Boolean {

    let v = this.SelectedSEList.filter(e => e.Employee_IC == emp.Employee_IC);

    if (v.length > 0) {
      return true;
    }
    else {
      return false;
    }

  }

  UpdateSelectedList() {
    this.SelectedSEList = this.FinalSEList.filter(employee => employee.IsSelected);
  }

}