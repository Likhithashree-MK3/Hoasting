import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScpfadetailsPage } from './scpfadetails';

@NgModule({
  declarations: [
    ScpfadetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ScpfadetailsPage),
  ],
})
export class ScpfadetailsPageModule {}
