import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScetdedetailsPage } from './scetdedetails';

@NgModule({
  declarations: [
    ScetdedetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ScetdedetailsPage),
  ],
})
export class ScetdedetailsPageModule {}
