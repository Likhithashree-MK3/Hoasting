import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SccmptedlistPage } from './sccmptedlist';

@NgModule({
  declarations: [
    SccmptedlistPage,
  ],
  imports: [
    IonicPageModule.forChild(SccmptedlistPage),
  ],
})
export class SccmptedlistPageModule {}
