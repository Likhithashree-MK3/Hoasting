import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScetdelistPage } from './scetdelist';

@NgModule({
  declarations: [
    ScetdelistPage,
  ],
  imports: [
    IonicPageModule.forChild(ScetdelistPage),
  ],
})
export class ScetdelistPageModule {}
