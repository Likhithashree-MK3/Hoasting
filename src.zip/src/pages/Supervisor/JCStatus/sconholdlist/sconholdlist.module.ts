import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SconholdlistPage } from './sconholdlist';

@NgModule({
  declarations: [
    SconholdlistPage,
  ],
  imports: [
    IonicPageModule.forChild(SconholdlistPage),
  ],
})
export class SconholdlistPageModule {}
