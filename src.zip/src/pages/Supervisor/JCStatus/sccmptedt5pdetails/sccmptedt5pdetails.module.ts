import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sccmptedt5pdetailsPage } from './sccmptedt5pdetails';

@NgModule({
  declarations: [
    Sccmptedt5pdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(Sccmptedt5pdetailsPage),
  ],
})
export class Sccmptedt5pdetailsPageModule {}
