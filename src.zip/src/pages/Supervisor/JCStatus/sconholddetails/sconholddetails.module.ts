import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SconholddetailsPage } from './sconholddetails';

@NgModule({
  declarations: [
    SconholddetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SconholddetailsPage),
  ],
})
export class SconholddetailsPageModule {}
