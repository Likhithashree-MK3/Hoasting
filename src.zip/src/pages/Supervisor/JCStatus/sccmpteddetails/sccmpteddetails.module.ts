import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SccmpteddetailsPage } from './sccmpteddetails';

@NgModule({
  declarations: [
    SccmpteddetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SccmpteddetailsPage),
  ],
})
export class SccmpteddetailsPageModule {}
