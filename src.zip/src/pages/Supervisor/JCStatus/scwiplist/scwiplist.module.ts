import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScwiplistPage } from './scwiplist';

@NgModule({
  declarations: [
    ScwiplistPage,
  ],
  imports: [
    IonicPageModule.forChild(ScwiplistPage),
  ],
})
export class ScwiplistPageModule {}
