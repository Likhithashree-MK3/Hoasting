import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sccmptedt5ddetailsPage } from './sccmptedt5ddetails';

@NgModule({
  declarations: [
    Sccmptedt5ddetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(Sccmptedt5ddetailsPage),
  ],
})
export class Sccmptedt5ddetailsPageModule {}
