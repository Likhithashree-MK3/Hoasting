import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScallocatedytslistPage } from './scallocatedytslist';

@NgModule({
  declarations: [
    ScallocatedytslistPage,
  ],
  imports: [
    IonicPageModule.forChild(ScallocatedytslistPage),
  ],
})
export class ScallocatedytslistPageModule {}
