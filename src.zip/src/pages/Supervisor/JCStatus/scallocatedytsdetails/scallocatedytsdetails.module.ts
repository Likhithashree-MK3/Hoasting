import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScallocatedytsdetailsPage } from './scallocatedytsdetails';

@NgModule({
  declarations: [
    ScallocatedytsdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ScallocatedytsdetailsPage),
  ],
})
export class ScallocatedytsdetailsPageModule {}
