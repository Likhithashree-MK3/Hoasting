import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sccmptedt5plistPage } from './sccmptedt5plist';

@NgModule({
  declarations: [
    Sccmptedt5plistPage,
  ],
  imports: [
    IonicPageModule.forChild(Sccmptedt5plistPage),
  ],
})
export class Sccmptedt5plistPageModule {}
