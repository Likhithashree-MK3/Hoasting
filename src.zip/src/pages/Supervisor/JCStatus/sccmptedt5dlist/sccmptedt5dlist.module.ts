import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sccmptedt5dlistPage } from './sccmptedt5dlist';

@NgModule({
  declarations: [
    Sccmptedt5dlistPage,
  ],
  imports: [
    IonicPageModule.forChild(Sccmptedt5dlistPage),
  ],
})
export class Sccmptedt5dlistPageModule {}
