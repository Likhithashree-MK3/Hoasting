import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScwipdetailsPage } from './scwipdetails';

@NgModule({
  declarations: [
    ScwipdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ScwipdetailsPage),
  ],
})
export class ScwipdetailsPageModule {}
