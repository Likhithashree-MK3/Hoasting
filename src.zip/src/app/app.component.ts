import { Component, ViewChild } from '@angular/core';
import { ActionSheetController, AlertController, App, IonicApp, Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Camera } from '@ionic-native/camera';

import { LoginPage } from '../pages/Shared/login/login';
import { GlobalProvider } from '../providers/global/global';
import { DashboardPage } from '../pages/Supervisor/KPI/dashboard/dashboard';
import { HttpClient } from '@angular/common/http';
import { RealizationPage } from '../pages/Supervisor/KPI/realization/realization';
import { ScpfalistPage } from '../pages/Supervisor/JCStatus/scpfalist/scpfalist';
import { ScetdelistPage } from '../pages/Supervisor/JCStatus/scetdelist/scetdelist';
import { ScallocatedytslistPage } from '../pages/Supervisor/JCStatus/scallocatedytslist/scallocatedytslist';
import { ScwiplistPage } from '../pages/Supervisor/JCStatus/scwiplist/scwiplist';
import { SconholdlistPage } from '../pages/Supervisor/JCStatus/sconholdlist/sconholdlist';
import { SccmptedlistPage } from '../pages/Supervisor/JCStatus/sccmptedlist/sccmptedlist';
import { Sccmptedt5plistPage } from '../pages/Supervisor/JCStatus/sccmptedt5plist/sccmptedt5plist';
import { Sccmptedt5dlistPage } from '../pages/Supervisor/JCStatus/sccmptedt5dlist/sccmptedt5dlist';
import { StdashboardPage } from '../pages/Technician/stdashboard/stdashboard';
import { ProfilePage } from '../pages/Shared/profile/profile';
import { StytsPage } from '../pages/Technician/styts/styts';
import { StwipPage } from '../pages/Technician/stwip/stwip';
import { StpausedPage } from '../pages/Technician/stpaused/stpaused';
import { SctechpausePage } from '../pages/Supervisor/TechStatus/sctechpause/sctechpause';
import { SctechytsPage } from '../pages/Supervisor/TechStatus/sctechyts/sctechyts';
import { SconholddetailsPage } from '../pages/Supervisor/JCStatus/sconholddetails/sconholddetails';
import { ScallocatedytsdetailsPage } from '../pages/Supervisor/JCStatus/scallocatedytsdetails/scallocatedytsdetails';
import { WelcomePage } from '../pages/Shared/welcome/welcome';
import { ScwipdetailsPage } from '../pages/Supervisor/JCStatus/scwipdetails/scwipdetails';
import { SccmpteddetailsPage } from '../pages/Supervisor/JCStatus/sccmpteddetails/sccmpteddetails';
import { Sccmptedt5pdetailsPage } from '../pages/Supervisor/JCStatus/sccmptedt5pdetails/sccmptedt5pdetails';
import { Sccmptedt5ddetailsPage } from '../pages/Supervisor/JCStatus/sccmptedt5ddetails/sccmptedt5ddetails';
import { ScetdedetailsPage } from '../pages/Supervisor/JCStatus/scetdedetails/scetdedetails';
import { ScpfadetailsPage } from '../pages/Supervisor/JCStatus/scpfadetails/scpfadetails';
declare var Pushy: any;

@Component({
  templateUrl: 'app.html'
})

export class MyApp {

  @ViewChild(Nav) nav: Nav;

  rootPage: any = LoginPage;

  constructor(public platform: Platform,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    public global: GlobalProvider,
    public alertCtrl: AlertController,
    public httpClient: HttpClient,
    public app: App,
    public camera: Camera,
    public actionSheetCtrl: ActionSheetController,
    public ionicApp: IonicApp) {

    this.initializeApp();

    this.platform.registerBackButtonAction(() => {
      this.BackButtonClick();
    });

  }

  initializeApp() {

    this.platform.ready().then(() => {

      this.statusBar.styleDefault();
      this.splashScreen.hide();

    });

  }

  ngOnInit() {

    // ===================================================== PUSHY NOTIFICATION NAVIGATIONS ============================================ //
    let that = this;

    document.addEventListener('deviceready', function () {

      // Start the Pushy service
      Pushy.listen();

      // Custom Notification Icon (Android)
      Pushy.setNotificationIcon('ic_notification');

      // Enable in-app notification banners (iOS 10+)
      Pushy.toggleInAppBanner(true);

      // Listen for push notifications
      Pushy.setNotificationListener(function (data) {
        console.log('Received notification: ' + data.message);
        // Clear iOS app badge number
        Pushy.clearBadge();
      });

      // Listen for notification click
      Pushy.setNotificationClickListener(function (data) {

        console.log('Notification click: ' + data.message);
        console.log('EmployeeID: ' + data.EmployeeID);
        console.log('JobCardHedIC : ' + data.JobCardHedIC);

        let JC = { JobCardHedIC: data.JobCardHedIC }

        if (that.global.isDeviceLogedIn) {

          console.log("Device is LogedIn");

          // Navigate the user to Particular pages

          if (data.message.includes('Diagnosis Issue')) {                         // Diagnosis Issue

            console.log('Notification click Message Contain - Diagnosis Issue');
            // that.nav.setRoot(SconholdlistPage); 
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('Pending for Allocation')) {            // Pending for Allocation

            console.log('Notification click Message Contain - Pending for Allocation');
            // that.nav.setRoot(ScpfalistPage);
            if (that.global.IsManager) {
              that.nav.setRoot(ScpfalistPage);
            }
          }
          else if (data.message.includes('YTS')) {                              // YTS

            console.log('Notification click Message Contain - YTS');
            // that.nav.setRoot(ScallocatedytslistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(ScallocatedytsdetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('has been allocated')) {             // JC# has been allocated

            console.log('Notification click Message Contain - has been allocated');
            that.nav.setRoot(WelcomePage);

          }
          else if (data.message.includes('No Job is assigned')) {             // No Job is assigned

            console.log('Notification click Message Contain - No Job is assigned');
            if (!that.global.IsManager) {
              that.nav.setRoot(ScpfalistPage);
            }
          }
          else if (data.message.includes('Ancillary')) {                      // Ancillary

            console.log('Notification click Message Contain - Ancillary');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('working on another vehicle')) {     // working on another vehicle

            console.log('Notification click Message Contain - working on another vehicle');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('Shift Change alert')) {             // Shift Change alert

            console.log('Notification click Message Contain - Shift Change alert');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('Tea break')) {                    // Tea break

            console.log('Notification click Message Contain - Tea break');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('Bio break')) {                    // Bio break

            console.log('Notification click Message Contain - Bio break');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }
          else if (data.message.includes('Lunch break')) {                // Lunch break

            console.log('Notification click Message Contain - Lunch break');
            // that.nav.setRoot(SconholdlistPage);
            if (!that.global.IsManager) {
              that.nav.setRoot(SconholddetailsPage, { data: JC });
            }
          }


        } else {
          console.log("Device is Not DeviceLogedIn");
        }
        // that.nav.setRoot(NotificationsPage);
        // console.log("Wellcome to NotificationsPage")
      });

    });

    // ============================================================================================================================= //
  }

  AboutClick() {

    console.log(this.global.AutoUpdateDetails)

    let AboutAlert = this.alertCtrl.create({
      title: 'About',
      message: '<center><span>' + this.global.AutoUpdateDetails[0].ApplicationName + '</span> <br/><span></span><br/>Version :' + this.global.AutoUpdateDetails[0].AppStoreVersion + '<br/><span></span><br/>Size : ' + this.global.AutoUpdateDetails[0].AppSize + ' MB<center>',
      buttons: [
        {
          text: 'OK',
          cssClass: 'BtnOnePopup',
          handler: data => {

          }
        }
      ],
      enableBackdropDismiss: false

    });

    AboutAlert.present();

  }

  BackButtonClick() {

    const overlayView = this.ionicApp._overlayPortal._views[0];

    if (!(overlayView && overlayView.dismiss)) {

      let nav = this.app.getActiveNavs()[0];
      let activeView = nav.getActive();

      console.log(activeView.name);

      switch (activeView.name) {

        case "LoginPage":
        case "WelcomePage":
          this.platform.exitApp();
          break;

        case "DashboardPage":
        case "StdashboardPage":
          if (!this.global.IsAlertOpen) {
            this.RegistrationBackClick("Are you sure, you want to Logout?");
          }
          break;

        case "UtilizationPage":
        case "RealizationPage":
        case "ProductivityPage":
        case "SctechavlPage":
        case "SctechwiplPage":
        case "SctechytsPage":
        case "SctechpausePage":
        case "ScpfalistPage":
        case "ScetdelistPage":
        case "ScallocatedytslistPage":
        case "ScwiplistPage":
        case "SconholdlistPage":
        case "SccmptedlistPage":
        case "Sccmptedt5plistPage":
        case "Sccmptedt5dlistPage":
          this.nav.setRoot(DashboardPage);
          break;

        case "ProfilePage":
        case "NotificationsPage":
        case "CommunicationPage":
        case "GovernancePage":
          if (this.global.WelcomeNavigateType == 1) {
            this.nav.setRoot(DashboardPage);
          }
          else if (this.global.WelcomeNavigateType == 2 ||
            this.global.WelcomeNavigateType == 3 ||
            this.global.WelcomeNavigateType == 4 ||
            this.global.WelcomeNavigateType == 5) {
            this.nav.setRoot(StdashboardPage);
          }
          break;

        case "StatisticsPage":
          this.nav.setRoot(RealizationPage);
          break;

        case "ScpfadetailsPage":
          this.nav.setRoot(ScpfalistPage);
          break;

        case "ScetdedetailsPage":
          this.nav.setRoot(ScetdelistPage);
          break;

        case "ScallocatedytsdetailsPage":
          this.nav.setRoot(ScallocatedytslistPage);
          break;

        case "ScwipdetailsPage":
          this.nav.setRoot(ScwiplistPage);
          break;

        case "SconholddetailsPage":
          this.nav.setRoot(SconholdlistPage);
          break;

        case "SccmpteddetailsPage":
          this.nav.setRoot(SccmptedlistPage);
          break;

        case "Sccmptedt5pdetailsPage":
          this.nav.setRoot(Sccmptedt5plistPage);
          break;

        case "Sccmptedt5ddetailsPage":
          this.nav.setRoot(Sccmptedt5dlistPage);
          break;

        case "StrealizationPage":
        case "StytsPage":
        case "StwipPage":
        case "StpausedPage":
        case "StcompletedPage":
          this.nav.setRoot(StdashboardPage);
          break;

        case "SctechpdetailsPage":
          this.nav.setRoot(SctechpausePage);
          break;

        case "SctechydetailsPage":
          this.nav.setRoot(SctechytsPage);
          break;

        case "SesearchPage":
        case "SctechlogPage":

          switch (this.global.SESearchPage) {

            case "PFA":
              this.nav.setRoot(ScpfadetailsPage, { data: this.global.SelectedJC });
              break;

            case "WIP":
              this.nav.setRoot(ScwipdetailsPage, { data: this.global.SelectedJC });
              break;

            case "AllocatedYTS":
              this.nav.setRoot(ScallocatedytsdetailsPage, { data: this.global.SelectedJC });
              break;

            case "OnHold":
              this.nav.setRoot(SconholddetailsPage, { data: this.global.SelectedJC });
              break;

            case "Completed":
              this.nav.setRoot(SccmpteddetailsPage, { data: this.global.SelectedJC });
              break;

            case "CompletedT5Pend":
              this.nav.setRoot(Sccmptedt5pdetailsPage, { data: this.global.SelectedJC });
              break;

            case "CompletedT5Done":
              this.nav.setRoot(Sccmptedt5ddetailsPage, { data: this.global.SelectedJC });
              break;

            case "ETDExceeded":
              this.nav.setRoot(ScetdedetailsPage, { data: this.global.SelectedJC });
              break;

            default:
              this.nav.setRoot(LoginPage);
              break;
          }

          break;

        case "StjcdetailsPage":
          if (this.global.CurrentPage == "StytsPage") {
            this.nav.setRoot(StytsPage);
          }
          else if (this.global.CurrentPage == "StwipPage") {
            this.nav.setRoot(StwipPage);
          }
          else if (this.global.CurrentPage == "StpausedPage") {
            this.nav.setRoot(StpausedPage);
          }
          break;

        case "ModalCmp":
          break;

        case "SependingjcPage":
          if (!this.global.IsAlertOpen) {

            this.global.IsAlertOpen = true;

            const confirm = this.alertCtrl.create({
              title: "Confirm",
              message: "Punch in your stopped time or else app cannot be used",
              buttons: [
                {
                  text: 'OK',
                  cssClass: "BtnOnePopup",
                  handler: () => {
                    this.global.IsAlertOpen = false;
                  }
                },
              ],
              enableBackdropDismiss: false
            });

            confirm.present();

          }
          break;

        default:
          this.nav.setRoot(LoginPage);
          break;

      }

    }

  }

  LogoutClick() {
    if (!this.global.IsAlertOpen) {
      this.RegistrationBackClick("Are you sure, you want to Logout?");
    }
  }

  RegistrationBackClick(msg) {

    this.global.IsAlertOpen = true;

    const confirm = this.alertCtrl.create({
      title: "Confirm",
      message: msg,
      buttons: [
        {
          text: 'No',
          cssClass: "BtnTwoPopup",
          handler: () => {
            this.global.IsAlertOpen = false;
          }
        },
        {
          text: 'Yes',
          cssClass: "BtnTwoPopup",
          handler: () => {
            this.nav.setRoot(LoginPage);
            this.global.IsAlertOpen = false;
            localStorage.clear();
          }
        }
      ],
      enableBackdropDismiss: false
    });

    confirm.present();

  }

  ProfilePencilClick() {

    this.nav.setRoot(ProfilePage);

  }

  FileChangeMethod(e) {

    console.log(e.target.files[0])

    var formData = new FormData();

    formData.append("Photo_1", e.target.files[0]);

    this.httpClient.post(this.global.HostedPath + 'UploadFile?EmpCode=' + this.global.UserDetails[0].Code, formData).subscribe(imageUploadData => {

      console.log(imageUploadData);

    }, error => {

      console.log(error);

      this.global.ToastShow("Failed to-upload attachments");

    });

  }

}