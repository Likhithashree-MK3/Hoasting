import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Network } from '@ionic-native/network';
import { LoadingController, ToastController } from 'ionic-angular';

@Injectable()
export class GlobalProvider {

  HeaderTitle: string = "";

  UserDetails: any = [{ Designation: "" }];

  ApplicationVersion: number = 10;
  AppVersion = "1.9";
  isDevice: boolean = false;
  WelcomeScreentime: number = 500;

  SelectedJC: any;
  IsManager: boolean = false;
  WelcomeNavigateType: number = 0;
  ProfilePhotoPath: string = "";
  PendingJCData: any;
  SESearchPage: string = "";
  CurrentPage: string = "";
  userpasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  RealTimeNotificationAlertCount: number = 0;
  alertMessages: any = [];
  notificationMessage: any = [];
  AlertMessagesReadingCount: number = 0;
  NotificationMessagesReadingCount: number = 0;

  isDeviceLogedIn: boolean = false;
  iscardOpen: boolean = false;
  FilterList: any = [
    {
      id: 1,
      name: "Last Day",
      isSelected: false
    },
    {
      id: 2,
      name: "Last 7 Days",
      isSelected: false
    },
    {
      id: 3,
      name: "MTD",
      isSelected: false
    },
    {
      id: 4,
      name: "Last Month",
      isSelected: false
    },
    {
      id: 5,
      name: "YTD",
      isSelected: false
    },
    {
      id: 6,
      name: "Date Range",
      isSelected: false
    }];

  //HostedPath = "http://localhost:64500/api/EicherAPI2/";                                    //Local debug
  //HostedPath = "http://localhost/EicherWeb_Dev/api/EicherAPI/";                             //Local
  //HostedPath = "http://192.168.3.69/EicherWeb_Dev/api/EicherAPI2/";                         //Local
  //HostedPath = "https://namptest.hcltechswnp.com/Eicher_Dev/api/EicherAPI2/";               //Dev
  HostedPath = "https://namptest.hcltechswnp.com/Eicher_QA/api/EicherAPI2/";                 //Testing
  //HostedPath = "https://namptest.hcltechswnp.com/Eicher_Pilot/api/EicherAPI/";              //Chennai
  //HostedPath = "https://wps_prod.vecv.net/Workshop_Productivity/api/EicherAPI/";            //Live
  //HostedPath = "http://10.210.3.45/Eicher_UAT/api/EicherAPI/";                              //UAT
  //HostedPath = "https://wps_prod.vecv.net/Workshop_Productivity_STG/api/EicherAPI2/";       //Phase 2 STG

  IsAlertOpen: boolean = false;

  load: any;

  NetworkMessage: string;

  MasterData: any = {};

  AutoUpdateDetails: any = [];

  //READ
  ApiGetHeaders = new HttpHeaders({
    'Authorization': '12345Read',
    'Content-Type': 'application/json'
  });

  //INSERT
  ApiInsertHeaders = new HttpHeaders({
    'Authorization': '12345Insert',
    'Content-Type': 'application/json'
  });

  //UPDATE
  ApiUpdateHeaders = new HttpHeaders({
    'Authorization': '12345Update',
    'Content-Type': 'application/json'
  });

  //DELETE
  ApiDeleteHeaders = new HttpHeaders({
    'Authorization': '12345Delete',
    'Content-Type': 'application/json'
  });

  constructor(public http: HttpClient,
    public toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    public network: Network) {

    // Call This method every 10 seconds (10000 milliseconds)
    // Call This method every 5 seconds (5000 milliseconds)
    setInterval(() => {

      if (this.WelcomeNavigateType != 0) {
        this.RealTimeNotificationAlertCountFunction();
      }

    }, 1000);

  }

  public ToastShow(message: string): any {

    let toast = this.toastCtrl.create({
      message: message,
      duration: 3000,
      position: 'bottom'
    });

    toast.present();

  }

  public LoadingShow(val: string) {

    this.load = this.loadingCtrl.create({
      //content: val
      content: "<img src='assets/imgs/Dashboard.png' class='ImgLoading' />"
    });

    this.load.present();

  }

  public LoadingHide() {

    this.load.dismiss();

  }

  public CheckInternetConnection(): boolean {

    if (this.network.type != "none") {

      if (this.network.type != "2g") {
        return true;
      }
      else {
        this.NetworkMessage = "Poor Network connectivity";
        return false;
      }

    }
    else {
      this.NetworkMessage = "App requires connection to Internet";
      return false;
    }

  }

  public DisplayTimeFormate(value) {

    let hours = Math.floor(value / 60);

    let minutes = Math.floor(value % 60);

    let h = hours > 9 ? hours : "0" + hours;
    let m = minutes > 9 ? minutes : "0" + minutes;

    return h + ':' + m;

  }

  public IsValid(username: string): boolean {
    return this.userpasswordRegex.test(username);
  }

  public JobTypeFormat(val) {

    if (val != "" && val != null && val != undefined) {
      return val.toString().substr(0, 3);
    }
    else {
      return "";
    }

  }

  public OdoMeterFormat(val) {

    if (val != "" && val != 0 && val != null && val != undefined) {

      let v = val.toString().split("/");

      return v[0] + " km";

    }
    else {
      return "";
    }

  }

  public AbsoluteValue(val) {

    if (val != "" && val != undefined && val != null && val != 0) {
      return Math.abs(val);
    }
    else {
      return val;
    }

  }

  //INSERTING INTO TR_ALERT2 TABLE
  public RealTimeInsertIntoTrAlert2(JobCardHedIC, EmployeIC, Description, Priority) {

    if (this.CheckInternetConnection()) {

      this.http.post(this.HostedPath + "RealTimeInsertIntoTrAlert2?JobCardHedIC=" + JobCardHedIC + "&EmployeIC=" + EmployeIC + "&Description=" + Description + "&Priority=" + Priority, null).subscribe((success) => {

        console.log(success);

      }, (error) => {
        console.log(`Failed To Update RealTimeInsertIntoTrAlert2:`, error);
      });

    }
    else {
      this.ToastShow(this.NetworkMessage);
    }

  }

  //INSERTING INTO TR_Notification2 TABLE
  public RealTimeInsertIntoTrNotification2(JC_Header_ID, Employee_ID, OrderNo, Description, Priority) {

    if (this.CheckInternetConnection()) {

      this.http.post(this.HostedPath + "RealTimeInsertIntoTrNotification2?JC_Header_ID=" + JC_Header_ID + "&Employee_ID=" + Employee_ID + "&OrderNo=" + OrderNo + "&Description=" + Description + "&Priority=" + Priority, null).subscribe((success) => {

        console.log(success);

      }, (error) => {
        console.log(`Failed To Update RealTimeInsertIntoTrNotification2:`, error);
      });

    }
    else {
      this.ToastShow(this.NetworkMessage);
    }

  }

  //INSERTING INTO TR_ALERT2 TABLE IF TECH IS FREE
  public RealTimeInsertIntoTrAlert2IfTechFree(JobCardHedIC, EmployeIC, Description, Priority) {

    if (this.CheckInternetConnection()) {

      this.http.post(this.HostedPath + "RealTimeInsertIntoTrAlert2IfTechFree?JobCardHedIC=" + JobCardHedIC + "&EmployeIC=" + EmployeIC + "&Description=" + Description + "&Priority=" + Priority, null).subscribe((success) => {

        console.log(success);

      }, (error) => {
        console.log(`Failed To Update RealTimeInsertIntoTrAlert2IfTechFree:`, error);
      });

    }
    else {
      this.ToastShow(this.NetworkMessage);
    }

  }

  RealTimeNotificationAlertCountFunction() {

    // ========================================================= ALERT LIST ========================================================= //
    this.http.get<any>(this.HostedPath + "GetAlertDetailsList?EmployeeID=" + this.UserDetails[0].Employee_IC).subscribe(commList => {

      if (commList.StatusCode == 200) {

        this.alertMessages = JSON.parse(commList.Output);

        this.AlertMessagesReadingCount = 0;
        for (let i of this.alertMessages) {
          if (i.IsRead == false) {
            this.AlertMessagesReadingCount++;
          }
        }

      }
      else {
        console.log(commList);
        this.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
    });

    // ========================================================= NOTIFICATION LIST ===================================================== //
    this.http.get<any>(this.HostedPath + "GetNotificationDetailsList?EmployeeID=" + this.UserDetails[0].Employee_IC).subscribe(commList => {

      if (commList.StatusCode == 200) {

        this.notificationMessage = JSON.parse(commList.Output);

        this.NotificationMessagesReadingCount = 0;
        for (let i of this.notificationMessage) {
          if (i.IsRead == false) {
            this.NotificationMessagesReadingCount++;
          }
        }
      }
      else {
        console.log(commList);
        this.ToastShow("Something went wrong, Pls try again later");
      }

    }, (error) => {
      console.log(error);
    });

    this.RealTimeNotificationAlertCount = this.AlertMessagesReadingCount + this.NotificationMessagesReadingCount;

  }

  GetLableName(activity) {

    let name = "";

    switch (activity) {

      case 0:
        name = "Allocated Date and Time:";
        break;
      case 1:
        name = "WIP Date and Time:";
        break;
      case 2:
        name = "Paused Date and Time:";
        break;
      case 4:
      case 5:
        name = "Completed Date and Time:";
        break;
      default:
        name = "Date and Time:";
        break;

    }

    return name;

  }

}